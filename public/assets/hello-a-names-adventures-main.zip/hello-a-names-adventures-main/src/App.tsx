import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Index from "./pages/Index";
import Lesson2 from "./pages/Lesson2";
import Lesson2Intro from "./pages/Lesson2Intro";
import Lesson3 from "./pages/Lesson3";
import Lesson3Intro from "./pages/Lesson3Intro";
import { Lesson21Intro } from "./pages/Lesson21Intro";
import { Lesson21 } from "./pages/Lesson21";
import { Lesson22Intro } from "./pages/Lesson22Intro";
import { Lesson22 } from "./pages/Lesson22";
import { Lesson23Intro } from "./pages/Lesson23Intro";
import { Lesson23 } from "./pages/Lesson23";
import { Lesson24Intro } from "./pages/Lesson24Intro";
import Lesson24 from "./pages/Lesson24";
import { Lesson31Intro } from "./pages/Lesson31Intro";
import Lesson31 from "./pages/Lesson31";
import { Lesson32Intro } from "./pages/Lesson32Intro";
import Lesson32 from "./pages/Lesson32";
import { Lesson33Intro } from "./pages/Lesson33Intro";
import Lesson33 from "./pages/Lesson33";
import { Lesson41Intro } from "./pages/Lesson41Intro";
import Lesson41 from "./pages/Lesson41";
import { Lesson42Intro } from "./pages/Lesson42Intro";
import Lesson42 from "./pages/Lesson42";
import { Lesson43Intro } from "./pages/Lesson43Intro";
import Lesson43 from "./pages/Lesson43";
import { Lesson44Intro } from "./pages/Lesson44Intro";
import Lesson44 from "./pages/Lesson44";
import { Lesson45Intro } from "./pages/Lesson45Intro";
import Lesson45 from "./pages/Lesson45";
import { Lesson51Intro } from "./pages/Lesson51Intro";
import Lesson51 from "./pages/Lesson51";
import { Lesson52Intro } from "./pages/Lesson52Intro";
import Lesson52 from "./pages/Lesson52";
import { Lesson53Intro } from "./pages/Lesson53Intro";
import Lesson53 from "./pages/Lesson53";
import { Lesson54Intro } from "./pages/Lesson54Intro";
import Lesson54 from "./pages/Lesson54";
import { Lesson55Intro } from "./pages/Lesson55Intro";
import Lesson55 from "./pages/Lesson55";
import Lesson61Intro from "./pages/Lesson61Intro";
import Lesson61 from "./pages/Lesson61";
import Lesson62Intro from "./pages/Lesson62Intro";
import Lesson62 from "./pages/Lesson62";
import Lesson63Intro from "./pages/Lesson63Intro";
import Lesson63 from "./pages/Lesson63";
import Lesson71Intro from "./pages/Lesson71Intro";
import Lesson71 from "./pages/Lesson71";
import Lesson72Intro from "./pages/Lesson72Intro";
import Lesson72 from "./pages/Lesson72";
import Lesson73Intro from "./pages/Lesson73Intro";
import Lesson73 from "./pages/Lesson73";
import Lesson81Intro from "./pages/Lesson81Intro";
import Lesson91Intro from "./pages/Lesson91Intro";
import Lesson101Intro from "./pages/Lesson101Intro";
import LessonIntro from "./pages/LessonIntro";
import Program from "./pages/Program";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/program" element={<Program />} />
          <Route path="/lesson-intro" element={<LessonIntro />} />
          <Route path="/lesson" element={<Index />} />
          <Route path="/lesson2-intro" element={<Lesson2Intro />} />
          <Route path="/lesson2" element={<Lesson2 />} />
            <Route path="/lesson3-intro" element={<Lesson3Intro />} />
            <Route path="/lesson3" element={<Lesson3 />} />
            <Route path="/lesson21-intro" element={<Lesson21Intro />} />
            <Route path="/lesson21" element={<Lesson21 />} />
            <Route path="/lesson22-intro" element={<Lesson22Intro />} />
            <Route path="/lesson22" element={<Lesson22 />} />
            <Route path="/lesson23-intro" element={<Lesson23Intro />} />
            <Route path="/lesson23" element={<Lesson23 />} />
            <Route path="/lesson24-intro" element={<Lesson24Intro />} />
            <Route path="/lesson24" element={<Lesson24 />} />
            <Route path="/lesson31-intro" element={<Lesson31Intro />} />
            <Route path="/lesson31" element={<Lesson31 />} />
            <Route path="/lesson32-intro" element={<Lesson32Intro />} />
            <Route path="/lesson32" element={<Lesson32 />} />
            <Route path="/lesson33-intro" element={<Lesson33Intro />} />
            <Route path="/lesson33" element={<Lesson33 />} />
            <Route path="/lesson41-intro" element={<Lesson41Intro />} />
            <Route path="/lesson41" element={<Lesson41 />} />
            <Route path="/lesson42-intro" element={<Lesson42Intro />} />
            <Route path="/lesson42" element={<Lesson42 />} />
            <Route path="/lesson43-intro" element={<Lesson43Intro />} />
            <Route path="/lesson43" element={<Lesson43 />} />
            <Route path="/lesson44-intro" element={<Lesson44Intro />} />
            <Route path="/lesson44" element={<Lesson44 />} />
            <Route path="/lesson45-intro" element={<Lesson45Intro />} />
            <Route path="/lesson45" element={<Lesson45 />} />
            <Route path="/lesson51-intro" element={<Lesson51Intro />} />
            <Route path="/lesson51" element={<Lesson51 />} />
            <Route path="/lesson52-intro" element={<Lesson52Intro />} />
            <Route path="/lesson52" element={<Lesson52 />} />
            <Route path="/lesson53-intro" element={<Lesson53Intro />} />
            <Route path="/lesson53" element={<Lesson53 />} />
            <Route path="/lesson54-intro" element={<Lesson54Intro />} />
            <Route path="/lesson54" element={<Lesson54 />} />
            <Route path="/lesson55-intro" element={<Lesson55Intro />} />
            <Route path="/lesson55" element={<Lesson55 />} />
            
            {/* Unit 6 - My Family */}
            <Route path="/lesson/6-1-intro" element={<Lesson61Intro />} />
            <Route path="/lesson/6-1" element={<Lesson61 />} />
            <Route path="/lesson/6-2-intro" element={<Lesson62Intro />} />
            <Route path="/lesson/6-2" element={<Lesson62 />} />
            <Route path="/lesson/6-3-intro" element={<Lesson63Intro />} />
            <Route path="/lesson/6-3" element={<Lesson63 />} />
            
            {/* Unit 7 - Food Fun */}
            <Route path="/lesson/7-1-intro" element={<Lesson71Intro />} />
            <Route path="/lesson/7-1" element={<Lesson71 />} />
            <Route path="/lesson/7-2-intro" element={<Lesson72Intro />} />
            <Route path="/lesson/7-2" element={<Lesson72 />} />
            <Route path="/lesson/7-3-intro" element={<Lesson73Intro />} />
            <Route path="/lesson/7-3" element={<Lesson73 />} />
            
            {/* Unit 8 - My Classroom */}
            <Route path="/lesson/8-1-intro" element={<Lesson81Intro />} />
            
            {/* Unit 9 - Weather & Clothes */}
            <Route path="/lesson/9-1-intro" element={<Lesson91Intro />} />
            
            {/* Unit 10 - My World Review */}
            <Route path="/lesson/10-1-intro" element={<Lesson101Intro />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
