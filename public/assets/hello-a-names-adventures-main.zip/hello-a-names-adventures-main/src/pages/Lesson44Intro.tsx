import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap } from "lucide-react";

export const Lesson44Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 4 • Lesson 4
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🦾 More Body Parts!
          </h1>
          <p className="text-xl text-muted-foreground">
            Learn about arms, legs, fingers, and toes
          </p>
        </div>

        {/* Lesson Preview Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">💪</div>
              <h3 className="font-bold">Arms</h3>
              <p className="text-sm text-muted-foreground">These are my arms</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🦵</div>
              <h3 className="font-bold">Legs</h3>
              <p className="text-sm text-muted-foreground">These are my legs</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">👆</div>
              <h3 className="font-bold">Fingers</h3>
              <p className="text-sm text-muted-foreground">These are my fingers</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🦶</div>
              <h3 className="font-bold">Toes</h3>
              <p className="text-sm text-muted-foreground">These are my toes</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Learn Today */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                What We'll Learn Today
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>New body parts: arms, legs, fingers, toes</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Sentences: "These are my arms/legs/fingers/toes"</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Phonics: Letter Ii /i/ (igloo, ink, insect)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Review: All previous body parts</span>
              </div>
            </CardContent>
          </Card>

          {/* Fun Activities & Games */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Fun Activities & Games
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Count your fingers game</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Wiggle your toes activity</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Move your arms dance</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Complete body puzzle</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Body parts memory game</span>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Lesson Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">25–30 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">20 interactive slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Language Focus:</span>
                <span className="font-medium">Extended body vocabulary</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Body Expert Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Key Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Key Vocabulary & Sentences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">New Body Parts:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>💪 Arms</span>
                    <AudioButton text="arms" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦵 Legs</span>
                    <AudioButton text="legs" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👆 Fingers</span>
                    <AudioButton text="fingers" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦶 Toes</span>
                    <AudioButton text="toes" />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Key Sentences:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"These are my arms."</span>
                    <AudioButton text="These are my arms" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"These are my legs."</span>
                    <AudioButton text="These are my legs" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teaching Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Interactive Movement:</strong> Have students show their arms, legs, fingers, and toes on camera. Make it fun with counting activities.
              </p>
              <p>
                <strong>Memory Building:</strong> Review previous body parts (head, eyes, nose, mouth, hands, feet) before introducing new ones.
              </p>
              <p>
                <strong>Counting Practice:</strong> Count fingers (1-10) and toes to reinforce numbers learned in previous units.
              </p>
              <p>
                <strong>Homework Suggestion:</strong> Draw a complete body diagram and label all 10 body parts learned in Unit 4.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson44")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Learn More Body Parts!
          </Button>
        </div>
      </div>
    </div>
  );
};