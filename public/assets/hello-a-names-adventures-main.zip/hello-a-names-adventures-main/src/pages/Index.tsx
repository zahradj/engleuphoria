import { useState } from "react";
import { ProgressBar } from "@/components/ProgressBar";
import { ActivityCard } from "@/components/ActivityCard";
import { DragDropActivity } from "@/components/DragDropActivity";
import { FillInTheGapActivity } from "@/components/FillInTheGapActivity";
import { MissingLetterActivity } from "@/components/MissingLetterActivity";
import { PhonicsActivity } from "@/components/PhonicsActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";
import { Button } from "@/components/ui/button";
import { Volume2, Hand, Sparkles } from "lucide-react";
import { AudioButton } from "@/components/AudioButton";
import { TranslationCard } from "@/components/TranslationCard";
import helloImage from "@/assets/hello.png";
import hiImage from "@/assets/hi.png";
import goodbyeImage from "@/assets/goodbye.png";
import nameDialogueImage from "@/assets/name-dialogue.png";
import spidermanSlide from "@/assets/spiderman-slide.png";
import spongebobSlide from "@/assets/spongebob-slide.png";
import appleCharacterLesson from "@/assets/apple-character-lesson.png";
import antCharacterLesson from "@/assets/ant-character-lesson.png";
import appleTextWord from "@/assets/apple-text-word.png";
import antTextWord from "@/assets/ant-text-word.png";
import appleImage from "@/assets/phonics-apple.png";
import antImage from "@/assets/phonics-ant.png";
import alligatorImage from "@/assets/phonics-alligator.png";
const TOTAL_SLIDES = 34;
const greetingWords = [{
  id: 'hello-img',
  content: helloImage,
  type: 'source' as const,
  matchId: 'hello-word',
  isImage: true
}, {
  id: 'hi-img',
  content: hiImage,
  type: 'source' as const,
  matchId: 'hi-word',
  isImage: true
}, {
  id: 'bye-img',
  content: goodbyeImage,
  type: 'source' as const,
  matchId: 'bye-word',
  isImage: true
}, {
  id: 'hello-word',
  content: 'Hello',
  type: 'target' as const
}, {
  id: 'hi-word',
  content: 'Hi',
  type: 'target' as const
}, {
  id: 'bye-word',
  content: 'Goodbye',
  type: 'target' as const
}];
const phonicsWords = [{
  word: 'apple',
  image: 'apple',
  hasLetter: true
}, {
  word: 'sun',
  image: 'sun',
  hasLetter: false
}, {
  word: 'ant',
  image: 'ant',
  hasLetter: true
}, {
  word: 'fish',
  image: 'fish',
  hasLetter: false
}, {
  word: 'alligator',
  image: 'alligator',
  hasLetter: true
}, {
  word: 'book',
  image: 'book',
  hasLetter: false
}];
const Index = () => {
  const [currentSlide, setCurrentSlide] = useState(1);
  const [showFireworks, setShowFireworks] = useState(false);
  const nextSlide = () => {
    if (currentSlide < TOTAL_SLIDES) {
      setCurrentSlide(prev => prev + 1);
    }
  };
  const previousSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(prev => prev - 1);
    }
  };

  const triggerFireworks = () => {
    setShowFireworks(true);
    setTimeout(() => setShowFireworks(false), 5000); // Extended duration
  };
  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return <ActivityCard title="🎵 Welcome to English!" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <div className="text-6xl animate-bounce">👋</div>
              <p className="text-xl">Let's start with a fun Hello song!</p>
              <div className="flex items-center gap-2">
                <Button className="bg-gradient-primary hover:shadow-button transition-all duration-300 text-lg font-semibold px-8 py-3" onClick={() => {/* Play song */}}>
                  <Volume2 className="mr-2 h-5 w-5" />
                  Play "Hello, Hello, How Are You?"
                </Button>
                <AudioButton text="Hello, Hello, How Are You?" className="text-white hover:bg-white/20" voice="child" pitch={1.4} />
              </div>
              <p className="text-sm text-muted-foreground">Wave your hand when you hear "hello"!</p>
            </div>
          </ActivityCard>;
      case 2:
        return <ActivityCard title="Greetings Song" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <div className="text-6xl animate-bounce">👋</div>
              <p className="text-xl">Watch this fun greetings song!</p>
              <div className="flex justify-center">
                <div className="w-full max-w-3xl">
                  <div className="relative aspect-video rounded-xl overflow-hidden shadow-lg">
                    <iframe src="https://www.youtube.com/embed/tVlcKp3bWH8" title="Greetings Learning Video" className="w-full h-full" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
                  </div>
                </div>
              </div>
            </div>
          </ActivityCard>;
      case 3:
        return <ActivityCard title="Learning Greetings" onNext={nextSlide}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div className="space-y-3">
                <img src={helloImage} alt="Hello" className="w-64 h-64 mx-auto" />
                <div className="flex items-center justify-center gap-2">
                  <p className="text-2xl font-bold text-primary">Hello</p>
                  <AudioButton text="Hello" variant="ghost" className="text-primary hover:bg-primary/20" />
                </div>
                <p className="text-muted-foreground">When you meet someone</p>
              </div>
              <div className="space-y-3">
                <img src={hiImage} alt="Hi" className="w-64 h-64 mx-auto" />
                <div className="flex items-center justify-center gap-2">
                  <p className="text-2xl font-bold text-accent">Hi</p>
                  <AudioButton text="Hi" variant="ghost" className="text-accent hover:bg-accent/20" />
                </div>
                <p className="text-muted-foreground">Friendly greeting</p>
              </div>
              <div className="space-y-3">
                <img src={goodbyeImage} alt="Bye" className="w-64 h-64 mx-auto" />
                <div className="flex items-center justify-center gap-2">
                  <p className="text-2xl font-bold text-secondary">Goodbye</p>
                  <AudioButton text="Goodbye" variant="ghost" className="text-secondary hover:bg-secondary/20" />
                </div>
                <p className="text-muted-foreground">When you leave</p>
              </div>
            </div>
          </ActivityCard>;
      case 4:
        return <ActivityCard title="Speaking Practice" showNext={false}>
            <SpeakingActivity prompt="Say Hello with a wave!" expectedResponse="Hello! 👋" onComplete={nextSlide} />
          </ActivityCard>;
      case 5:
        return <ActivityCard title="Meet Letter Aa" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <div className="bg-gradient-primary p-8 rounded-2xl inline-block relative">
                <span className="text-6xl font-bold text-white">Aa</span>
                <AudioButton audioSrc="/audio/alphasounds-a-2.mp3" className="absolute -top-2 -right-2 bg-white/20 hover:bg-white/30" variant="ghost" />
              </div>
              <p className="text-xl">The letter "A" makes the "ah" sound like in "apple"</p>
              <div className="flex justify-center gap-4">
                <img src={appleCharacterLesson} alt="Apple character" className="w-32 h-32" />
                <img src={antCharacterLesson} alt="Ant character" className="w-32 h-32" />
              </div>
            </div>
          </ActivityCard>;
      case 6:
        return <ActivityCard title="Greetings Practice Video" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <div className="text-4xl">📹</div>
              <p className="text-xl">Watch this greetings practice video!</p>
              <div className="flex justify-center">
                <div className="w-full max-w-3xl">
                  <div className="relative aspect-video rounded-xl overflow-hidden shadow-lg">
                    <iframe src="https://www.youtube.com/embed/6tlydXoNC2Q" title="Greetings Practice Video" className="w-full h-full" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
                  </div>
                </div>
              </div>
            </div>
          </ActivityCard>;
      case 7:
        return <ActivityCard title="Meet Letter Aa" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <div className="bg-gradient-primary p-8 rounded-2xl inline-block">
                <span className="text-6xl font-bold text-white">Aa</span>
              </div>
              <p className="text-xl">The letter "A" makes the "ah" sound like in "apple"</p>
              <div className="flex justify-center gap-8">
                <div className="flex flex-col items-center space-y-3">
                  <img src={appleCharacterLesson} alt="Apple character" className="w-32 h-32" />
                  <img src={appleTextWord} alt="Apple word" className="w-32 h-12" />
                </div>
                <div className="flex flex-col items-center space-y-3">
                  <img src={antCharacterLesson} alt="Ant character" className="w-32 h-32" />
                  <img src={antTextWord} alt="Ant word" className="w-24 h-12" />
                </div>
              </div>
            </div>
          </ActivityCard>;
      case 8:
        return <ActivityCard title="Fill in the Missing Letters!" showNext={false}>
            <FillInTheGapActivity 
              title="What letter is missing?"
              words={[
                { word: "apple", imageSrc: appleImage, missingLetter: "a", missingPosition: 0 },
                { word: "ant", imageSrc: antImage, missingLetter: "a", missingPosition: 0 },
                { word: "alligator", imageSrc: alligatorImage, missingLetter: "a", missingPosition: 0 }
              ]}
              onComplete={nextSlide}
            />
          </ActivityCard>;
      case 9:
        return <ActivityCard title="Phonics Practice" showNext={false}>
            <PhonicsActivity 
              letter="a"
              words={phonicsWords.slice(0, 3)} 
              onComplete={nextSlide} 
            />
          </ActivityCard>;
      case 10:
        return <ActivityCard title="Missing Letter Challenge" showNext={false}>
            <MissingLetterActivity 
              word="apple"
              imageSrc={appleImage}
              missingLetter="a"
              missingPosition={0}
              onComplete={nextSlide} 
            />
          </ActivityCard>;
      case 11:
        return <ActivityCard title="Spongebob Says Hello!" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <img src={spongebobSlide} alt="Spongebob introduces himself" className="w-full max-w-2xl mx-auto rounded-xl shadow-lg" />
                <div className="flex justify-center mt-4">
                  <AudioButton text="What is your name?" className="text-primary hover:bg-primary/20" />
                </div>
                <div className="flex justify-center">
                  <audio controls className="w-80">
                    <source src="/audio/spongebob.mp3" type="audio/mp3" />
                    Your browser does not support the audio element.
                  </audio>
                </div>
                <p className="text-lg font-medium">Listen to Spongebob introduce himself!</p>
              </div>
            </ActivityCard>;
      case 12:
        return <ActivityCard title="Spiderman Says Hello!" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <img src={spidermanSlide} alt="Spiderman introduces himself" className="w-full max-w-2xl mx-auto rounded-xl shadow-lg" />
                <div className="flex justify-center mt-4 space-x-4">
                  <AudioButton text="What is your name?" className="text-primary hover:bg-primary/20" voice="female" pitch={1.3} />
                  <AudioButton audioSrc="/audio/my_name_is_spiderman-2.wav" className="text-red-600 hover:bg-red-100" playbackRate={0.8} />
                </div>
                
                <p className="text-lg font-medium">Listen to Spiderman introduce himself!</p>
              </div>
            </ActivityCard>;
      case 11:
        return <ActivityCard title="Spongebob Says Hello!" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <img src={spongebobSlide} alt="Spongebob introduces himself" className="w-full max-w-2xl mx-auto rounded-xl shadow-lg" />
                <div className="flex justify-center mt-4">
                  <AudioButton text="What is your name?" className="text-primary hover:bg-primary/20" />
                </div>
                <div className="flex justify-center">
                  <audio controls className="w-80">
                    <source src="/audio/spongebob.mp3" type="audio/mp3" />
                    Your browser does not support the audio element.
                  </audio>
                </div>
                <p className="text-lg font-medium">Listen to Spongebob introduce himself!</p>
              </div>
            </ActivityCard>;
      case 13:
        return <ActivityCard title="What Is Your Name? ♫" onNext={nextSlide} className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
            <div className="space-y-6">
              <div className="text-center space-y-4">
                <p className="text-lg font-medium text-purple-800">
                  Let's sing along with Bobby, Judy, Jacky, and Sally!
                </p>
                <AudioButton text="Hello, hello. What is your name?" className="mx-auto block bg-purple-100 hover:bg-purple-200" voice="male" pitch={0.9} />
              </div>
              
              <div className="bg-white/80 p-6 rounded-xl border border-purple-200">
                <h3 className="text-lg font-semibold text-purple-800 mb-4">Song Lyrics:</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center space-x-2">
                    <AudioButton text="Hello, hello. What is your name?" variant="ghost" size="sm" />
                    <span>Hello, hello. What is your name?</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <AudioButton text="My name is Bobby! What is your name?" variant="ghost" size="sm" voice="male" pitch={0.8} />
                    <span>My name is Bobby! What is your name?</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <AudioButton text="My name is Judy! Goodbye." variant="ghost" size="sm" voice="female" pitch={1.3} />
                    <span>My name is Judy! Goodbye.</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-blue-100 rounded-lg">
                  <p className="font-semibold text-blue-800">Bobby</p>
                  <AudioButton text="My name is Bobby" variant="ghost" size="sm" />
                </div>
                <div className="text-center p-4 bg-pink-100 rounded-lg">
                  <p className="font-semibold text-pink-800">Judy</p>
                  <AudioButton text="My name is Judy" variant="ghost" size="sm" />
                </div>
                <div className="text-center p-4 bg-green-100 rounded-lg">
                  <p className="font-semibold text-green-800">Jacky</p>
                  <AudioButton text="My name is Jacky" variant="ghost" size="sm" />
                </div>
                <div className="text-center p-4 bg-yellow-100 rounded-lg">
                  <p className="font-semibold text-yellow-800">Sally</p>
                  <AudioButton text="My name is Sally" variant="ghost" size="sm" />
                </div>
              </div>
            </div>
          </ActivityCard>;
      case 14:
        return <ActivityCard title="Nice to Meet You!" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <img 
                  src="/images/Apple_A4_Landscape.gif" 
                  alt="Nice to meet you animation"
                  className="w-full max-w-2xl mx-auto rounded-xl shadow-lg"
                />
                <div className="flex flex-col items-center space-y-4">
                  <h2 className="text-2xl font-bold text-primary">Nice to meet you!</h2>
                  <AudioButton 
                    text="Nice to meet you!" 
                    className="text-primary hover:bg-primary/20" 
                    voice="female" 
                    pitch={1.2}
                    size="default"
                  />
                </div>
              </div>
            </ActivityCard>;
      case 15:
        return <ActivityCard title="What's Your Name?" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <div className="space-y-4">
                  <p className="text-xl font-semibold">Learn to ask and answer:</p>
                  <div className="space-y-4">
                    <TranslationCard english="What's your name?" french="Comment tu t'appelles ?" />
                    <TranslationCard english="My name is..." french="Je m'appelle..." />
                  </div>
                </div>
              </div>
            </ActivityCard>;
      case 26:
        return <ActivityCard title="Speaking Practice" showNext={false}>
              <SpeakingActivity prompt="What's your name?" expectedResponse="My name is [your name]" onComplete={nextSlide} />
            </ActivityCard>;
      case 15:
        return <ActivityCard title="Interactive Matching" showNext={false}>
              <DragDropActivity title="Complete the sentences" items={[{
            id: 'question',
            content: "What's your name?",
            type: 'source' as const,
            matchId: 'answer'
          }, {
            id: 'intro',
            content: "Hello, I'm",
            type: 'source' as const,
            matchId: 'name'
          }, {
            id: 'answer',
            content: "My name is ___",
            type: 'target' as const
          }, {
            id: 'name',
            content: "nice to meet you!",
            type: 'target' as const
          }]} onComplete={nextSlide} />
            </ActivityCard>;
      case 16:
        return <ActivityCard title="Sound Recognition Game" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <div className="bg-gradient-primary p-6 rounded-2xl inline-block">
                  <span className="text-4xl font-bold text-white">Listen carefully!</span>
                </div>
                <p className="text-xl">Clap when you hear the "A" sound!</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {['Apple', 'Ball', 'Ant', 'Cat', 'Alligator', 'Book'].map((word, index) => <Button key={word} variant="outline" className="p-4 text-lg font-semibold border-2 hover:bg-primary/10" onClick={() => {}}>
                      <div className="flex items-center gap-2">
                        {word}
                        <AudioButton text={word} variant="ghost" />
                      </div>
                    </Button>)}
                </div>
              </div>
            </ActivityCard>;
      case 17:
        return <ActivityCard title="Interactive Matching" showNext={false}>
              <DragDropActivity title="Complete the sentences" items={[{
            id: 'question',
            content: "What's your name?",
            type: 'source' as const,
            matchId: 'answer'
          }, {
            id: 'intro',
            content: "Hello, I'm",
            type: 'source' as const,
            matchId: 'name'
          }, {
            id: 'answer',
            content: "My name is ___",
            type: 'target' as const
          }, {
            id: 'name',
            content: "nice to meet you!",
            type: 'target' as const
          }]} onComplete={nextSlide} />
            </ActivityCard>;
      case 19:
        return <ActivityCard title="Listening Game" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <p className="text-xl font-semibold">Listen and choose the correct picture!</p>
                <div className="bg-gradient-warm p-4 rounded-xl">
                  <div className="flex items-center justify-center gap-2">
                    <AudioButton text="Hello, I'm Anna. Nice to meet you!" />
                    <p className="text-lg text-white">"Hello, I'm Anna. Nice to meet you!"</p>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <Button variant="outline" className="p-4 h-24">
                    <span className="text-2xl">👋 Anna</span>
                  </Button>
                  <Button variant="outline" className="p-4 h-24">
                    <span className="text-2xl">👋 Tom</span>
                  </Button>
                  <Button variant="outline" className="p-4 h-24">
                    <span className="text-2xl">👋 Sara</span>
                  </Button>
                </div>
              </div>
            </ActivityCard>;
      case 17:
        return <ActivityCard title="Speaking Practice" showNext={false}>
              <SpeakingActivity prompt="Introduce yourself: Hello, I am..." expectedResponse="Hello, I am [your name]" onComplete={nextSlide} />
            </ActivityCard>;
      case 18:
        return <ActivityCard title="Grab & Drag Names" onNext={nextSlide}>
              <DragDropActivity title="Drag names to the correct faces" items={[{
            id: 'tom-face',
            content: '👦 Face 1',
            type: 'source' as const,
            matchId: 'tom-name'
          }, {
            id: 'anna-face',
            content: '👧 Face 2',
            type: 'source' as const,
            matchId: 'anna-name'
          }, {
            id: 'max-face',
            content: '🧑 Face 3',
            type: 'source' as const,
            matchId: 'max-name'
          }, {
            id: 'tom-name',
            content: 'Tom',
            type: 'target' as const
          }, {
            id: 'anna-name',
            content: 'Anna',
            type: 'target' as const
          }, {
            id: 'max-name',
            content: 'Max',
            type: 'target' as const
          }]} onComplete={nextSlide} />
            </ActivityCard>;
      case 21:
        return <ActivityCard title="Listening Game" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <p className="text-xl font-semibold">Listen and choose the correct picture!</p>
                <div className="bg-gradient-warm p-4 rounded-xl">
                  <div className="flex items-center justify-center gap-2">
                    <AudioButton text="Hello, I'm Anna. Nice to meet you!" />
                    <p className="text-lg text-white">"Hello, I'm Anna. Nice to meet you!"</p>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <Button variant="outline" className="p-4 h-24">
                    <span className="text-2xl">👋 Anna</span>
                  </Button>
                  <Button variant="outline" className="p-4 h-24">
                    <span className="text-2xl">👋 Tom</span>
                  </Button>
                  <Button variant="outline" className="p-4 h-24">
                    <span className="text-2xl">👋 Sara</span>
                  </Button>
                </div>
              </div>
            </ActivityCard>;
      case 20:
        return <ActivityCard title="Yes/No Quick Quiz" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <p className="text-xl font-semibold">Answer Yes or No!</p>
                <div className="space-y-4">
                  <div className="bg-gradient-card p-4 rounded-xl">
                    <p className="text-lg mb-4">Can I say "Hello" when I leave?</p>
                    <div className="flex gap-4 justify-center">
                      <Button variant="outline" className="px-8 py-2 text-lg">Yes</Button>
                      <Button className="px-8 py-2 text-lg bg-gradient-primary">No!</Button>
                    </div>
                  </div>
                  <div className="bg-gradient-card p-4 rounded-xl">
                    <p className="text-lg mb-4">Do I say "Bye" when I meet someone?</p>
                    <div className="flex gap-4 justify-center">
                      <Button className="px-8 py-2 text-lg bg-gradient-primary">No!</Button>
                      <Button variant="outline" className="px-8 py-2 text-lg">Yes</Button>
                    </div>
                  </div>
                </div>
              </div>
            </ActivityCard>;
      case 21:
        return <ActivityCard title="Dialogue Practice" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <p className="text-xl font-semibold">Practice this dialogue:</p>
                <div className="bg-gradient-card p-6 rounded-xl space-y-4">
                  <div className="flex items-center justify-between p-3 bg-primary/10 rounded-lg">
                    <p className="text-lg">"Hello, I'm Max."</p>
                    <AudioButton text="Hello, I'm Max" />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-accent/10 rounded-lg">
                    <p className="text-lg">"Hi Max, I'm Sara."</p>
                    <AudioButton text="Hi Max, I'm Sara" />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg">
                    <p className="text-lg">"Nice to meet you!"</p>
                    <AudioButton text="Nice to meet you" />
                  </div>
                </div>
              </div>
            </ActivityCard>;
      case 22:
        return <ActivityCard title="Match Words to Pictures!" showNext={false}>
              <DragDropActivity 
                title="Drag the words to match their pictures" 
                items={[
                  {
                    id: 'apple-word',
                    content: 'Apple',
                    type: 'source' as const,
                    matchId: 'apple-pic'
                  },
                  {
                    id: 'ant-word',
                    content: 'Ant',
                    type: 'source' as const,
                    matchId: 'ant-pic'
                  },
                  {
                    id: 'alligator-word',
                    content: 'Alligator',
                    type: 'source' as const,
                    matchId: 'alligator-pic'
                  },
                  {
                    id: 'apple-pic',
                    content: appleImage,
                    type: 'target' as const,
                    isImage: true
                  },
                  {
                    id: 'ant-pic',
                    content: antImage,
                    type: 'target' as const,
                    isImage: true
                  },
                  {
                    id: 'alligator-pic',
                    content: alligatorImage,
                    type: 'target' as const,
                    isImage: true
                  }
                ]} 
                onComplete={nextSlide} 
              />
            </ActivityCard>;
      case 23:
        return <ActivityCard title="Mini Story" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <p className="text-xl font-semibold">Read the story together!</p>
                <div className="bg-gradient-card p-6 rounded-xl space-y-4">
                  <div className="flex items-center justify-between p-3 bg-primary/10 rounded-lg">
                    <p className="text-lg">"Hi, I'm Sam."</p>
                    <AudioButton text="Hi, I'm Sam" />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-accent/10 rounded-lg">
                    <p className="text-lg">"Hello, I'm Mia."</p>
                    <AudioButton text="Hello, I'm Mia" />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-secondary/10 rounded-lg">
                    <p className="text-lg">"Goodbye!"</p>
                    <AudioButton text="Goodbye" />
                  </div>
                </div>
                <p className="text-muted-foreground">Practice reading each line aloud!</p>
              </div>
            </ActivityCard>;
      case 24:
        return <ActivityCard title="Find the Greeting" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <p className="text-xl font-semibold">Click on the correct greeting word!</p>
                <div className="bg-gradient-warm p-6 rounded-xl">
                  <img src={helloImage} alt="Hello scene" className="w-40 h-40 mx-auto mb-4" />
                  <p className="text-white text-lg">What should you say?</p>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <Button className="p-4 text-lg bg-gradient-primary hover:shadow-button">
                    Hello
                  </Button>
                  <Button variant="outline" className="p-4 text-lg">
                    Goodbye
                  </Button>
                  <Button variant="outline" className="p-4 text-lg">
                    Thanks
                  </Button>
                </div>
              </div>
             </ActivityCard>;
      case 25:
        return <ActivityCard title="Pair Practice" showNext={false}>
              <SpeakingActivity prompt="Practice with a partner: Ask and answer names" expectedResponse="What's your name? My name is..." onComplete={nextSlide} />
            </ActivityCard>;
      case 26:
        return <ActivityCard title="Letter A Review" onNext={nextSlide}>
              <div className="text-center space-y-6">
                <div className="bg-gradient-primary p-8 rounded-2xl inline-block">
                  <span className="text-6xl font-bold text-white">Aa</span>
                </div>
                <p className="text-xl">Let's review what we learned about the letter A!</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <img src={appleImage} alt="Apple" className="w-32 h-32 mx-auto" />
                    <p className="text-lg font-semibold">Apple</p>
                    <AudioButton text="Apple" />
                  </div>
                  <div className="space-y-3">
                    <img src={antImage} alt="Ant" className="w-32 h-32 mx-auto" />
                    <p className="text-lg font-semibold">Ant</p>
                    <AudioButton text="Ant" />
                  </div>
                  <div className="space-y-3">
                    <img src={alligatorImage} alt="Alligator" className="w-32 h-32 mx-auto" />
                    <p className="text-lg font-semibold">Alligator</p>
                    <AudioButton text="Alligator" />
                  </div>
                </div>
              </div>
            </ActivityCard>;
      case 27:
        return <ActivityCard title="Final Challenge" showNext={false}>
            <DragDropActivity 
              title="Complete the conversation" 
              items={[
                {
                  id: 'hello-greeting',
                  content: 'Hello!',
                  type: 'source' as const,
                  matchId: 'hello-response'
                },
                {
                  id: 'name-question',
                  content: "What's your name?",
                  type: 'source' as const,
                  matchId: 'name-answer'
                },
                {
                  id: 'hello-response',
                  content: 'Hi there!',
                  type: 'target' as const
                },
                {
                  id: 'name-answer',
                  content: 'My name is...',
                  type: 'target' as const
                }
              ]} 
              onComplete={nextSlide} 
            />
          </ActivityCard>;
      case 28:
        return <ActivityCard title="Letter Recognition" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <p className="text-xl font-semibold">Can you find all the letter A's?</p>
              <div className="bg-gradient-warm p-6 rounded-xl">
                <div className="text-4xl font-bold text-white space-x-4">
                  A B C A D E A F G A
                </div>
              </div>
              <p className="text-lg">Count how many "A"s you can see!</p>
            </div>
          </ActivityCard>;
      case 29:
        return <ActivityCard title="Memory Game" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <p className="text-xl font-semibold">Remember these greetings!</p>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-primary/10 p-4 rounded-lg">
                  <p className="text-lg font-bold">Hello</p>
                  <p className="text-sm text-muted-foreground">When you meet</p>
                </div>
                <div className="bg-accent/10 p-4 rounded-lg">
                  <p className="text-lg font-bold">Goodbye</p>
                  <p className="text-sm text-muted-foreground">When you leave</p>
                </div>
              </div>
            </div>
          </ActivityCard>;
      case 30:
        return <ActivityCard title="Sound Practice" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <div className="bg-gradient-primary p-6 rounded-2xl inline-block">
                <span className="text-4xl font-bold text-white">/a/ sound</span>
              </div>
              <p className="text-xl">Practice saying these words with the /a/ sound:</p>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <img src={appleImage} alt="Apple" className="w-24 h-24 mx-auto" />
                  <AudioButton text="Apple" />
                </div>
                <div className="space-y-2">
                  <img src={antImage} alt="Ant" className="w-24 h-24 mx-auto" />
                  <AudioButton text="Ant" />
                </div>
                <div className="space-y-2">
                  <img src={alligatorImage} alt="Alligator" className="w-24 h-24 mx-auto" />
                  <AudioButton text="Alligator" />
                </div>
              </div>
            </div>
          </ActivityCard>;
      case 31:
        return <ActivityCard title="Quick Review" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <p className="text-xl font-semibold">What did we learn today?</p>
              <div className="space-y-4">
                <div className="bg-gradient-card p-4 rounded-xl">
                  <p className="text-lg">✓ How to say Hello and Goodbye</p>
                </div>
                <div className="bg-gradient-card p-4 rounded-xl">
                  <p className="text-lg">✓ How to ask "What's your name?"</p>
                </div>
                <div className="bg-gradient-card p-4 rounded-xl">
                  <p className="text-lg">✓ The letter A and its sound</p>
                </div>
              </div>
            </div>
          </ActivityCard>;
      case 32:
        return <ActivityCard title="Celebration Time!" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <div className="text-6xl animate-bounce">🎉</div>
              <p className="text-2xl font-bold text-primary">Great job!</p>
              <p className="text-lg">You've learned so much today!</p>
              <Button 
                onClick={triggerFireworks}
                className="bg-gradient-primary hover:shadow-button transition-all duration-300"
              >
                <Sparkles className="mr-2 h-5 w-5" />
                Celebrate!
              </Button>
            </div>
          </ActivityCard>;
      case 33:
        return <ActivityCard title="What's Next?" onNext={nextSlide}>
            <div className="text-center space-y-6">
              <p className="text-xl font-semibold">Ready for your next adventure?</p>
              <div className="bg-gradient-warm p-6 rounded-xl text-white">
                <p className="text-lg">Next lesson: Letter B and more greetings!</p>
              </div>
              <p className="text-muted-foreground">Keep practicing what you learned today!</p>
            </div>
          </ActivityCard>;
      case 34:
        return <BadgeReward title="Congratulations!" description="You've completed Lesson 1.1 - Greetings & Names!" badgeName="Hello Explorer 🏅" onContinue={() => setCurrentSlide(1)} />;
      default:
        return <ActivityCard title={`Activity ${currentSlide}`} onNext={nextSlide}>
            <div className="text-center space-y-4">
              <p className="text-lg">More activities coming soon!</p>
              <p className="text-muted-foreground">
                This would contain slide {currentSlide} content based on the lesson plan.
              </p>
            </div>
          </ActivityCard>;
    }
  };
  return <div className="min-h-screen bg-background p-4">
      <FloatingLogo />
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Fun Header with animated elements */}
        
        {/* Balloon Celebration Button */}
        <div className="fixed top-4 right-4 z-50">
          <Button
            onClick={triggerFireworks}
            size="lg"
            className="bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 animate-pulse"
          >
            <Sparkles className="mr-2 h-5 w-5 animate-spin" />
            🎈 Balloon Party! 🎉
          </Button>
        </div>

        {/* Balloon Celebration Effect */}
        {showFireworks && (
          <div className="fixed inset-0 z-40 pointer-events-none overflow-hidden">
            {/* Flying balloons */}
            {[...Array(12)].map((_, i) => (
              <div
                key={`balloon-${i}`}
                className="absolute text-6xl animate-bounce"
                style={{
                  left: `${5 + i * 8}%`,
                  bottom: '-10%',
                  animation: `balloon-float-${i % 3} ${3 + Math.random() * 2}s ease-out forwards`,
                  animationDelay: `${i * 0.2}s`
                }}
              >
                {['🎈', '🎈', '🎈', '🎈', '🎈', '🎈'][i % 6]}
              </div>
            ))}

            {/* Confetti shower */}
            {[...Array(30)].map((_, i) => (
              <div
                key={`confetti-${i}`}
                className="absolute w-3 h-3 rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: '-10px',
                  backgroundColor: `hsl(${Math.random() * 360}, 70%, 60%)`,
                  animation: `confetti-fall ${2 + Math.random() * 3}s linear forwards`,
                  animationDelay: `${Math.random() * 2}s`
                }}
              />
            ))}

            {/* Floating stars */}
            {[...Array(15)].map((_, i) => (
              <div
                key={`star-${i}`}
                className="absolute text-4xl animate-spin"
                style={{
                  left: `${Math.random() * 90 + 5}%`,
                  top: `${Math.random() * 80 + 10}%`,
                  animation: `star-twinkle ${1 + Math.random() * 2}s ease-in-out infinite`,
                  animationDelay: `${Math.random() * 2}s`
                }}
              >
                ⭐
              </div>
            ))}

            {/* Success message */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center animate-bounce">
              <div className="bg-gradient-to-r from-blue-400 to-green-400 text-white px-8 py-4 rounded-full shadow-2xl">
                <div className="text-4xl font-bold font-fredoka">🌟 FANTASTIC! 🌟</div>
                <div className="text-lg">Keep up the great work!</div>
              </div>
            </div>

            {/* Dancing emojis in corners */}
            <div className="absolute top-8 left-8 text-5xl animate-bounce">🎊</div>
            <div className="absolute top-8 right-8 text-5xl animate-pulse">🎉</div>
            <div className="absolute bottom-8 left-8 text-5xl animate-spin">✨</div>
            <div className="absolute bottom-8 right-8 text-5xl animate-bounce">🌟</div>
          </div>
        )}
        {/* Enhanced Progress Bar */}
        <ProgressBar current={currentSlide} total={TOTAL_SLIDES} className="bg-white/50 p-6 rounded-2xl border-2 border-primary/20 shadow-soft" />
        
        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button onClick={previousSlide} disabled={currentSlide === 1} variant="outline" className="flex items-center gap-2">
            ← Back
          </Button>
          <div className="text-sm text-muted-foreground">
            Slide {currentSlide} of {TOTAL_SLIDES}
          </div>
          <div className="w-20"></div> {/* Spacer for centering */}
        </div>
        
        {/* Main Content */}
        <div className="flex justify-center">
          <div className="w-full max-w-3xl">
            {renderSlide()}
          </div>
        </div>
        
        {/* Learning Objectives */}
        {currentSlide === 1 && <div className="bg-gradient-card p-6 rounded-xl border border-border/50">
            <h3 className="font-semibold mb-3">🎯 Learning Objectives:</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Say basic greetings (Hello, Hi, Bye)</li>
              <li>• Ask and answer names: "What's your name? My name is ___"</li>
              <li>• Recognize and pronounce the sounds of Aa (phonics)</li>
            </ul>
          </div>}
      </div>
    </div>;
};
export default Index;