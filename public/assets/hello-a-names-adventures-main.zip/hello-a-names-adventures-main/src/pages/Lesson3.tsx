import { useState } from "react";
import { ProgressBar } from "@/components/ProgressBar";
import { ActivityCard } from "@/components/ActivityCard";
import { DragDropActivity } from "@/components/DragDropActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AudioButton } from "@/components/AudioButton";

const TOTAL_SLIDES = 20;

const Lesson3 = () => {
  const [currentSlide, setCurrentSlide] = useState(1);
  const [wheelResult, setWheelResult] = useState("");
  const [bingoClicked, setBingoClicked] = useState<string[]>([]);

  const nextSlide = () => {
    if (currentSlide < TOTAL_SLIDES) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const previousSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const greetingItems = [
    { id: 'hello-word', content: 'HELLO', type: 'source' as const, matchId: 'hello-face' },
    { id: 'hi-word', content: 'HI', type: 'source' as const, matchId: 'hi-face' },
    { id: 'bye-word', content: 'BYE', type: 'source' as const, matchId: 'bye-face' },
    { id: 'hello-face', content: '😊 Happy Face', type: 'target' as const },
    { id: 'hi-face', content: '👋 Waving Face', type: 'target' as const },
    { id: 'bye-face', content: '😢 Sad Face', type: 'target' as const }
  ];

  const spinWheel = (options: string[]) => {
    const randomIndex = Math.floor(Math.random() * options.length);
    setWheelResult(options[randomIndex]);
  };

  const toggleBingo = (item: string) => {
    setBingoClicked(prev => 
      prev.includes(item) 
        ? prev.filter(i => i !== item)
        : [...prev, item]
    );
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return <ActivityCard title="Unit 1 Review! 🎉" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="text-8xl animate-bounce-gentle">🎭</div>
            <h2 className="text-4xl font-bold font-fredoka rainbow-text">
              Let's Review Everything!
            </h2>
            <div className="bg-gradient-accent p-8 rounded-3xl text-white">
              <h3 className="text-2xl font-bold mb-4">Welcome Back, Star Student!</h3>
              <p className="text-xl">Today we'll review all your amazing learning!</p>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-xl border-2 border-primary">
                <div className="text-3xl mb-2">👋</div>
                <p className="font-semibold">Greetings</p>
              </div>
              <div className="bg-white p-4 rounded-xl border-2 border-success">
                <div className="text-3xl mb-2">🔤</div>
                <p className="font-semibold">Letters A-B</p>
              </div>
              <div className="bg-white p-4 rounded-xl border-2 border-accent">
                <div className="text-3xl mb-2">🎭</div>
                <p className="font-semibold">Role-Play</p>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 2:
        return <ActivityCard title="Quick Vocabulary Flashback! 📚" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Click each greeting to hear it!</h3>
            <div className="grid grid-cols-3 gap-6">
              <Card className="p-6 hover:scale-110 transition-transform cursor-pointer bg-gradient-primary text-white">
                <div className="text-5xl mb-4">👋</div>
                <h4 className="text-2xl font-bold mb-2">HELLO</h4>
                <AudioButton text="Hello" className="bg-white text-primary" />
              </Card>
              <Card className="p-6 hover:scale-110 transition-transform cursor-pointer bg-gradient-success text-white">
                <div className="text-5xl mb-4">👋</div>
                <h4 className="text-2xl font-bold mb-2">HI</h4>
                <AudioButton text="Hi" className="bg-white text-success" />
              </Card>
              <Card className="p-6 hover:scale-110 transition-transform cursor-pointer bg-gradient-accent text-white">
                <div className="text-5xl mb-4">👋</div>
                <h4 className="text-2xl font-bold mb-2">BYE</h4>
                <AudioButton text="Bye" className="bg-white text-accent" />
              </Card>
            </div>
            <p className="text-lg font-medium text-primary">Great! You remember all the greetings!</p>
          </div>
        </ActivityCard>;

      case 3:
        return <ActivityCard title="Phonics Warm-Up: A + B Chant! 🎵" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Let's chant our letters with clapping!</h3>
            <div className="grid grid-cols-2 gap-8">
              <div className="bg-gradient-primary p-8 rounded-3xl text-white">
                <div className="text-9xl mb-4">A</div>
                <h4 className="text-3xl font-bold mb-4">A is for Apple!</h4>
                <div className="text-5xl mb-4">🍎</div>
                <AudioButton text="A is for Apple" className="bg-white text-primary" />
              </div>
              <div className="bg-gradient-success p-8 rounded-3xl text-white">
                <div className="text-9xl mb-4">B</div>
                <h4 className="text-3xl font-bold mb-4">B is for Ball!</h4>
                <div className="text-5xl mb-4">⚽</div>
                <AudioButton audioSrc="/audio/alphasounds-b.mp3" className="bg-white text-success" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-2xl border-4 border-accent">
              <p className="text-2xl font-bold text-accent">👏 A-B-A-B! Clap with me! 👏</p>
            </div>
          </div>
        </ActivityCard>;

      case 4:
        return <ActivityCard title="Flashcard Game! 🎮" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Tap each card to hear the greeting!</h3>
            <div className="grid grid-cols-1 gap-6 max-w-md mx-auto">
              <Button
                size="fun"
                className="h-24 text-2xl font-bold bg-gradient-primary hover:scale-105 transition-transform"
                onClick={() => console.log("Play Hello sound")}
              >
                <div className="text-center">
                  <div className="text-4xl mb-2">👋</div>
                  <div>HELLO</div>
                </div>
              </Button>
              <Button
                size="fun" 
                className="h-24 text-2xl font-bold bg-gradient-success hover:scale-105 transition-transform"
                onClick={() => console.log("Play Hi sound")}
              >
                <div className="text-center">
                  <div className="text-4xl mb-2">👋</div>
                  <div>HI</div>
                </div>
              </Button>
              <Button
                size="fun"
                className="h-24 text-2xl font-bold bg-gradient-accent hover:scale-105 transition-transform"
                onClick={() => console.log("Play Bye sound")}
              >
                <div className="text-center">
                  <div className="text-4xl mb-2">👋</div>
                  <div>BYE</div>
                </div>
              </Button>
            </div>
          </div>
        </ActivityCard>;

      case 5:
        return <ActivityCard title="Drag & Drop Faces! 😊" showNext={false}>
          <DragDropActivity
            title="Match each greeting to the right cartoon character!"
            items={greetingItems}
            onComplete={nextSlide}
          />
        </ActivityCard>;

      case 6:
        return <ActivityCard title="Quick Choice Quiz! 🤔" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Which one says "Bye"?</h3>
            <div className="grid grid-cols-3 gap-6">
              <Button
                variant="outline"
                className="h-32 text-xl border-2 hover:scale-105 transition-transform"
                onClick={() => console.log("Wrong choice")}
              >
                <div className="text-center">
                  <div className="text-4xl mb-2">😊</div>
                  <div>HELLO</div>
                </div>
              </Button>
              <Button
                variant="outline"
                className="h-32 text-xl border-2 hover:scale-105 transition-transform"
                onClick={() => console.log("Wrong choice")}
              >
                <div className="text-center">
                  <div className="text-4xl mb-2">👋</div>
                  <div>HI</div>
                </div>
              </Button>
              <Button
                size="fun"
                className="h-32 text-xl bg-gradient-success hover:scale-105 transition-transform"
                onClick={nextSlide}
              >
                <div className="text-center">
                  <div className="text-4xl mb-2">😢</div>
                  <div>BYE</div>
                </div>
              </Button>
            </div>
            <p className="text-lg font-medium">Click the correct answer!</p>
          </div>
        </ActivityCard>;

      case 7:
        return <ActivityCard title="Speaking Drill! 🎤" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Repeat each greeting after me!</h3>
            <div className="space-y-6">
              <Card className="p-6 bg-gradient-primary text-white">
                <div className="text-5xl mb-4">👋</div>
                <h4 className="text-3xl font-bold mb-4">HELLO</h4>
                <AudioButton text="Hello" className="bg-white text-primary mb-4" />
                <div className="bg-white/20 p-4 rounded-xl">
                  <p className="text-lg">🎤 Your turn: Say "Hello"</p>
                </div>
              </Card>
              <Card className="p-6 bg-gradient-success text-white">
                <div className="text-5xl mb-4">👋</div>
                <h4 className="text-3xl font-bold mb-4">HI</h4>
                <AudioButton text="Hi" className="bg-white text-success mb-4" />
                <div className="bg-white/20 p-4 rounded-xl">
                  <p className="text-lg">🎤 Your turn: Say "Hi"</p>
                </div>
              </Card>
              <Card className="p-6 bg-gradient-accent text-white">
                <div className="text-5xl mb-4">👋</div>
                <h4 className="text-3xl font-bold mb-4">BYE</h4>
                <AudioButton text="Bye" className="bg-white text-accent mb-4" />
                <div className="bg-white/20 p-4 rounded-xl">
                  <p className="text-lg">🎤 Your turn: Say "Bye"</p>
                </div>
              </Card>
            </div>
          </div>
        </ActivityCard>;

      case 8:
        return <ActivityCard title="Model Sentence! 💬" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Learn this important sentence!</h3>
            <div className="bg-gradient-primary p-8 rounded-3xl text-white">
              <div className="text-6xl mb-6">👋</div>
              <h2 className="text-4xl font-bold mb-6">"Hello, I am Anna."</h2>
              <AudioButton text="Hello, I am Anna" className="bg-white text-primary text-xl p-4" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-xl border-2 border-primary">
                <div className="text-2xl font-bold text-primary">HELLO</div>
                <p className="text-sm">Greeting</p>
              </div>
              <div className="bg-white p-4 rounded-xl border-2 border-success">
                <div className="text-2xl font-bold text-success">I AM</div>
                <p className="text-sm">About me</p>
              </div>
              <div className="bg-white p-4 rounded-xl border-2 border-accent">
                <div className="text-2xl font-bold text-accent">ANNA</div>
                <p className="text-sm">My name</p>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 9:
        return <ActivityCard title="Build Your Sentence! 🏗️" showNext={false}>
          <DragDropActivity
            title="Drag the name to complete: 'Hello, I am ___'"
            items={[
              { id: 'tom-name', content: 'TOM', type: 'source' as const, matchId: 'name-bubble' },
              { id: 'anna-name', content: 'ANNA', type: 'source' as const, matchId: 'name-bubble' },
              { id: 'leo-name', content: 'LEO', type: 'source' as const, matchId: 'name-bubble' },
              { id: 'name-bubble', content: '"Hello, I am ___"', type: 'target' as const }
            ]}
            onComplete={nextSlide}
          />
        </ActivityCard>;

      case 10:
        return <ActivityCard title="Spin & Speak Wheel (Part 1)! 🎰" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Spin the wheel and say what it lands on!</h3>
            <div className="relative">
              <div className="w-64 h-64 mx-auto bg-gradient-to-br from-primary via-success to-accent rounded-full flex items-center justify-center border-8 border-white shadow-glow">
                <div className="text-center">
                  <div className="text-6xl mb-2">🎰</div>
                  <div className="text-2xl font-bold text-white">
                    {wheelResult || "SPIN ME!"}
                  </div>
                </div>
              </div>
            </div>
            <Button
              size="fun"
              className="text-2xl font-bold bg-gradient-accent hover:scale-110 transition-transform"
              onClick={() => spinWheel(['HELLO', 'HI', 'BYE'])}
            >
              🎰 SPIN THE WHEEL!
            </Button>
            {wheelResult && (
              <div className="bg-white p-6 rounded-2xl border-2 border-accent">
                <p className="text-xl font-bold text-accent">🎤 Now say: "{wheelResult}"</p>
              </div>
            )}
          </div>
        </ActivityCard>;

      case 11:
        return <ActivityCard title="Spin & Speak Wheel (Part 2)! 🎰" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Spin for a name and say "Hello, I am ___"!</h3>
            <div className="relative">
              <div className="w-64 h-64 mx-auto bg-gradient-to-br from-accent via-warning to-primary rounded-full flex items-center justify-center border-8 border-white shadow-glow">
                <div className="text-center">
                  <div className="text-6xl mb-2">🎰</div>
                  <div className="text-2xl font-bold text-white">
                    {wheelResult || "SPIN ME!"}
                  </div>
                </div>
              </div>
            </div>
            <Button
              size="fun"
              className="text-2xl font-bold bg-gradient-warning hover:scale-110 transition-transform"
              onClick={() => spinWheel(['TOM', 'ANNA', 'LEO', 'SAM'])}
            >
              🎰 SPIN FOR A NAME!
            </Button>
            {wheelResult && (
              <div className="bg-white p-6 rounded-2xl border-2 border-warning">
                <p className="text-xl font-bold text-warning">🎤 Now say: "Hello, I am {wheelResult}"</p>
              </div>
            )}
          </div>
        </ActivityCard>;

      case 12:
        return <ActivityCard title="Greeting Bingo! 🎯" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Click the greeting when teacher calls it!</h3>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              {['HELLO', 'HI', 'BYE', 'HELLO', 'HI', 'BYE', 'HELLO', 'HI', 'BYE'].map((item, index) => (
                <Button
                  key={index}
                  size="fun"
                  className={`h-20 text-lg font-bold transition-all ${
                    bingoClicked.includes(`${item}-${index}`)
                      ? 'bg-gradient-success text-white scale-105'
                      : 'bg-white border-2 border-primary text-primary hover:bg-primary/10'
                  }`}
                  onClick={() => toggleBingo(`${item}-${index}`)}
                >
                  {item}
                </Button>
              ))}
            </div>
            <div className="bg-gradient-primary p-4 rounded-2xl text-white">
              <p className="text-lg font-semibold">🎯 Teacher calls: "Hello!" - Click all HELLO squares!</p>
            </div>
          </div>
        </ActivityCard>;

      case 13:
        return <ActivityCard title="Role-Play Puppet 1! 🎭" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="bg-gradient-primary p-8 rounded-3xl text-white">
              <div className="text-6xl mb-4">🐻</div>
              <h3 className="text-2xl font-bold mb-4">Puppet Tom says:</h3>
              <p className="text-3xl font-bold">"Hello, I am Tom."</p>
              <AudioButton text="Hello, I am Tom" className="bg-white text-primary mt-6" />
            </div>
            <div className="bg-white p-6 rounded-2xl border-4 border-success">
              <h4 className="text-xl font-bold text-success mb-4">🎤 Your turn to respond!</h4>
              <p className="text-lg">Say: "Hello Tom!" or "Hi Tom!"</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Button
                size="fun"
                className="text-xl font-bold bg-gradient-success hover:scale-105 transition-transform"
                onClick={nextSlide}
              >
                "Hello Tom!"
              </Button>
              <Button
                size="fun"
                className="text-xl font-bold bg-gradient-accent hover:scale-105 transition-transform"
                onClick={nextSlide}
              >
                "Hi Tom!"
              </Button>
            </div>
          </div>
        </ActivityCard>;

      case 14:
        return <ActivityCard title="Role-Play Puppet 2! 🎭" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="bg-gradient-success p-8 rounded-3xl text-white">
              <div className="text-6xl mb-4">👧</div>
              <h3 className="text-2xl font-bold mb-4">Puppet Anna says:</h3>
              <p className="text-3xl font-bold">"Hi, I am Anna."</p>
              <AudioButton text="Hi, I am Anna" className="bg-white text-success mt-6" />
            </div>
            <div className="bg-white p-6 rounded-2xl border-4 border-primary">
              <h4 className="text-xl font-bold text-primary mb-4">🎤 Your turn to respond!</h4>
              <p className="text-lg">Say: "Hello Anna!" or "Hi Anna!"</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Button
                size="fun"
                className="text-xl font-bold bg-gradient-primary hover:scale-105 transition-transform"
                onClick={nextSlide}
              >
                "Hello Anna!"
              </Button>
              <Button
                size="fun"
                className="text-xl font-bold bg-gradient-warning hover:scale-105 transition-transform"
                onClick={nextSlide}
              >
                "Hi Anna!"
              </Button>
            </div>
          </div>
        </ActivityCard>;

      case 15:
        return <ActivityCard title="Sequence Game! 🎯" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Click the characters in order: Hello → Hi → Bye</h3>
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center">
                <Button
                  size="fun"
                  className="w-32 h-32 text-2xl font-bold bg-gradient-primary hover:scale-110 transition-transform mb-4"
                >
                  <div>
                    <div className="text-4xl mb-2">😊</div>
                    <div>HELLO</div>
                  </div>
                </Button>
                <p className="font-semibold">1st Click</p>
              </div>
              <div className="text-center">
                <Button
                  size="fun"
                  className="w-32 h-32 text-2xl font-bold bg-gradient-success hover:scale-110 transition-transform mb-4"
                >
                  <div>
                    <div className="text-4xl mb-2">👋</div>
                    <div>HI</div>
                  </div>
                </Button>
                <p className="font-semibold">2nd Click</p>
              </div>
              <div className="text-center">
                <Button
                  size="fun"
                  className="w-32 h-32 text-2xl font-bold bg-gradient-accent hover:scale-110 transition-transform mb-4"
                  onClick={nextSlide}
                >
                  <div>
                    <div className="text-4xl mb-2">😢</div>
                    <div>BYE</div>
                  </div>
                </Button>
                <p className="font-semibold">3rd Click</p>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 16:
        return <ActivityCard title="Comic Strip 1: Tom meets Anna! 📚" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Read and repeat the conversation!</h3>
            <div className="grid grid-cols-2 gap-6">
              <Card className="p-6 bg-gradient-primary text-white">
                <div className="text-6xl mb-4">🐻</div>
                <h4 className="text-xl font-bold mb-2">Tom says:</h4>
                <p className="text-2xl font-bold">"Hello, I am Tom."</p>
                <AudioButton text="Hello, I am Tom" className="bg-white text-primary mt-4" />
              </Card>
              <Card className="p-6 bg-gradient-success text-white">
                <div className="text-6xl mb-4">👧</div>
                <h4 className="text-xl font-bold mb-2">Anna says:</h4>
                <p className="text-2xl font-bold">"Hi Tom! I am Anna."</p>
                <AudioButton text="Hi Tom! I am Anna" className="bg-white text-success mt-4" />
              </Card>
            </div>
            <div className="bg-white p-6 rounded-2xl border-2 border-accent">
              <p className="text-xl font-bold text-accent">🎤 Practice: Read both parts aloud!</p>
            </div>
          </div>
        </ActivityCard>;

      case 17:
        return <ActivityCard title="Comic Strip 2: Anna meets Leo! 📚" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Fill in the missing greeting!</h3>
            <div className="grid grid-cols-2 gap-6">
              <Card className="p-6 bg-gradient-success text-white">
                <div className="text-6xl mb-4">👧</div>
                <h4 className="text-xl font-bold mb-2">Anna says:</h4>
                <p className="text-2xl font-bold">"Hello, I am Anna."</p>
              </Card>
              <Card className="p-6 bg-gradient-warning text-white">
                <div className="text-6xl mb-4">🦁</div>
                <h4 className="text-xl font-bold mb-2">Leo says:</h4>
                <p className="text-2xl font-bold">"___, Anna! I am Leo."</p>
              </Card>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Button
                size="fun"
                className="text-xl font-bold bg-gradient-primary hover:scale-105 transition-transform"
                onClick={nextSlide}
              >
                "Hello"
              </Button>
              <Button
                size="fun"
                className="text-xl font-bold bg-gradient-accent hover:scale-105 transition-transform"
                onClick={nextSlide}
              >
                "Hi"
              </Button>
            </div>
          </div>
        </ActivityCard>;

      case 18:
        return <ActivityCard title="Personal Speaking Drill! 🎤" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Practice with YOUR name!</h3>
            <div className="bg-gradient-primary p-8 rounded-3xl text-white">
              <div className="text-6xl mb-6">🌟</div>
              <h2 className="text-3xl font-bold mb-6">Practice saying:</h2>
              <p className="text-4xl font-bold">"Hello, I am ___"</p>
              <p className="text-xl mt-4">(Use your real name!)</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border-4 border-success">
              <h4 className="text-xl font-bold text-success mb-4">🎤 Teacher's Turn:</h4>
              <p className="text-lg mb-4">"What's your name?"</p>
              <p className="text-lg font-bold text-primary">Student answers: "Hello, I am [Your Name]"</p>
            </div>
            <div className="bg-gradient-success p-4 rounded-2xl text-white">
              <p className="text-lg font-semibold">Perfect! Now you can introduce yourself!</p>
            </div>
          </div>
        </ActivityCard>;

      case 19:
        return <ActivityCard title="Role-Play Task: Meet 2 Friends! 🎭" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Introduce yourself to both cartoon friends!</h3>
            <div className="grid grid-cols-2 gap-6">
              <Card className="p-6 bg-gradient-primary text-white hover:scale-105 transition-transform cursor-pointer">
                <div className="text-8xl mb-4">🐼</div>
                <h4 className="text-2xl font-bold mb-4">Meet Panda!</h4>
                <Button
                  size="fun"
                  className="bg-white text-primary hover:scale-110 transition-transform"
                  onClick={() => console.log("Introduce to Panda")}
                >
                  Say Hello!
                </Button>
              </Card>
              <Card className="p-6 bg-gradient-success text-white hover:scale-105 transition-transform cursor-pointer">
                <div className="text-8xl mb-4">🦊</div>
                <h4 className="text-2xl font-bold mb-4">Meet Fox!</h4>
                <Button
                  size="fun"
                  className="bg-white text-success hover:scale-110 transition-transform"
                  onClick={() => console.log("Introduce to Fox")}
                >
                  Say Hello!
                </Button>
              </Card>
            </div>
            <div className="bg-white p-6 rounded-2xl border-4 border-accent">
              <h4 className="text-xl font-bold text-accent mb-4">🎯 Your Task:</h4>
              <p className="text-lg">Click each friend and say: "Hello, I am [Your Name]"</p>
            </div>
          </div>
        </ActivityCard>;

      case 20:
        return <ActivityCard title="🏅 Congratulations, Greetings Master! 🎉" showNext={false}>
          <BadgeReward
            title="Greetings Master Badge Unlocked!"
            description="You've mastered all greetings, letters A & B, and can introduce yourself perfectly!"
            badgeName="Greetings Master"
            onContinue={() => {
              console.log("Lesson 1.3 completed!");
            }}
          />
        </ActivityCard>;

      default:
        return <ActivityCard title="Lesson Complete!" onNext={nextSlide}>
          <div className="text-center">
            <h2 className="text-2xl font-bold">Great job!</h2>
            <p>You've completed all the slides!</p>
          </div>
        </ActivityCard>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-warning/10">
      <FloatingLogo />
      <div className="container mx-auto px-4 py-6">
        <ProgressBar current={currentSlide} total={TOTAL_SLIDES} />
        
        <div className="mt-6">
          {renderSlide()}
        </div>

        <div className="flex justify-between items-center mt-6">
          <Button
            onClick={previousSlide}
            disabled={currentSlide === 1}
            variant="outline"
            className="flex items-center gap-2"
          >
            ← Previous
          </Button>
          
          <span className="text-sm text-muted-foreground">
            Slide {currentSlide} of {TOTAL_SLIDES}
          </span>
          
          <Button
            onClick={nextSlide}
            disabled={currentSlide === TOTAL_SLIDES}
            variant="outline"
            className="flex items-center gap-2"
          >
            Next →
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Lesson3;