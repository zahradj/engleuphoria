import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ProgressBar } from "@/components/ProgressBar";
import { FloatingLogo } from "@/components/FloatingLogo";
import { BookOpen, Play, Trophy, Clock, Users, Star } from "lucide-react";

interface Lesson {
  id: string;
  title: string;
  subtitle: string;
  phonics: string;
  duration: string;
  status: "completed" | "current" | "locked";
  introRoute: string;
  lessonRoute: string;
}

interface Level {
  id: string;
  title: string;
  description: string;
  color: string;
  gradient: string;
  lessons: Lesson[];
  difficulty: string;
  skills: string[];
}

const Home = () => {
  const navigate = useNavigate();

  const levels: Level[] = [
    {
      id: "pre-starter",
      title: "Pre-Starter",
      description: "Foundation level for very young learners. Basic greetings, letters, numbers 1-5, and simple vocabulary.",
      color: "lesson-blue",
      gradient: "gradient-cool",
      difficulty: "Absolute Beginner",
      skills: ["Greetings", "Alphabet A-G", "Numbers 1-5", "Basic Colors", "Simple Toys"],
      lessons: [
        {
          id: "lesson1",
          title: "Unit 1: Greetings & Self",
          subtitle: "Hello, My Name Is... (Letter A)",
          phonics: "A",
          duration: "20-25 mins",
          status: "completed",
          introRoute: "/lesson-intro",
          lessonRoute: "/lesson"
        },
        {
          id: "lesson21",
          title: "Unit 2: Colors & Objects",
          subtitle: "My Colors (Red, Blue, Yellow) (Letter B)",
          phonics: "B",
          duration: "20-25 mins",
          status: "completed",
          introRoute: "/lesson2-intro",
          lessonRoute: "/lesson2"
        },
        {
          id: "lesson22",
          title: "Unit 2: More Colors",
          subtitle: "Green, Black, White (Letter C)",
          phonics: "C",
          duration: "20-25 mins",
          status: "completed",
          introRoute: "/lesson21-intro",
          lessonRoute: "/lesson21"
        },
        {
          id: "lesson23",
          title: "Unit 2: Rainbow Review",
          subtitle: "All Colors Practice (Letter D)",
          phonics: "D",
          duration: "25-30 mins",
          status: "completed",
          introRoute: "/lesson22-intro",
          lessonRoute: "/lesson22"
        },
        {
          id: "lesson24",
          title: "Unit 2: Color Games",
          subtitle: "Color Review & Games (Letter E)",
          phonics: "E",
          duration: "25-30 mins",
          status: "completed",
          introRoute: "/lesson23-intro",
          lessonRoute: "/lesson23"
        },
        {
          id: "lesson31",
          title: "Unit 3: Numbers & Toys",
          subtitle: "Numbers 1-3 & Toys (Letter F)",
          phonics: "F",
          duration: "25-30 mins",
          status: "completed",
          introRoute: "/lesson31-intro",
          lessonRoute: "/lesson31"
        },
        {
          id: "lesson32",
          title: "Unit 3: More Numbers",
          subtitle: "Numbers 4-5 & More Toys (Letter G)",
          phonics: "G",
          duration: "25-30 mins",
          status: "completed",
          introRoute: "/lesson32-intro",
          lessonRoute: "/lesson32"
        },
        {
          id: "lesson33",
          title: "Unit 3: Toy Shop Role-Play",
          subtitle: "Review 1-5, Toys (Ball, Car, Doll, Teddy)",
          phonics: "A-F",
          duration: "25-30 mins",
          status: "completed",
          introRoute: "/lesson33-intro",
          lessonRoute: "/lesson33"
        },
        {
          id: "lesson41",
          title: "Lesson 4.1 – My Body",
          subtitle: "Head, Eyes, Nose (Letter Gg)",
          phonics: "Gg",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson41-intro",
          lessonRoute: "/lesson41"
        },
        {
          id: "lesson42",
          title: "Lesson 4.2 – My Body",
          subtitle: "Mouth, Hands, Feet (Letter Hh)",
          phonics: "Hh",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson42-intro",
          lessonRoute: "/lesson42"
        },
        {
          id: "lesson43",
          title: "Lesson 4.3 – Full Body Review",
          subtitle: "Complete Body Parts Review",
          phonics: "A-H",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson43-intro",
          lessonRoute: "/lesson43"
        },
        {
          id: "lesson44",
          title: "Lesson 4.4 – More Body Parts",
          subtitle: "Arms, Legs, Fingers, Toes (Letter Ii)",
          phonics: "Ii",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson44-intro",
          lessonRoute: "/lesson44"
        },
        {
          id: "lesson45",
          title: "Lesson 4.5 – Body Actions & Final Test",
          subtitle: "Run, Walk, Jump + Unit Assessment",
          phonics: "A-I",
          duration: "30-35 mins",
          status: "current",
          introRoute: "/lesson45-intro",
          lessonRoute: "/lesson45"
        },
        {
          id: "lesson51",
          title: "Lesson 5.1 – Animals: Pets",
          subtitle: "Cat, Dog, Fish (Letter Ii)",
          phonics: "Ii",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson51-intro",
          lessonRoute: "/lesson51"
        },
        {
          id: "lesson52",
          title: "Lesson 5.2 – Animals: Farm",
          subtitle: "Bird, Cow, Duck (Letter Jj)",
          phonics: "Jj",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson52-intro",
          lessonRoute: "/lesson52"
        },
        {
          id: "lesson53",
          title: "Lesson 5.3 – Animals: Wild",
          subtitle: "Lion, Elephant, Monkey (Letter Kk)",
          phonics: "Kk",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson53-intro",
          lessonRoute: "/lesson53"
        },
        {
          id: "lesson54",
          title: "Lesson 5.4 – Animal Actions",
          subtitle: "Swim, Fly, Run, Jump (Letter Ll)",
          phonics: "Ll",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson54-intro",
          lessonRoute: "/lesson54"
        },
        {
          id: "lesson55",
          title: "Lesson 5.5 – Animal Kingdom Review & Test",
          subtitle: "All Animals Review + Unit Assessment",
          phonics: "A-L",
          duration: "30-35 mins",
          status: "completed",
          introRoute: "/lesson55-intro",
          lessonRoute: "/lesson55"
        },
        {
          id: "lesson61",
          title: "Lesson 6.1 – My Family: Parents",
          subtitle: "Mother, Father (Letter Kk)",
          phonics: "Kk",
          duration: "25-30 mins",
          status: "completed",
          introRoute: "/lesson/6-1-intro",
          lessonRoute: "/lesson/6-1"
        },
        {
          id: "lesson62",
          title: "Lesson 6.2 – My Family: Siblings",
          subtitle: "Brother, Sister, Baby (Letter Ll)",
          phonics: "Ll",
          duration: "25-30 mins",
          status: "completed",
          introRoute: "/lesson/6-2-intro",
          lessonRoute: "/lesson/6-2"
        },
        {
          id: "lesson63",
          title: "Lesson 6.3 – Family Review & Role-Play",
          subtitle: "Complete Family Review (Letter Mm)",
          phonics: "Mm",
          duration: "25-30 mins",
          status: "completed",
          introRoute: "/lesson/6-3-intro",
          lessonRoute: "/lesson/6-3"
        },
        {
          id: "lesson71",
          title: "Lesson 7.1 – Food Fun: Fruits",
          subtitle: "Apple, Banana (Letter Nn)",
          phonics: "Nn",
          duration: "25-30 mins",
          status: "current",
          introRoute: "/lesson/7-1-intro",
          lessonRoute: "/lesson/7-1"
        },
        {
          id: "lesson72",
          title: "Lesson 7.2 – Food Fun: Meals",
          subtitle: "Milk, Bread, Rice (Letter Oo)",
          phonics: "Oo",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/lesson/7-2-intro",
          lessonRoute: "/lesson/7-2"
        },
        {
          id: "lesson73",
          title: "Lesson 7.3 – Food Review & Shopping Game",
          subtitle: "All Foods Review (Letter Pp)",
          phonics: "Pp",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/lesson/7-3-intro",
          lessonRoute: "/lesson/7-3"
        },
        {
          id: "lesson81",
          title: "Lesson 8.1 – My Classroom: School Items 1",
          subtitle: "Book, Pen (Letter Qq)",
          phonics: "Qq",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/lesson/8-1-intro",
          lessonRoute: "/lesson/8-1"
        },
        {
          id: "lesson82",
          title: "Lesson 8.2 – My Classroom: School Items 2",
          subtitle: "Bag, Chair, Table (Letter Rr)",
          phonics: "Rr",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/lesson/8-2-intro",
          lessonRoute: "/lesson/8-2"
        },
        {
          id: "lesson83",
          title: "Lesson 8.3 – Classroom Review & Role-Play",
          subtitle: "All School Items Review",
          phonics: "M-R",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/lesson/8-3-intro",
          lessonRoute: "/lesson/8-3"
        },
        {
          id: "lesson91",
          title: "Lesson 9.1 – Weather & Clothes: Weather",
          subtitle: "Sun, Rain, Hot (Letter Ss)",
          phonics: "Ss",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/lesson/9-1-intro",
          lessonRoute: "/lesson/9-1"
        },
        {
          id: "lesson92",
          title: "Lesson 9.2 – Weather & Clothes: Clothes",
          subtitle: "Cold, Hat, Coat (Letter Tt)",
          phonics: "Tt",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/lesson/9-2-intro",
          lessonRoute: "/lesson/9-2"
        },
        {
          id: "lesson93",
          title: "Lesson 9.3 – Weather & Clothes Review",
          subtitle: "Complete Weather & Clothes Review",
          phonics: "S-T",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/lesson/9-3-intro",
          lessonRoute: "/lesson/9-3"
        },
        {
          id: "lesson101",
          title: "Lesson 10.1 – My World Review: Spin & Speak",
          subtitle: "Mixed Vocabulary (Letter Uu)",
          phonics: "Uu",
          duration: "30-35 mins",
          status: "locked",
          introRoute: "/lesson/10-1-intro",
          lessonRoute: "/lesson/10-1"
        },
        {
          id: "lesson102",
          title: "Lesson 10.2 – Story Time",
          subtitle: "Mini Story with All Vocabulary (Letter Vv)",
          phonics: "Vv",
          duration: "30-35 mins",
          status: "locked",
          introRoute: "/lesson/10-2-intro",
          lessonRoute: "/lesson/10-2"
        },
        {
          id: "lesson103",
          title: "Lesson 10.3 – Final Show",
          subtitle: "Review + Certificate & Badges (A-Z)",
          phonics: "A-Z",
          duration: "35-40 mins",
          status: "locked",
          introRoute: "/lesson/10-3-intro",
          lessonRoute: "/lesson/10-3"
        }
      ]
    },
    {
      id: "beginner",
      title: "Beginner",
      description: "First steps in English. Family, body parts, simple actions, and everyday objects.",
      color: "lesson-green",
      gradient: "gradient-success",
      difficulty: "Beginner",
      skills: ["Family Members", "Body Parts", "Common Actions", "Days of Week", "Simple Sentences"],
      lessons: [
        {
          id: "beginner1",
          title: "Unit 1: My Family",
          subtitle: "Mom, Dad, Sister, Brother",
          phonics: "H-J",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/beginner1-intro",
          lessonRoute: "/beginner1"
        },
        {
          id: "beginner2",
          title: "Unit 2: My Body",
          subtitle: "Head, Eyes, Nose, Mouth",
          phonics: "K-M",
          duration: "25-30 mins",
          status: "locked",
          introRoute: "/beginner2-intro",
          lessonRoute: "/beginner2"
        }
      ]
    },
    {
      id: "a1",
      title: "A1 Elementary",
      description: "Basic communication skills. Animals, food, home, and simple conversations.",
      color: "lesson-orange",
      gradient: "gradient-warm",
      difficulty: "Elementary",
      skills: ["Animals", "Food & Drinks", "House & Rooms", "Basic Conversations", "Present Simple"],
      lessons: [
        {
          id: "a1-1",
          title: "Unit 1: Animals",
          subtitle: "Cat, Dog, Bird, Fish",
          phonics: "N-P",
          duration: "30-35 mins",
          status: "locked",
          introRoute: "/a1-1-intro",
          lessonRoute: "/a1-1"
        },
        {
          id: "a1-2",
          title: "Unit 2: Food I Like",
          subtitle: "Apple, Banana, Bread, Milk",
          phonics: "Q-S",
          duration: "30-35 mins",
          status: "locked",
          introRoute: "/a1-2-intro",
          lessonRoute: "/a1-2"
        }
      ]
    },
    {
      id: "a2",
      title: "A2 Pre-Intermediate",
      description: "Expanding vocabulary and grammar. Describing people, places, and past events.",
      color: "lesson-purple",
      gradient: "gradient-primary",
      difficulty: "Pre-Intermediate", 
      skills: ["Descriptions", "Past Tense", "Weather", "Clothes", "Hobbies"],
      lessons: [
        {
          id: "a2-1",
          title: "Unit 1: Describing People",
          subtitle: "Tall, Short, Happy, Sad",
          phonics: "T-V",
          duration: "35-40 mins",
          status: "locked",
          introRoute: "/a2-1-intro",
          lessonRoute: "/a2-1"
        }
      ]
    },
    {
      id: "b1",
      title: "B1 Intermediate",
      description: "More complex conversations and grammar. Travel, work, and expressing opinions.",
      color: "lesson-pink",
      gradient: "gradient-fun",
      difficulty: "Intermediate",
      skills: ["Travel", "Work", "Opinions", "Future Tense", "Comparisons"],
      lessons: [
        {
          id: "b1-1",
          title: "Unit 1: Travel Adventures",
          subtitle: "Countries, Transport, Hotels",
          phonics: "W-Z",
          duration: "40-45 mins",
          status: "locked",
          introRoute: "/b1-1-intro",
          lessonRoute: "/b1-1"
        }
      ]
    },
    {
      id: "b2",
      title: "B2 Upper-Intermediate", 
      description: "Advanced discussions and complex grammar. News, culture, and detailed conversations.",
      color: "lesson-teal",
      gradient: "gradient-cool",
      difficulty: "Upper-Intermediate",
      skills: ["Complex Grammar", "News & Media", "Culture", "Debates", "Academic Language"],
      lessons: [
        {
          id: "b2-1",
          title: "Unit 1: In the News",
          subtitle: "Current Events & Media",
          phonics: "Review",
          duration: "45-50 mins",
          status: "locked",
          introRoute: "/b2-1-intro",
          lessonRoute: "/b2-1"
        }
      ]
    },
    {
      id: "c1",
      title: "C1 Advanced",
      description: "Near-native fluency. Complex texts, nuanced communication, and professional language.",
      color: "lesson-red",
      gradient: "gradient-warm",
      difficulty: "Advanced",
      skills: ["Professional Language", "Complex Texts", "Nuanced Communication", "Idioms", "Academic Writing"],
      lessons: [
        {
          id: "c1-1",
          title: "Unit 1: Business English",
          subtitle: "Meetings, Presentations, Negotiations",
          phonics: "Advanced",
          duration: "50-60 mins",
          status: "locked",
          introRoute: "/c1-1-intro",
          lessonRoute: "/c1-1"
        }
      ]
    },
    {
      id: "c2",
      title: "C2 Proficiency",
      description: "Native-level mastery. Literature, advanced writing, and expert-level communication.",
      color: "lesson-lime",
      gradient: "gradient-success",
      difficulty: "Proficiency",
      skills: ["Literature Analysis", "Expert Communication", "Advanced Writing", "Research Skills", "Native Fluency"],
      lessons: [
        {
          id: "c2-1",
          title: "Unit 1: Literature & Analysis",
          subtitle: "Poetry, Novels, Critical Thinking",
          phonics: "Mastery",
          duration: "60+ mins",
          status: "locked",
          introRoute: "/c2-1-intro",
          lessonRoute: "/c2-1"
        }
      ]
    }
  ];

  const allLessons = levels.flatMap(level => level.lessons);
  const completedLessons = allLessons.filter(lesson => lesson.status === "completed").length;
  const totalLessons = allLessons.length;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <Trophy className="w-4 h-4 text-success" />;
      case "current":
        return <Play className="w-4 h-4 text-primary" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="secondary" className="bg-success text-success-foreground">Completed</Badge>;
      case "current":
        return <Badge variant="default">Current</Badge>;
      default:
        return <Badge variant="outline">Locked</Badge>;
    }
  };

  const handleLessonClick = (lesson: Lesson) => {
    if (lesson.status === "locked") return;
    navigate(lesson.introRoute);
  };

  const handleQuickStart = (lesson: Lesson) => {
    if (lesson.status === "locked") return;
    navigate(lesson.lessonRoute);
  };

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      {/* Header Section */}
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <FloatingLogo />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-4 rainbow-text">
            Pre-Starter Program
          </h1>
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground mb-2">
            Complete English Learning Program
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Complete English learning journey from Pre-Starter to C2 Proficiency! 
            Learn through interactive lessons, games, and activities designed for all levels.
          </p>
        </div>

        {/* Overall Progress */}
        <div className="mb-8">
          <Card className="bg-gradient-card border-0 shadow-card hover-grow">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Star className="w-6 h-6 text-warning" />
                Your Learning Progress
                <Star className="w-6 h-6 text-warning" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ProgressBar current={completedLessons} total={totalLessons} className="mb-4" />
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-primary">{totalLessons}</div>
                  <div className="text-sm text-muted-foreground">Total Lessons</div>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-success">{completedLessons}</div>
                  <div className="text-sm text-muted-foreground">Completed</div>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-lesson-orange">8</div>
                  <div className="text-sm text-muted-foreground">Language Levels</div>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-lesson-purple">A-Z</div>
                  <div className="text-sm text-muted-foreground">Complete Alphabet</div>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-lesson-pink">10+ hrs</div>
                  <div className="text-sm text-muted-foreground">Total Content</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Levels Grid */}
        <div className="space-y-8">
          {levels.map((level) => {
            const levelCompleted = level.lessons.filter(l => l.status === "completed").length;
            const levelTotal = level.lessons.length;

            return (
              <Card key={level.id} className="bg-gradient-card border-0 shadow-card hover-grow">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <CardTitle className={`text-2xl text-${level.color} mb-2`}>
                        {level.title}
                      </CardTitle>
                      <CardDescription className="text-base mb-2">
                        {level.description}
                      </CardDescription>
                      <div className="flex flex-wrap gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          {level.difficulty}
                        </Badge>
                        {level.skills.slice(0, 3).map((skill) => (
                          <Badge key={skill} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="text-right">
                      <ProgressBar current={levelCompleted} total={levelTotal} className="w-48" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {level.lessons.map((lesson) => (
                      <Card 
                        key={lesson.id} 
                        className={`cursor-pointer transition-all duration-300 hover:shadow-glow border-2 ${
                          lesson.status === "locked" 
                            ? "opacity-60 cursor-not-allowed" 
                            : "hover:scale-105"
                        } ${
                          lesson.status === "current" 
                            ? "border-primary shadow-button" 
                            : "border-border"
                        }`}
                        onClick={() => handleLessonClick(lesson)}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                {getStatusIcon(lesson.status)}
                                <CardTitle className="text-lg">{lesson.title}</CardTitle>
                              </div>
                              <CardDescription className="text-sm">
                                {lesson.subtitle}
                              </CardDescription>
                            </div>
                            {getStatusBadge(lesson.status)}
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="flex items-center justify-between text-sm text-muted-foreground mb-3">
                            <div className="flex items-center gap-1">
                              <BookOpen className="w-4 h-4" />
                              Phonics: {lesson.phonics}
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {lesson.duration}
                            </div>
                          </div>
                          
                          {lesson.status !== "locked" && (
                            <div className="flex gap-2">
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="flex-1"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleLessonClick(lesson);
                                }}
                              >
                                <Play className="w-4 h-4 mr-1" />
                                Intro
                              </Button>
                              <Button 
                                size="sm" 
                                variant="default"
                                className="flex-1"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleQuickStart(lesson);
                                }}
                              >
                                <Users className="w-4 h-4 mr-1" />
                                Start
                              </Button>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-primary border-0 shadow-glow text-white">
            <CardContent className="py-8">
              <h3 className="text-2xl font-bold mb-4">Ready to Learn?</h3>
              <p className="mb-6 opacity-90">
                Continue your English learning adventure with fun games and activities!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  variant="secondary"
                  onClick={() => navigate("/lesson/7-3-intro")}
                  className="text-lg px-8"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Current: Unit 7.3 - Food Review & Shopping
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  onClick={() => navigate("/program")}
                  className="text-lg px-8 bg-white/20 border-white/30 hover:bg-white/30"
                >
                  <BookOpen className="w-5 h-5 mr-2" />
                  View Program Details
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Home;