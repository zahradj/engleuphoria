import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap, Trophy } from "lucide-react";

export const Lesson55Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 5 • Lesson 5 • Final Assessment
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🏆 Animal Kingdom Review & Test!
          </h1>
          <p className="text-xl text-muted-foreground">
            Master all animals and complete Unit 5 assessment
          </p>
        </div>

        {/* Complete Animal Kingdom */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-3xl mb-2">🐱🐶🐟</div>
              <h3 className="font-bold">Pet Animals</h3>
              <p className="text-sm text-muted-foreground">Cat, Dog, Fish</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-3xl mb-2">🐦🐄🦆</div>
              <h3 className="font-bold">Farm Animals</h3>
              <p className="text-sm text-muted-foreground">Bird, Cow, Duck</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-success/20 hover:border-success/40 transition-colors bg-gradient-success/10">
            <CardContent className="pt-6">
              <div className="text-3xl mb-2">🦁🐘🐵</div>
              <h3 className="font-bold text-success">Wild Animals</h3>
              <p className="text-sm text-muted-foreground">Lion, Elephant, Monkey</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Review & Assess */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-warning" />
                What We'll Review & Assess
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>All 9 animals from Unit 5</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Animal sounds and actions</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Complete "It is a/an..." sentences</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>"Animals can..." ability sentences</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Phonics A-L comprehensive review</span>
              </div>
            </CardContent>
          </Card>

          {/* Assessment Activities */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Assessment Activities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Animal kingdom sorting test</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Sound identification challenge</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Sentence building assessment</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Speaking fluency evaluation</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Animal action matching test</span>
              </div>
            </CardContent>
          </Card>

          {/* Assessment Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Assessment Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">30–35 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">23 assessment slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Focus:</span>
                <span className="font-medium">Unit 5 completion</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Animal Kingdom Master Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Complete Unit 5 Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Complete Unit 5 Vocabulary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">All Animals (9):</h4>
                <div className="grid grid-cols-3 gap-1 text-sm">
                  <span>🐱 Cat</span>
                  <span>🐶 Dog</span>
                  <span>🐟 Fish</span>
                  <span>🐦 Bird</span>
                  <span>🐄 Cow</span>
                  <span>🦆 Duck</span>
                  <span>🦁 Lion</span>
                  <span>🐘 Elephant</span>
                  <span>🐵 Monkey</span>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Actions:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>🏊‍♀️ Swim</span>
                    <AudioButton text="swim" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦅 Fly</span>
                    <AudioButton text="fly" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🏃‍♂️ Run</span>
                    <AudioButton text="run" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦘 Jump</span>
                    <AudioButton text="jump" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Assessment Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              Assessment & Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Comprehensive Evaluation:</strong> This lesson assesses all Unit 5 learning including animal vocabulary, classification, sounds, actions, and sentence patterns.
              </p>
              <p>
                <strong>Interactive Assessment:</strong> Use games and activities to evaluate understanding rather than traditional testing methods.
              </p>
              <p>
                <strong>Speaking Focus:</strong> Emphasize oral production with "It is a/an..." and "Animals can..." patterns throughout the assessment.
              </p>
              <p>
                <strong>Progress Celebration:</strong> Highlight student achievements and progress throughout Unit 5 to build confidence.
              </p>
              <p>
                <strong>Next Steps:</strong> Upon successful completion, students are ready for Unit 6 topics (family, colors review, etc.).
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson55")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Start Final Assessment!
          </Button>
        </div>
      </div>
    </div>
  );
};