import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { FillInTheGapActivity } from "@/components/FillInTheGapActivity";
import { useState } from "react";
import { FloatingLogo } from "@/components/FloatingLogo";
import logo from "@/assets/englphoria-logo.png";
import appleImage from "@/assets/phonics-apple.png";
import antImage from "@/assets/phonics-ant.png";
import alligatorImage from "@/assets/phonics-alligator.png";

export const LessonIntro = () => {
  const navigate = useNavigate();
  const [showPreview, setShowPreview] = useState(false);

  const startLesson = () => {
    navigate("/lesson");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
      <FloatingLogo />
      <div className="max-w-2xl mx-auto text-center space-y-12">
        
        {/* Animated Logo in Purple Bubble */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-primary to-accent rounded-full shadow-glow animate-bounce-gentle flex items-center justify-center">
              <img 
                src={logo} 
                alt="EnglEphoria Logo" 
                className="w-20 h-20 object-contain filter brightness-0 invert"
              />
            </div>
            {/* Floating sparkles around the bubble */}
            <div className="absolute -top-2 -right-2 text-2xl animate-pulse-fun">✨</div>
            <div className="absolute -bottom-1 -left-3 text-xl animate-bounce-gentle" style={{animationDelay: '0.5s'}}>⭐</div>
            <div className="absolute top-4 -left-4 text-lg animate-pulse-fun" style={{animationDelay: '1s'}}>🌟</div>
          </div>
        </div>

        {/* Lesson Title */}
        <div className="space-y-6">
          <h1 className="text-5xl font-bold font-fredoka rainbow-text">
            Welcome to Your Adventure!
          </h1>
          
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl border-2 border-primary/20 shadow-fun">
            <h2 className="text-3xl font-bold font-fredoka text-primary mb-4">
              🎯 Lesson 1.1
            </h2>
            <h3 className="text-2xl font-semibold text-foreground mb-3">
              Greetings & Names
            </h3>
            <p className="text-lg text-muted-foreground">
              Pre-Starter Level • 30 Fun Minutes
            </p>
          </div>
        </div>

        {/* What You'll Learn Section */}
        <div className="bg-gradient-success p-8 rounded-3xl border-2 border-success/30 shadow-glow">
          <h3 className="text-2xl font-bold font-fredoka text-white mb-6 sparkle">
            🌟 Today's Amazing Journey!
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">👋</div>
              <p className="text-white font-fredoka font-semibold">Say Hello & Goodbye!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">📛</div>
              <p className="text-white font-fredoka font-semibold">Share Your Name!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🔤</div>
              <p className="text-white font-fredoka font-semibold">Meet Letter A!</p>
        </div>

            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🎵</div>
              <p className="text-white font-fredoka font-semibold">Fun Songs & Games!</p>
            </div>
          </div>
        </div>

        {/* Start Button */}
        <div className="space-y-4">
          <div className="flex gap-4 justify-center">
            <Button
              onClick={startLesson}
              size="fun"
              variant="kid"
              className="text-2xl font-bold font-fredoka shadow-glow hover:shadow-fun transform hover:scale-110 transition-all duration-300"
            >
              🚀 Start My Adventure! 🌟
            </Button>
            <Button
              onClick={() => setShowPreview(!showPreview)}
              variant="outline"
              size="fun"
              className="text-xl font-bold font-fredoka border-primary text-primary hover:bg-primary/10"
            >
              👀 Quick Preview
            </Button>
            <Button
              onClick={() => navigate("/program")}
              variant="outline"
              size="fun"
              className="text-xl font-bold font-fredoka border-accent text-accent hover:bg-accent/10"
            >
              📚 Full Program
            </Button>
          </div>
          <p className="text-sm text-muted-foreground font-fredoka">
            Click when you're ready to begin!
          </p>
        </div>

        {/* Preview Activity */}
        {showPreview && (
          <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl border-2 border-primary/30 shadow-fun">
            <FillInTheGapActivity 
              title="Try this activity from the lesson!"
              words={[
                { word: "apple", imageSrc: appleImage, missingLetter: "a", missingPosition: 0 },
                { word: "ant", imageSrc: antImage, missingLetter: "a", missingPosition: 0 },
                { word: "alligator", imageSrc: alligatorImage, missingLetter: "a", missingPosition: 0 }
              ]}
              onComplete={() => {
                setShowPreview(false);
                startLesson();
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default LessonIntro;