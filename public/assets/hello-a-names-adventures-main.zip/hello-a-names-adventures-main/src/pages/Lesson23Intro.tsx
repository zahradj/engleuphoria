import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";

export const Lesson23Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-warm flex items-center justify-center p-4 relative">
      <FloatingLogo />
      
      <div className="max-w-2xl mx-auto text-center space-y-8">
        {/* Rainbow Animation Header */}
        <div className="relative">
          <div className="text-6xl mb-4 animate-bounce">🌈</div>
          <h1 className="text-4xl md:text-5xl font-bold font-fredoka text-white mb-2">
            Rainbow Review
          </h1>
          <div className="flex justify-center gap-2 mb-4">
            <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
            <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-4 h-4 bg-yellow-500 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }}></div>
            <div className="w-4 h-4 bg-gray-800 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
            <div className="w-4 h-4 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
          </div>
          <p className="text-xl text-white/90 font-medium">
            Let's review all six colors together!
          </p>
        </div>

        {/* Lesson Info Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-3 flex items-center gap-2">
              🎨 What We'll Review
            </h3>
            <div className="space-y-2 text-white/90">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-red-500/20 text-white border-red-500/30">Red</Badge>
                <Badge variant="secondary" className="bg-blue-500/20 text-white border-blue-500/30">Blue</Badge>
                <Badge variant="secondary" className="bg-yellow-500/20 text-white border-yellow-500/30">Yellow</Badge>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-green-500/20 text-white border-green-500/30">Green</Badge>
                <Badge variant="secondary" className="bg-gray-800/40 text-white border-gray-600/30">Black</Badge>
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">White</Badge>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-3 flex items-center gap-2">
              🎯 Fun Activities
            </h3>
            <ul className="space-y-2 text-white/90 text-left">
              <li>🎲 Rainbow Bingo Game</li>
              <li>🎪 Spin & Speak Wheel</li>
              <li>📚 Mini Comic Stories</li>
              <li>🎨 Rainbow Drawing</li>
              <li>🎭 Role-Play Practice</li>
            </ul>
          </Card>
        </div>

        {/* Learning Objectives */}
        <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            📚 Learning Goals
          </h3>
          <div className="grid md:grid-cols-3 gap-4 text-white/90">
            <div className="text-center">
              <div className="text-2xl mb-2">🌈</div>
              <p className="font-semibold">All Six Colors</p>
              <p className="text-sm">Master every color name</p>
            </div>
            <div className="text-center">
              <div className="text-2xl mb-2">🔤</div>
              <p className="font-semibold">Phonics A-D</p>
              <p className="text-sm">Review letter sounds</p>
            </div>
            <div className="text-center">
              <div className="text-2xl mb-2">💬</div>
              <p className="font-semibold">Full Sentences</p>
              <p className="text-sm">"It is..." and "This is..."</p>
            </div>
          </div>
        </Card>

        {/* Start Button */}
        <div className="pt-4">
          <Button
            onClick={() => navigate("/lesson23")}
            size="fun"
            className="text-2xl font-bold font-fredoka bg-white text-primary hover:bg-white/90 hover:scale-110 transition-all duration-300 shadow-button"
          >
            🌈 Start Rainbow Review! ✨
          </Button>
        </div>

        {/* Navigation */}
        <div className="flex gap-4 justify-center pt-4">
          <Button
            onClick={() => navigate("/program")}
            variant="outline"
            className="text-white border-white/30 hover:bg-white/10"
          >
            ← Back to Program
          </Button>
        </div>
      </div>
    </div>
  );
};