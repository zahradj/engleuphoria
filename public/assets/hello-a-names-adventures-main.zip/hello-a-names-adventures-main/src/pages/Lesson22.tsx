import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useNavigate } from "react-router-dom";
import { AudioButton } from "@/components/AudioButton";
import { DragDropActivity } from "@/components/DragDropActivity";
import { Badge } from "@/components/ui/badge";
import { FloatingLogo } from "@/components/FloatingLogo";
import { Card } from "@/components/ui/card";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import logo from "@/assets/englphoria-logo.png";

export const Lesson22 = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinResult, setSpinResult] = useState("GREEN");
  const navigate = useNavigate();
  const totalSlides = 22;

  const nextSlide = () => {
    if (currentSlide < totalSlides - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const goToSlide = (slideNumber: number) => {
    setCurrentSlide(slideNumber);
  };

  const handleSpin = () => {
    setIsSpinning(true);
    const colors = ["GREEN", "BLACK", "WHITE"];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    
    setTimeout(() => {
      setSpinResult(randomColor);
      setIsSpinning(false);
    }, 2000);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 0:
        return (
          <div className="text-center space-y-8">
            <div className="flex justify-center mb-8">
              <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full shadow-glow flex items-center justify-center">
                <img src={logo} alt="EnglEphoria" className="w-16 h-16 object-contain filter brightness-0 invert" />
              </div>
            </div>
            <h1 className="text-6xl font-bold font-fredoka rainbow-text mb-8">More Colors!</h1>
            <div className="flex justify-center gap-8 animate-bounce-gentle">
              <div className="w-16 h-16 bg-green-500 rounded-full shadow-lg animate-float" style={{animationDelay: '0s'}}></div>
              <div className="w-16 h-16 bg-black rounded-full shadow-lg animate-float" style={{animationDelay: '0.3s'}}></div>
              <div className="w-16 h-16 bg-white border-2 border-gray-300 rounded-full shadow-lg animate-float" style={{animationDelay: '0.6s'}}></div>
            </div>
            <p className="text-2xl font-fredoka text-muted-foreground">Welcome to Unit 2, Lesson 2! 🌈</p>
          </div>
        );

      case 1:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-primary mb-8">Quick Review!</h2>
            <p className="text-xl font-fredoka text-muted-foreground mb-8">Let's remember our first colors!</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-3xl border-2 border-red-300 shadow-fun hover:shadow-glow transition-all duration-300 cursor-pointer hover:scale-105">
                <div className="w-20 h-20 bg-red-500 rounded-full mx-auto mb-4"></div>
                <AudioButton text="Red" className="text-2xl font-fredoka font-bold text-red-500" />
              </div>
              <div className="bg-white p-6 rounded-3xl border-2 border-blue-300 shadow-fun hover:shadow-glow transition-all duration-300 cursor-pointer hover:scale-105">
                <div className="w-20 h-20 bg-blue-500 rounded-full mx-auto mb-4"></div>
                <AudioButton text="Blue" className="text-2xl font-fredoka font-bold text-blue-500" />
              </div>
              <div className="bg-white p-6 rounded-3xl border-2 border-yellow-300 shadow-fun hover:shadow-glow transition-all duration-300 cursor-pointer hover:scale-105">
                <div className="w-20 h-20 bg-yellow-500 rounded-full mx-auto mb-4"></div>
                <AudioButton text="Yellow" className="text-2xl font-fredoka font-bold text-yellow-500" />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-primary mb-8">Phonics Warm-Up!</h2>
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-8 rounded-3xl border-2 border-primary/20">
              <div className="text-6xl mb-6">🎵</div>
              <p className="text-3xl font-fredoka font-bold text-primary mb-4">Let's Chant Together!</p>
              <div className="space-y-4">
                <div className="text-2xl font-fredoka">🅰️ A is for Apple! /æ/ /æ/ /æ/</div>
                <div className="text-2xl font-fredoka">🅱️ B is for Ball! /b/ /b/ /b/</div>
                <div className="text-2xl font-fredoka">🅲 C is for Cat! /k/ /k/ /k/</div>
                <div className="text-2xl font-fredoka text-accent font-bold">🅳 D is for Dog! /d/ /d/ /d/</div>
              </div>
              <div className="mt-6 flex justify-center gap-4">
                <div className="text-4xl animate-bounce">🐕</div>
                <div className="text-4xl animate-bounce" style={{animationDelay: '0.2s'}}>🦆</div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-green-500 mb-8">GREEN</h2>
            <div className="flex justify-center mb-8">
              <div className="relative cursor-pointer" onClick={() => console.log('Leaf animation')}>
                <div className="w-48 h-48 bg-gradient-to-br from-green-400 to-green-600 rounded-full shadow-glow animate-pulse-fun flex items-center justify-center hover:scale-105 transition-all">
                  <div className="text-8xl">🌿</div>
                </div>
                <div className="absolute -top-4 -right-4 text-4xl animate-bounce">✨</div>
              </div>
            </div>
            <AudioButton 
              text="Green" 
              className="text-4xl font-fredoka font-bold bg-green-500 text-white px-8 py-4 rounded-2xl hover:bg-green-600 transition-all duration-300 shadow-glow"
            />
            <p className="text-2xl font-fredoka text-muted-foreground">Tap the leaf to see it turn green!</p>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-gray-800 mb-8">BLACK</h2>
            <div className="flex justify-center mb-8">
              <div className="relative cursor-pointer" onClick={() => console.log('Night sky animation')}>
                <div className="w-48 h-48 bg-gradient-to-br from-gray-800 to-black rounded-full shadow-glow animate-pulse-fun flex items-center justify-center hover:scale-105 transition-all">
                  <div className="text-8xl">🌌</div>
                </div>
                <div className="absolute -bottom-4 -left-4 text-4xl animate-bounce">⭐</div>
              </div>
            </div>
            <AudioButton 
              text="Black" 
              className="text-4xl font-fredoka font-bold bg-gray-800 text-white px-8 py-4 rounded-2xl hover:bg-gray-900 transition-all duration-300 shadow-glow"
            />
            <p className="text-2xl font-fredoka text-muted-foreground">The beautiful black night sky!</p>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-gray-600 mb-8">WHITE</h2>
            <div className="flex justify-center mb-8">
              <div className="relative cursor-pointer" onClick={() => console.log('Snow falling animation')}>
                <div className="w-48 h-48 bg-gradient-to-br from-gray-100 to-white border-4 border-gray-300 rounded-full shadow-glow animate-pulse-fun flex items-center justify-center hover:scale-105 transition-all">
                  <div className="text-8xl">❄️</div>
                </div>
                <div className="absolute -top-4 -left-4 text-4xl animate-bounce">❄️</div>
              </div>
            </div>
            <AudioButton 
              text="White" 
              className="text-4xl font-fredoka font-bold bg-gray-100 text-gray-800 border-2 border-gray-300 px-8 py-4 rounded-2xl hover:bg-gray-200 transition-all duration-300 shadow-glow"
            />
            <p className="text-2xl font-fredoka text-muted-foreground">Watch the white snow fall!</p>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Tap-to-Hear Buttons!</h2>
            <p className="text-xl font-fredoka text-muted-foreground mb-8">Click each color to hear it!</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-3xl border-2 border-green-300 shadow-fun hover:shadow-glow transition-all duration-300">
                <div className="w-24 h-24 bg-green-500 rounded-full mx-auto mb-4"></div>
                <AudioButton text="Green" className="text-2xl font-fredoka font-bold text-green-500" />
              </div>
              <div className="bg-white p-6 rounded-3xl border-2 border-gray-400 shadow-fun hover:shadow-glow transition-all duration-300">
                <div className="w-24 h-24 bg-gray-800 rounded-full mx-auto mb-4"></div>
                <AudioButton text="Black" className="text-2xl font-fredoka font-bold text-gray-800" />
              </div>
              <div className="bg-white p-6 rounded-3xl border-2 border-gray-300 shadow-fun hover:shadow-glow transition-all duration-300">
                <div className="w-24 h-24 bg-white border-2 border-gray-300 rounded-full mx-auto mb-4"></div>
                <AudioButton text="White" className="text-2xl font-fredoka font-bold text-gray-600" />
              </div>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Match the Colors!</h2>
            <DragDropActivity
              title="Drag words to their matching objects!"
              items={[
                { id: 'green-word', content: 'GREEN', type: 'source', matchId: 'green-leaf' },
                { id: 'black-word', content: 'BLACK', type: 'source', matchId: 'black-cat' },
                { id: 'white-word', content: 'WHITE', type: 'source', matchId: 'white-snowman' },
                { id: 'green-leaf', content: '🌿', type: 'target' },
                { id: 'black-cat', content: '🐱', type: 'target' },
                { id: 'white-snowman', content: '⛄', type: 'target' }
              ]}
              onComplete={() => console.log('Activity completed!')}
            />
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Sentence Magic!</h2>
            <div className="bg-gradient-to-br from-green-100 to-green-200 p-8 rounded-3xl border-2 border-green-300">
              <div className="text-6xl mb-6">🌿</div>
              <p className="text-4xl font-fredoka font-bold text-green-600">"It is green."</p>
              <AudioButton 
                text="It is green" 
                className="mt-4 text-2xl font-fredoka bg-green-500 text-white px-6 py-3 rounded-xl hover:bg-green-600"
              />
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">More Sentences!</h2>
            <div className="bg-gradient-to-br from-gray-100 to-gray-200 p-8 rounded-3xl border-2 border-gray-300">
              <div className="text-6xl mb-6">🐱</div>
              <p className="text-4xl font-fredoka font-bold text-gray-800">"This is black."</p>
              <AudioButton 
                text="This is black" 
                className="mt-4 text-2xl font-fredoka bg-gray-800 text-white px-6 py-3 rounded-xl hover:bg-gray-900"
              />
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">White Sentence!</h2>
            <div className="bg-gradient-to-br from-gray-50 to-white border-2 border-gray-300 p-8 rounded-3xl">
              <div className="text-6xl mb-6">⛄</div>
              <p className="text-4xl font-fredoka font-bold text-gray-700">"It is white."</p>
              <AudioButton 
                text="It is white" 
                className="mt-4 text-2xl font-fredoka bg-gray-100 text-gray-800 border-2 border-gray-300 px-6 py-3 rounded-xl hover:bg-gray-200"
              />
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Speaking Practice!</h2>
            <p className="text-2xl font-fredoka text-muted-foreground mb-8">Look at the object and say "It is ___"</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-3xl border-2 border-green-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">🌳</div>
                <p className="text-xl font-fredoka text-green-500 font-bold">Say: "It is green"</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-gray-400 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">🎩</div>
                <p className="text-xl font-fredoka text-gray-800 font-bold">Say: "It is black"</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-gray-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">🏳️</div>
                <p className="text-xl font-fredoka text-gray-600 font-bold">Say: "It is white"</p>
              </div>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Sentence Builder!</h2>
            <p className="text-xl font-fredoka text-muted-foreground mb-8">Drag the words to make: "It is black."</p>
            <DragDropActivity
              title="Build the sentence!"
              items={[
                { id: 'it-word', content: 'It', type: 'source', matchId: 'slot1' },
                { id: 'is-word', content: 'is', type: 'source', matchId: 'slot2' },
                { id: 'black-word', content: 'black', type: 'source', matchId: 'slot3' },
                { id: 'slot1', content: '___', type: 'target' },
                { id: 'slot2', content: '___', type: 'target' },
                { id: 'slot3', content: '___', type: 'target' }
              ]}
              onComplete={() => console.log('Sentence completed!')}
            />
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Guess the Hidden Color! 🔍</h2>
            <p className="text-xl font-fredoka text-muted-foreground mb-8">Click the question mark to reveal the color!</p>
            <div className="flex justify-center space-x-8">
              <div className="bg-white p-8 rounded-3xl border-2 border-primary/20 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-8xl mb-4">❓</div>
                <p className="text-lg font-fredoka">Click me!</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-green-300 shadow-fun">
                <div className="w-20 h-20 bg-green-500 rounded-full mx-auto mb-4"></div>
                <p className="text-xl font-fredoka text-green-500 font-bold">It's GREEN!</p>
              </div>
            </div>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Color Spin Wheel! 🎡</h2>
            <div className="flex justify-center mb-8">
              <div className="relative w-48 h-48">
                <div className={`w-full h-full rounded-full border-8 border-primary ${isSpinning ? 'animate-spin' : ''}`}>
                  <div className="w-full h-full rounded-full bg-gradient-to-r from-green-400 via-gray-600 to-gray-100 flex items-center justify-center">
                    <div className="text-2xl font-fredoka font-bold text-white">
                      {isSpinning ? "SPINNING..." : "SPIN!"}
                    </div>
                  </div>
                </div>
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-2 text-2xl">📍</div>
              </div>
            </div>
            <Button
              onClick={handleSpin}
              disabled={isSpinning}
              className="text-xl font-fredoka font-bold px-8 py-4 mb-4"
            >
              {isSpinning ? "Spinning..." : "Spin the Wheel!"}
            </Button>
            {!isSpinning && (
              <div className="bg-white p-6 rounded-2xl border-2 border-accent/20 shadow-fun">
                <p className="text-2xl font-fredoka font-bold text-accent">Wheel says: "{spinResult}"</p>
                <p className="text-xl font-fredoka text-muted-foreground mt-2">Now say: "It is {spinResult.toLowerCase()}!"</p>
              </div>
            )}
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Color Match Quiz! 🧩</h2>
            <p className="text-2xl font-fredoka text-muted-foreground mb-8">Which one is WHITE?</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-3xl border-2 border-green-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="w-20 h-20 bg-green-500 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">A</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-gray-400 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="w-20 h-20 bg-gray-800 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">B</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-4 border-green-400 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="w-20 h-20 bg-white border-2 border-gray-300 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">C ✓</p>
              </div>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Role-Play with Puppet! 🎭</h2>
            <div className="bg-gradient-primary p-6 rounded-3xl text-white">
              <h3 className="text-2xl font-bold mb-4">🎭 Puppet asks you:</h3>
              <div className="text-6xl mb-4">🐱</div>
              <p className="text-2xl font-semibold">"What color is the cat?"</p>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <Button
                size="default"
                variant="outline"
                className="text-xl font-bold p-8 border-green-300 text-green-500 hover:scale-110 transition-transform"
              >
                🟢 "Green"
              </Button>
              <Button
                size="default"
                className="text-xl font-bold p-8 bg-gray-800 text-white hover:scale-110 transition-transform"
              >
                ⚫ "Black"
              </Button>
              <Button
                size="default"
                variant="outline"
                className="text-xl font-bold p-8 border-gray-300 text-gray-600 hover:scale-110 transition-transform"
              >
                ⚪ "White"
              </Button>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Phonics Chant: Letter D! 🎵</h2>
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-8 rounded-3xl border-2 border-primary/20">
              <div className="text-6xl mb-6">🅳</div>
              <p className="text-3xl font-fredoka font-bold text-primary mb-4">D Makes the /d/ Sound!</p>
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-2xl">
                  <div className="text-4xl mb-2">🐕</div>
                  <p className="text-xl font-fredoka font-bold">Dog</p>
                  <AudioButton text="Dog" className="mt-2" />
                </div>
                <div className="bg-white p-6 rounded-2xl">
                  <div className="text-4xl mb-2">🦆</div>
                  <p className="text-xl font-fredoka font-bold">Duck</p>
                  <AudioButton text="Duck" className="mt-2" />
                </div>
                <div className="bg-white p-6 rounded-2xl">
                  <div className="text-4xl mb-2">🚪</div>
                  <p className="text-xl font-fredoka font-bold">Door</p>
                  <AudioButton text="Door" className="mt-2" />
                </div>
                <div className="bg-white p-6 rounded-2xl">
                  <div className="text-4xl mb-2">🌚</div>
                  <p className="text-xl font-fredoka font-bold">Dark</p>
                  <AudioButton text="Dark" className="mt-2" />
                </div>
              </div>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Mini Story Comic! 📖</h2>
            <div className="bg-white p-8 rounded-3xl border-2 border-primary/20 shadow-fun">
              <div className="grid grid-cols-3 gap-6">
                <div className="bg-gray-100 p-6 rounded-2xl">
                  <div className="text-6xl mb-4">🐱</div>
                  <p className="text-lg font-fredoka font-bold text-gray-800">"The cat is black."</p>
                  <AudioButton text="The cat is black" className="mt-2" />
                </div>
                <div className="bg-green-100 p-6 rounded-2xl">
                  <div className="text-6xl mb-4">🌿</div>
                  <p className="text-lg font-fredoka font-bold text-green-600">"The leaf is green."</p>
                  <AudioButton text="The leaf is green" className="mt-2" />
                </div>
                <div className="bg-gray-50 p-6 rounded-2xl border-2 border-gray-300">
                  <div className="text-6xl mb-4">❄️</div>
                  <p className="text-lg font-fredoka font-bold text-gray-700">"The snow is white."</p>
                  <AudioButton text="The snow is white" className="mt-2" />
                </div>
              </div>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Speaking Role-Play! 🎤</h2>
            <SpeakingActivity
              prompt="Answer the teacher's questions about colors!"
              expectedResponse="It is green / black / white"
              onComplete={nextSlide}
            />
            <div className="bg-gradient-primary p-6 rounded-3xl text-white">
              <p className="text-xl font-fredoka font-bold">Teacher asks: "What color is this?"</p>
              <div className="flex justify-center gap-4 mt-4">
                <div className="text-4xl">🌳</div>
                <div className="text-4xl">🎩</div>
                <div className="text-4xl">❄️</div>
              </div>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Quick Quiz! 🧩</h2>
            <p className="text-2xl font-fredoka text-muted-foreground mb-8">Which one is GREEN?</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-3xl border-2 border-gray-400 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="w-20 h-20 bg-gray-800 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">A</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-4 border-green-400 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="w-20 h-20 bg-green-500 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">B ✓</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-gray-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="w-20 h-20 bg-white border-2 border-gray-300 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">C</p>
              </div>
            </div>
            <div className="mt-6">
              <Button onClick={nextSlide} className="text-xl font-fredoka font-bold px-8 py-4">
                Perfect! Continue →
              </Button>
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-8">
            <div className="relative">
              <div className="mx-auto w-32 h-32 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-glow animate-pulse">
                <div className="text-6xl">🏅</div>
              </div>
              <div className="absolute -top-2 -right-2">
                <div className="w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center">
                  <div className="text-2xl">⭐</div>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h2 className="text-4xl font-bold rainbow-text">Congratulations!</h2>
              <p className="text-xl text-muted-foreground">You completed Lesson 2.2!</p>
            </div>
            
            <Card className="p-6 bg-gradient-to-br from-green-400 to-green-600 max-w-md mx-auto text-white">
              <div className="text-center space-y-2">
                <h3 className="text-2xl font-bold">🏅 Badge Earned!</h3>
                <p className="text-lg font-semibold">Color Master Badge</p>
                <div className="text-4xl">🎨🌈</div>
              </div>
            </Card>
            
            <div className="flex justify-center gap-4">
              <Button 
                onClick={() => navigate("/lesson21-intro")}
                variant="outline"
                className="text-lg font-bold px-8 py-3"
              >
                ← Previous Lesson
              </Button>
              <Button 
                onClick={() => navigate("/lesson23-intro")}
                className="text-lg font-bold px-8 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white"
              >
                Next Lesson →
              </Button>
            </div>
            
            <div className="text-6xl animate-bounce">🎉</div>
          </div>
        );

      default:
        return (
          <div className="text-center">
            <p className="text-2xl font-fredoka">More activities coming soon!</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-primary/10 p-4">
      <FloatingLogo />
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold rainbow-text mb-4">Unit 2 - Lesson 2.2</h1>
          <div className="flex items-center justify-center gap-4 mb-4">
            <Badge variant="outline" className="text-lg px-4 py-2">
              More Colors: Green, Black, White
            </Badge>
            <Badge variant="outline" className="text-lg px-4 py-2">
              Slide {currentSlide + 1} of {totalSlides}
            </Badge>
          </div>
          <Progress value={(currentSlide + 1) / totalSlides * 100} className="w-full max-w-md mx-auto" />
        </div>

        {/* Slide Content */}
        <div className="bg-white rounded-3xl shadow-fun p-8 mb-8 min-h-96">
          {renderSlide()}
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button 
            onClick={prevSlide} 
            disabled={currentSlide === 0}
            variant="outline"
            className="text-lg font-semibold"
          >
            ← Previous
          </Button>
          
          <div className="flex gap-2">
            {Array.from({ length: totalSlides }, (_, i) => (
              <button
                key={i}
                onClick={() => goToSlide(i)}
                className={`w-3 h-3 rounded-full transition-all ${
                  i === currentSlide 
                    ? 'bg-primary' 
                    : 'bg-muted hover:bg-primary/50'
                }`}
              />
            ))}
          </div>
          
          <Button 
            onClick={nextSlide} 
            disabled={currentSlide === totalSlides - 1}
            className="text-lg font-semibold"
          >
            Next →
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Lesson22;