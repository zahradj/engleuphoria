import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { Clock, Users, Target, Gamepad2, MessageCircle, Award } from "lucide-react";
import { AudioButton } from "@/components/AudioButton";
import { FloatingLogo } from "@/components/FloatingLogo";

export const Lesson41Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <FloatingLogo />
      
      <div className="max-w-4xl mx-auto pt-8">
        {/* Header */}
        <div className="text-center mb-8 space-y-4">
          <Badge variant="secondary" className="text-lg px-4 py-2">
            Unit 4 • Lesson 1
          </Badge>
          <div className="space-y-2">
            <h1 className="text-4xl md:text-6xl font-bold font-fredoka rainbow-text">
              🧍 My Body!
            </h1>
            <p className="text-xl md:text-2xl text-primary font-fredoka">
              Head, Eyes, Nose - Let's Learn Our Body Parts!
            </p>
          </div>
        </div>

        {/* Lesson Preview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="text-center p-4 bg-gradient-card hover-grow">
            <div className="text-4xl mb-2">👤</div>
            <p className="font-semibold">Head</p>
            <p className="text-sm text-muted-foreground">The top part</p>
          </Card>
          <Card className="text-center p-4 bg-gradient-card hover-grow">
            <div className="text-4xl mb-2">👀</div>
            <p className="font-semibold">Eyes</p>
            <p className="text-sm text-muted-foreground">We see with them</p>
          </Card>
          <Card className="text-center p-4 bg-gradient-card hover-grow">
            <div className="text-4xl mb-2">👃</div>
            <p className="font-semibold">Nose</p>
            <p className="text-sm text-muted-foreground">We smell with it</p>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Lesson Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <Target className="w-6 h-6" />
                  What We'll Learn Today
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-lesson-blue">👤 Body Parts</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Head - the top part</li>
                      <li>• Eyes - we see with them</li>
                      <li>• Nose - we smell with it</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-lesson-pink">💬 Body Sentences</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• "This is my head"</li>
                      <li>• "These are my eyes"</li>
                      <li>• "This is my nose"</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-lesson-green">🎵 Phonics G</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Letter G for Goat</li>
                      <li>• Review A-F letters</li>
                      <li>• Body parts phonics</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-lesson-purple">🎯 Games & Fun</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Simon Says activities</li>
                      <li>• Body matching games</li>
                      <li>• Speaking drills</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <Gamepad2 className="w-6 h-6" />
                  Fun Activities & Games
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🎯</span>
                      <div>
                        <p className="font-semibold">Simon Says Game</p>
                        <p className="text-sm text-muted-foreground">Touch your head, eyes, nose!</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🗣️</span>
                      <div>
                        <p className="font-semibold">Speaking Practice</p>
                        <p className="text-sm text-muted-foreground">"This is my..." sentences</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">📖</span>
                      <div>
                        <p className="font-semibold">Body Parts Story</p>
                        <p className="text-sm text-muted-foreground">Learn with Tom and Anna</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🧩</span>
                      <div>
                        <p className="font-semibold">Body Parts Puzzle</p>
                        <p className="text-sm text-muted-foreground">Place eyes and nose on face</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🎭</span>
                      <div>
                        <p className="font-semibold">Body Match Quiz</p>
                        <p className="text-sm text-muted-foreground">Where are the eyes?</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🎵</span>
                      <div>
                        <p className="font-semibold">Spin & Speak Wheel</p>
                        <p className="text-sm text-muted-foreground">Practice body sentences</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Lesson Info Sidebar */}
          <div className="space-y-6">
            <Card className="bg-gradient-accent text-white border-0 shadow-card">
              <CardHeader>
                <CardTitle className="text-white">Lesson Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5" />
                  <div>
                    <p className="font-semibold">Duration</p>
                    <p className="text-sm opacity-90">20-25 minutes</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="w-5 h-5" />
                  <div>
                    <p className="font-semibold">Class Size</p>
                    <p className="text-sm opacity-90">1-on-1 or Small Groups</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <MessageCircle className="w-5 h-5" />
                  <div>
                    <p className="font-semibold">Language Focus</p>
                    <p className="text-sm opacity-90">Body Parts Vocabulary</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Award className="w-5 h-5" />
                  <div>
                    <p className="font-semibold">Reward</p>
                    <p className="text-sm opacity-90">Body Explorer Badge</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="text-primary">Key Vocabulary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 gap-2">
                  <div className="text-center p-3 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg">
                    <div className="text-3xl">👤</div>
                    <p className="text-sm font-bold">Head</p>
                    <AudioButton text="head" className="text-xs" />
                  </div>
                  <div className="text-center p-3 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg">
                    <div className="text-3xl">👀</div>
                    <p className="text-sm font-bold">Eyes</p>
                    <AudioButton text="eyes" className="text-xs" />
                  </div>
                  <div className="text-center p-3 bg-gradient-to-r from-orange-100 to-pink-100 rounded-lg">
                    <div className="text-3xl">👃</div>
                    <p className="text-sm font-bold">Nose</p>
                    <AudioButton text="nose" className="text-xs" />
                  </div>
                </div>
                
                <div className="space-y-2 mt-4">
                  <h4 className="font-semibold text-sm">Key Sentences:</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center gap-2">
                      <span>💬</span>
                      <span>"This is my head."</span>
                      <AudioButton text="This is my head" className="text-xs" />
                    </div>
                    <div className="flex items-center gap-2">
                      <span>💬</span>
                      <span>"These are my eyes."</span>
                      <AudioButton text="These are my eyes" className="text-xs" />
                    </div>
                    <div className="flex items-center gap-2">
                      <span>💬</span>
                      <span>"This is my nose."</span>
                      <AudioButton text="This is my nose" className="text-xs" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Teacher Notes */}
        <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-l-4 border-l-warning mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-warning">
              👨‍🏫 One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <ul className="space-y-1 text-sm">
              <li>• Use Simon Says to make it physical and fun (student points to their own body)</li>
              <li>• Encourage full sentences, not just "Head"</li>
              <li>• Connect to real-life: Ask student to point to their head, eyes, nose in real time</li>
              <li>• Practice pronunciation clearly - body parts are fundamental vocabulary</li>
              <li>• Homework: Draw a face, label "head, eyes, nose"</li>
            </ul>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="text-lg px-8 py-6"
          >
            ← Back to Home
          </Button>
          <Button
            onClick={() => navigate("/lesson41")}
            className="text-lg px-8 py-6 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            Learn My Body! 🧍
          </Button>
        </div>
      </div>
    </div>
  );
};