import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";

const totalSlides = 20;

const Lesson33 = () => {
  const [currentSlide, setCurrentSlide] = useState(1);
  const [showBadgeReward, setShowBadgeReward] = useState(false);
  const navigate = useNavigate();

  const toys = ["ball", "car", "doll", "teddy"];
  const numbers = [1, 2, 3, 4, 5];
  
  const [basketItems, setBasketItems] = useState<string[]>([]);
  const [spinResult, setSpinResult] = useState<{toy: string, number: number} | null>(null);
  const [bingoClicked, setBingoClicked] = useState<number[]>([]);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [rolePlayCustomer, setRolePlayCustomer] = useState(true);

  const nextSlide = () => {
    if (currentSlide >= totalSlides) {
      setShowBadgeReward(true);
    } else {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const handleSpin = () => {
    const randomToy = toys[Math.floor(Math.random() * toys.length)];
    const randomNumber = numbers[Math.floor(Math.random() * numbers.length)];
    setSpinResult({ toy: randomToy, number: randomNumber });
  };

  const handleBingoClick = (index: number) => {
    if (!bingoClicked.includes(index)) {
      setBingoClicked(prev => [...prev, index]);
    }
  };

  const handleQuizAnswer = (answer: number) => {
    setQuizAnswers(prev => [...prev, answer]);
  };

  if (showBadgeReward) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
        <BadgeReward
          title="Toy Shop Champion!"
          description="You've mastered the toy shop role-play! Perfect numbers 1-5 and sentence work!"
          badgeName="Toy Shop Champion Badge 🏅"
          onContinue={() => navigate("/")}
        />
      </div>
    );
  }

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-8">
            <div className="flex justify-center gap-4">
              <div className="text-8xl animate-bounce-gentle">🛍️</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.3s'}}>🎈</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.6s'}}>🧸</div>
            </div>
            <h1 className="text-5xl font-bold font-fredoka rainbow-text">
              Toy Shop Role-Play!
            </h1>
            <p className="text-2xl font-fredoka text-primary">
              Welcome to our magical toy shop! Let's practice shopping! 🛒✨
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
              {toys.map((toy, index) => (
                <div key={toy} className="text-center">
                  <div className="text-6xl animate-pulse-fun" style={{animationDelay: `${index * 0.2}s`}}>
                    {toy === 'ball' ? '⚽' : toy === 'car' ? '🚗' : toy === 'doll' ? '👧' : '🧸'}
                  </div>
                  <p className="text-lg font-bold mt-2 capitalize">{toy}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🔢 Quick Review: Numbers 1-5!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Count aloud with me! Click each number card!
            </p>
            <div className="grid grid-cols-5 gap-4 max-w-3xl mx-auto">
              {numbers.map(num => (
                <Card 
                  key={num} 
                  className={`p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105 ${
                    quizAnswers.includes(num) ? 'border-success bg-success/10' : ''
                  }`}
                  onClick={() => handleQuizAnswer(num)}
                >
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto">
                      {num}
                    </div>
                    <div className="text-3xl">
                      {num === 1 ? '⚽' : 
                       num === 2 ? '⚽⚽' : 
                       num === 3 ? '⚽⚽⚽' : 
                       num === 4 ? '⚽⚽⚽⚽' : 
                       '⚽⚽⚽⚽⚽'}
                    </div>
                    <p className="text-lg font-bold">
                      {num === 1 ? 'ONE' : num === 2 ? 'TWO' : num === 3 ? 'THREE' : num === 4 ? 'FOUR' : 'FIVE'}
                    </p>
                    <AudioButton text={num.toString()} />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎵 Phonics Warm-Up: A-F Chant!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Let's chant together with rhythm! Clap your hands!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-4 max-w-4xl mx-auto">
              {['A', 'B', 'C', 'D', 'E', 'F'].map((letter, index) => (
                <Card key={letter} className="p-4 text-center hover:shadow-lg transition-all animate-bounce-gentle" style={{animationDelay: `${index * 0.2}s`}}>
                  <div className="space-y-3">
                    <div className="text-4xl font-bold text-primary">
                      {letter}{letter.toLowerCase()}
                    </div>
                    <p className="text-sm font-semibold">
                      {letter === 'A' ? 'Apple' : 
                       letter === 'B' ? 'Ball' : 
                       letter === 'C' ? 'Car' : 
                       letter === 'D' ? 'Doll' : 
                       letter === 'E' ? 'Elephant' :
                       'Fish'}
                    </p>
                    <div className="text-2xl">
                      {letter === 'A' ? '🍎' : 
                       letter === 'B' ? '⚽' : 
                       letter === 'C' ? '🚗' : 
                       letter === 'D' ? '👧' : 
                       letter === 'E' ? '🐘' :
                       '🐟'}
                    </div>
                    <AudioButton text={`${letter} is for ${letter === 'A' ? 'Apple' : letter === 'B' ? 'Ball' : letter === 'C' ? 'Car' : letter === 'D' ? 'Doll' : letter === 'E' ? 'Elephant' : 'Fish'}`} />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🧸 Toy Flashcards with Audio!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Listen and repeat each toy name!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {toys.map((toy, index) => (
                <Card key={toy} className="p-6 hover:shadow-lg transition-all hover:scale-105">
                  <div className="text-center space-y-4">
                    <div className="text-8xl animate-pulse-fun" style={{animationDelay: `${index * 0.3}s`}}>
                      {toy === 'ball' ? '⚽' : toy === 'car' ? '🚗' : toy === 'doll' ? '👧' : '🧸'}
                    </div>
                    <h3 className="text-2xl font-bold uppercase text-primary">{toy}</h3>
                    <AudioButton text={toy} className="text-lg" />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🔢 Counting Review: 1-5 with Toys!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Count each set and say the number aloud!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6 max-w-5xl mx-auto">
              {numbers.map(num => (
                <Card key={num} className="p-6 hover:shadow-lg transition-all">
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto">
                      {num}
                    </div>
                    <div className="space-y-2">
                      {Array.from({length: num}).map((_, i) => (
                        <div key={i} className="text-3xl inline-block mr-1">
                          {num === 1 ? '⚽' : num === 2 ? '🚗' : num === 3 ? '👧' : num === 4 ? '🧸' : '⚽'}
                        </div>
                      ))}
                    </div>
                    <p className="text-xl font-bold">
                      {num} {num === 1 ? toys[0] : num === 2 ? toys[1] + 's' : num === 3 ? toys[2] + 's' : num === 4 ? toys[3] + 's' : toys[0] + 's'}
                    </p>
                    <AudioButton text={`${num} ${num === 1 ? toys[0] : toys[0] + 's'}`} />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              💬 Model Sentence 1: "I have a car."
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Watch, listen, and repeat after me!
            </p>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-blue-400 to-purple-400 text-white">
              <div className="text-center space-y-6">
                <div className="text-9xl">🚗</div>
                <div className="bg-white/20 p-6 rounded-xl">
                  <h3 className="text-3xl font-bold mb-4">I have a car.</h3>
                  <AudioButton text="I have a car" className="text-xl text-white border-white" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👆 Point to yourself</p>
                    <p className="text-2xl">I</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">🤲 Hold gesture</p>
                    <p className="text-2xl">have</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">🚗 Point to car</p>
                    <p className="text-2xl">a car</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              💬 Model Sentence 2: "I want a teddy."
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Practice the "want" sentence pattern!
            </p>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-pink-400 to-orange-400 text-white">
              <div className="text-center space-y-6">
                <div className="text-9xl">🧸</div>
                <div className="bg-white/20 p-6 rounded-xl">
                  <h3 className="text-3xl font-bold mb-4">I want a teddy.</h3>
                  <AudioButton text="I want a teddy" className="text-xl text-white border-white" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👆 Point to yourself</p>
                    <p className="text-2xl">I</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">🙏 Reach gesture</p>
                    <p className="text-2xl">want</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">🧸 Point to teddy</p>
                    <p className="text-2xl">a teddy</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🗣️ Speaking Drill: Teacher Shows → You Answer!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Use "I have..." or "I want..." sentences!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {toys.map((toy, index) => (
                <Card key={toy} className="p-6 hover:shadow-lg transition-all hover:scale-105 cursor-pointer">
                  <div className="text-center space-y-4">
                    <div className="text-8xl">
                      {toy === 'ball' ? '⚽' : toy === 'car' ? '🚗' : toy === 'doll' ? '👧' : '🧸'}
                    </div>
                    <SpeakingActivity 
                      prompt={`Say: "I have a ${toy}"`}
                      expectedResponse={`I have a ${toy}`}
                      onComplete={() => {}}
                    />
                    <div className="text-sm text-muted-foreground">
                      or "I want a {toy}"
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 9:
        return (
          <DragDropActivity
            title="🔢 Drag & Drop: Match Numbers to Toy Sets!"
            items={[
              { id: '1', content: '1', type: 'source', matchId: 'one-ball' },
              { id: '2', content: '2', type: 'source', matchId: 'two-cars' },
              { id: '3', content: '3', type: 'source', matchId: 'three-dolls' },
              { id: '4', content: '4', type: 'source', matchId: 'four-teddies' },
              { id: '5', content: '5', type: 'source', matchId: 'five-balls' },
              { id: 'one-ball', content: '⚽', type: 'target' },
              { id: 'two-cars', content: '🚗🚗', type: 'target' },
              { id: 'three-dolls', content: '👧👧👧', type: 'target' },
              { id: 'four-teddies', content: '🧸🧸🧸🧸', type: 'target' },
              { id: 'five-balls', content: '⚽⚽⚽⚽⚽', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 10:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎲 Spin & Speak Wheel!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Spin the wheel and say the sentence! Example: "Three cars."
            </p>
            <div className="space-y-6">
              <div className="relative w-64 h-64 mx-auto">
                <div className="w-full h-full bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center border-8 border-white shadow-lg cursor-pointer hover:scale-105 transition-all" onClick={handleSpin}>
                  <div className="text-center text-white">
                    <div className="text-6xl mb-2">🎰</div>
                    <p className="text-xl font-bold">SPIN!</p>
                  </div>
                </div>
              </div>
              
              {spinResult && (
                <Card className="p-8 max-w-md mx-auto bg-gradient-accent text-white">
                  <div className="text-center space-y-4">
                    <div className="text-6xl">
                      {spinResult.toy === 'ball' ? '⚽' : spinResult.toy === 'car' ? '🚗' : spinResult.toy === 'doll' ? '👧' : '🧸'}
                    </div>
                    <h3 className="text-3xl font-bold">
                      {spinResult.number} {spinResult.toy}{spinResult.number > 1 ? 's' : ''}
                    </h3>
                    <SpeakingActivity 
                      prompt={`Say: "${spinResult.number} ${spinResult.toy}${spinResult.number > 1 ? 's' : ''}"`}
                      expectedResponse={`${spinResult.number} ${spinResult.toy}${spinResult.number > 1 ? 's' : ''}`}
                      onComplete={() => {}}
                    />
                  </div>
                </Card>
              )}
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎯 Toy Bingo Board!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher calls a toy → Click the correct square!
            </p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              {[
                { toy: 'ball', emoji: '⚽', id: 0 },
                { toy: 'car', emoji: '🚗', id: 1 },
                { toy: 'doll', emoji: '👧', id: 2 },
                { toy: 'teddy', emoji: '🧸', id: 3 },
                { toy: 'ball', emoji: '⚽', id: 4 },
                { toy: 'car', emoji: '🚗', id: 5 },
                { toy: 'doll', emoji: '👧', id: 6 },
                { toy: 'teddy', emoji: '🧸', id: 7 },
                { toy: 'ball', emoji: '⚽', id: 8 }
              ].map((item) => (
                <Card 
                  key={item.id}
                  className={`p-8 cursor-pointer hover:shadow-lg transition-all hover:scale-105 ${
                    bingoClicked.includes(item.id) ? 'bg-success text-white' : ''
                  }`}
                  onClick={() => handleBingoClick(item.id)}
                >
                  <div className="text-center">
                    <div className="text-4xl mb-2">{item.emoji}</div>
                    <p className="text-sm font-bold uppercase">{item.toy}</p>
                  </div>
                </Card>
              ))}
            </div>
            <div className="text-center">
              <Badge variant="secondary" className="text-lg px-4 py-2">
                Clicked: {bingoClicked.length}/9 squares
              </Badge>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              ❓ Quick Quiz: How Many Dolls?
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Count the dolls and choose the correct answer!
            </p>
            <div className="space-y-6">
              <div className="flex justify-center gap-2 flex-wrap">
                {Array.from({length: 3}).map((_, i) => (
                  <div key={i} className="text-6xl animate-bounce" style={{animationDelay: `${i * 0.2}s`}}>👧</div>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                {[2, 3, 4].map(option => (
                  <Card key={option} className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105">
                    <div className="text-center space-y-2">
                      <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto">
                        {option}
                      </div>
                      <Button variant={option === 3 ? "default" : "outline"} className="capitalize">
                        {option === 2 ? 'Two' : option === 3 ? 'Three' : 'Four'}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🔍 Toy Hunt Scene!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Find and click all the hidden toys in the classroom!
            </p>
            <Card className="p-8 max-w-4xl mx-auto bg-gradient-to-br from-yellow-100 to-blue-100">
              <div className="relative">
                <div className="grid grid-cols-6 gap-4 min-h-64">
                  {/* Classroom scene with hidden toys */}
                  <div className="col-span-2 text-6xl cursor-pointer hover:scale-110 transition-all" onClick={() => handleBingoClick(10)}>📚</div>
                  <div className="text-4xl cursor-pointer hover:scale-110 transition-all" onClick={() => handleBingoClick(11)}>⚽</div>
                  <div className="col-span-2 text-6xl">🪑</div>
                  <div className="text-4xl cursor-pointer hover:scale-110 transition-all" onClick={() => handleBingoClick(12)}>🚗</div>
                  
                  <div className="text-6xl">🖥️</div>
                  <div className="text-4xl cursor-pointer hover:scale-110 transition-all" onClick={() => handleBingoClick(13)}>👧</div>
                  <div className="col-span-2 text-6xl">📝</div>
                  <div className="text-6xl">🗂️</div>
                  <div className="text-4xl cursor-pointer hover:scale-110 transition-all" onClick={() => handleBingoClick(14)}>🧸</div>
                  
                  <div className="col-span-2 text-6xl">🪟</div>
                  <div className="text-6xl">🎨</div>
                  <div className="col-span-2 text-6xl">📐</div>
                  <div className="text-6xl">✏️</div>
                </div>
                
                <div className="mt-6 text-center">
                  <Badge variant="secondary" className="text-lg px-4 py-2">
                    Found toys: {bingoClicked.filter(id => id >= 10).length}/5
                  </Badge>
                </div>
              </div>
            </Card>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📖 Mini Comic 1: Anna Shops!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Read along and practice the dialogue!
            </p>
            <Card className="p-8 max-w-3xl mx-auto bg-gradient-to-r from-pink-100 to-purple-100">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="text-center space-y-4">
                  <div className="text-8xl">👧</div>
                  <h3 className="text-xl font-bold">Anna (Customer)</h3>
                  <div className="bg-white p-4 rounded-xl speech-bubble-left">
                    <p className="text-lg">"I want a ball."</p>
                    <AudioButton text="I want a ball" />
                  </div>
                </div>
                <div className="text-center space-y-4">
                  <div className="text-8xl">👨‍💼</div>
                  <h3 className="text-xl font-bold">Shopkeeper</h3>
                  <div className="bg-white p-4 rounded-xl speech-bubble-right">
                    <p className="text-lg">"Here you are."</p>
                    <AudioButton text="Here you are" />
                  </div>
                </div>
              </div>
              <div className="text-center mt-6">
                <div className="text-4xl">⚽ → 👧</div>
                <p className="text-sm text-muted-foreground mt-2">Anna gets her ball!</p>
              </div>
            </Card>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📖 Mini Comic 2: Tom Shops!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Practice shopping with numbers!
            </p>
            <Card className="p-8 max-w-3xl mx-auto bg-gradient-to-r from-blue-100 to-green-100">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="text-center space-y-4">
                  <div className="text-8xl">👦</div>
                  <h3 className="text-xl font-bold">Tom (Customer)</h3>
                  <div className="bg-white p-4 rounded-xl speech-bubble-left">
                    <p className="text-lg">"I want two teddies."</p>
                    <AudioButton text="I want two teddies" />
                  </div>
                </div>
                <div className="text-center space-y-4">
                  <div className="text-8xl">👨‍💼</div>
                  <h3 className="text-xl font-bold">Shopkeeper</h3>
                  <div className="bg-white p-4 rounded-xl speech-bubble-right">
                    <p className="text-lg">"Here you are."</p>
                    <AudioButton text="Here you are" />
                  </div>
                </div>
              </div>
              <div className="text-center mt-6">
                <div className="text-4xl">🧸🧸 → 👦</div>
                <p className="text-sm text-muted-foreground mt-2">Tom gets his two teddies!</p>
              </div>
            </Card>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎭 Role-Play Task 1: You are the Customer!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher plays shopkeeper. Answer: "I want a ___."
            </p>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-green-400 to-blue-400 text-white">
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-8xl mb-4">👨‍💼</div>
                  <h3 className="text-2xl font-bold mb-4">Teacher (Shopkeeper) asks:</h3>
                  <div className="bg-white/20 p-6 rounded-xl">
                    <p className="text-2xl">"What do you want?"</p>
                    <AudioButton text="What do you want?" className="mt-2 text-white border-white" />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {toys.map((toy) => (
                    <Card key={toy} className="p-4 bg-white/10 hover:bg-white/20 transition-all cursor-pointer">
                      <div className="text-center">
                        <div className="text-3xl mb-2">
                          {toy === 'ball' ? '⚽' : toy === 'car' ? '🚗' : toy === 'doll' ? '👧' : '🧸'}
                        </div>
                        <SpeakingActivity 
                          prompt={`Click & say: "I want a ${toy}"`}
                          expectedResponse={`I want a ${toy}`}
                          onComplete={() => {}}
                        />
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎭 Role-Play Task 2: You are the Shopkeeper!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Student asks for toys. Answer: "Here you are."
            </p>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-purple-400 to-pink-400 text-white">
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-8xl mb-4">👦</div>
                  <h3 className="text-2xl font-bold mb-4">Student (Customer) says:</h3>
                  <div className="bg-white/20 p-6 rounded-xl">
                    <p className="text-2xl">"I want a car."</p>
                    <AudioButton text="I want a car" className="mt-2 text-white border-white" />
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="text-8xl mb-4">👨‍💼</div>
                  <h3 className="text-xl font-bold mb-4">You (Shopkeeper) answer:</h3>
                  <SpeakingActivity 
                    prompt="Say: 'Here you are.'"
                    expectedResponse="Here you are"
                    onComplete={() => {}}
                  />
                  <div className="mt-4 text-6xl">🚗 → 👦</div>
                </div>
                
                <Button 
                  className="bg-white/20 hover:bg-white/30 border-white text-white"
                  onClick={() => setRolePlayCustomer(!rolePlayCustomer)}
                >
                  Switch Roles & Practice Again
                </Button>
              </div>
            </Card>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🧠 Review Quiz: Numbers + Toys!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Answer the mixed questions! Pick the correct answer!
            </p>
            <div className="space-y-6">
              <Card className="p-6 max-w-2xl mx-auto">
                <div className="space-y-4">
                  <h3 className="text-xl font-bold">Question: How many cars?</h3>
                  <div className="flex justify-center gap-2">
                    {Array.from({length: 4}).map((_, i) => (
                      <div key={i} className="text-4xl">🚗</div>
                    ))}
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    {[3, 4, 5].map(option => (
                      <Button key={option} variant={option === 4 ? "default" : "outline"} onClick={() => handleQuizAnswer(option)}>
                        {option}
                      </Button>
                    ))}
                  </div>
                </div>
              </Card>
              
              <Card className="p-6 max-w-2xl mx-auto">
                <div className="space-y-4">
                  <h3 className="text-xl font-bold">Complete: "I ___ a teddy."</h3>
                  <div className="text-6xl">🧸</div>
                  <div className="grid grid-cols-3 gap-4">
                    {['want', 'have', 'like'].map(option => (
                      <Button key={option} variant={option === 'want' ? "default" : "outline"}>
                        {option}
                      </Button>
                    ))}
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎵 Phonics Recap: A-F with Toy Words!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Final chant with all our letters and toy words!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-4 max-w-4xl mx-auto">
              {[
                { letter: 'A', word: 'Apple', emoji: '🍎' },
                { letter: 'B', word: 'Ball', emoji: '⚽' },
                { letter: 'C', word: 'Car', emoji: '🚗' },
                { letter: 'D', word: 'Doll', emoji: '👧' },
                { letter: 'E', word: 'Elephant', emoji: '🐘' },
                { letter: 'F', word: 'Fish', emoji: '🐟' }
              ].map((item, index) => (
                <Card key={item.letter} className="p-4 text-center hover:shadow-lg transition-all animate-bounce-gentle" style={{animationDelay: `${index * 0.3}s`}}>
                  <div className="space-y-3">
                    <div className="text-3xl font-bold text-primary">
                      {item.letter}{item.letter.toLowerCase()}
                    </div>
                    <div className="text-3xl">{item.emoji}</div>
                    <p className="text-sm font-bold">{item.word}</p>
                    <AudioButton text={`${item.letter} is for ${item.word}`} />
                  </div>
                </Card>
              ))}
            </div>
            
            <Card className="p-6 max-w-2xl mx-auto bg-gradient-primary text-white">
              <h3 className="text-xl font-bold mb-4">Final Chant Together!</h3>
              <p className="text-lg leading-relaxed">
                🎵 A is for Apple, B is for Ball,<br/>
                C is for Car, D is for Doll,<br/>
                E is for Elephant, F is for Fish,<br/>
                Learning letters is our wish! 🎵
              </p>
              <AudioButton text="A is for Apple, B is for Ball, C is for Car, D is for Doll, E is for Elephant, F is for Fish" className="mt-4 text-white border-white" />
            </Card>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-8">
            <div className="flex justify-center gap-4">
              <div className="text-8xl animate-bounce-gentle">🏅</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.3s'}}>🎉</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.6s'}}>✨</div>
            </div>
            <h1 className="text-5xl font-bold font-fredoka rainbow-text">
              Congratulations!
            </h1>
            <h2 className="text-3xl font-bold text-primary">
              Toy Shop Champion Badge! 🏅
            </h2>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-gold to-yellow-400 text-white">
              <div className="text-center space-y-6">
                <div className="text-9xl">🏆</div>
                <h3 className="text-2xl font-bold">AMAZING PROGRESS!</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="bg-white/20 p-3 rounded-lg">
                    <p className="font-bold">✅ Numbers 1-5</p>
                    <p>Perfect counting!</p>
                  </div>
                  <div className="bg-white/20 p-3 rounded-lg">
                    <p className="font-bold">✅ Toy Vocabulary</p>
                    <p>Ball, car, doll, teddy!</p>
                  </div>
                  <div className="bg-white/20 p-3 rounded-lg">
                    <p className="font-bold">✅ Role-Play</p>
                    <p>Shopping sentences!</p>
                  </div>
                  <div className="bg-white/20 p-3 rounded-lg">
                    <p className="font-bold">✅ Phonics A-F</p>
                    <p>Letter mastery!</p>
                  </div>
                </div>
                <div className="bg-white/10 p-4 rounded-xl">
                  <p className="text-lg font-bold mb-2">🎉 CONFETTI CELEBRATION! 🎉</p>
                  <AudioButton text="Congratulations! You are a toy shop champion!" className="text-white border-white" />
                </div>
              </div>
            </Card>
            <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-6 rounded-xl max-w-md mx-auto">
              <h4 className="text-lg font-bold text-gray-800 mb-2">📝 Mini Homework:</h4>
              <p className="text-gray-700">Draw your toy shop at home with 3-5 toys and label them!</p>
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-fun">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <Badge variant="secondary" className="text-sm mb-4">
              Unit 3 • Lesson 3 • Toy Shop Role-Play
            </Badge>
            <ProgressBar current={currentSlide} total={totalSlides} className="mb-4" />
            <p className="text-muted-foreground">
              Slide {currentSlide} of {totalSlides}
            </p>
          </div>

          {/* Slide Content */}
          <Card className="bg-gradient-card border-0 shadow-card min-h-[500px] flex items-center">
            <div className="w-full p-8">
              {renderSlide()}
            </div>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between items-center mt-8">
            <Button
              variant="outline"
              onClick={prevSlide}
              disabled={currentSlide === 1}
              className="flex items-center gap-2"
            >
              ← Previous
            </Button>

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => navigate("/")}>
                🏠 Home
              </Button>
            </div>

            <Button
              onClick={nextSlide}
              className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
            >
              {currentSlide >= totalSlides ? "Complete!" : "Next →"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Lesson33;