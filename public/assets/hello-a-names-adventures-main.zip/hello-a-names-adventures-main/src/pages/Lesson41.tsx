import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";

const totalSlides = 21;

const Lesson41 = () => {
  const [currentSlide, setCurrentSlide] = useState(1);
  const [showBadgeReward, setShowBadgeReward] = useState(false);
  const navigate = useNavigate();

  const bodyParts = [
    { name: "head", emoji: "👤", description: "The top part of your body" },
    { name: "eyes", emoji: "👀", description: "We see with our eyes" },
    { name: "nose", emoji: "👃", description: "We smell with our nose" }
  ];

  const [simonSaysClicked, setSimonSaysClicked] = useState<string[]>([]);
  const [quizAnswers, setQuizAnswers] = useState<string[]>([]);
  const [spinResult, setSpinResult] = useState("");

  const nextSlide = () => {
    if (currentSlide >= totalSlides) {
      setShowBadgeReward(true);
    } else {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const handleSimonSaysClick = (part: string) => {
    if (!simonSaysClicked.includes(part)) {
      setSimonSaysClicked(prev => [...prev, part]);
    }
  };

  const handleSpinWheel = () => {
    const parts = ["head", "eyes", "nose"];
    const randomPart = parts[Math.floor(Math.random() * parts.length)];
    setSpinResult(randomPart);
  };

  const handleQuizAnswer = (answer: string) => {
    setQuizAnswers(prev => [...prev, answer]);
  };

  if (showBadgeReward) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
        <BadgeReward
          title="Body Explorer!"
          description="You've learned all about body parts! Amazing work with head, eyes, and nose!"
          badgeName="Body Explorer Badge 🧍"
          onContinue={() => navigate("/")}
        />
      </div>
    );
  }

  const renderSlide = () => {
    switch (currentSlide) {
      // Slides 1-3: Warm-Up & Transition
      case 1:
        return (
          <div className="text-center space-y-8">
            <div className="flex justify-center gap-4">
              <div className="text-8xl animate-bounce-gentle">🧍</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.3s'}}>👤</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.6s'}}>👀</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.9s'}}>👃</div>
            </div>
            <h1 className="text-5xl font-bold font-fredoka rainbow-text">
              My Body!
            </h1>
            <p className="text-2xl font-fredoka text-primary">
              Let's learn about our amazing body! Head, Eyes, Nose! 🧍
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
              {bodyParts.map((part, index) => (
                <Card key={part.name} className="p-6 hover:shadow-lg transition-all hover:scale-105">
                  <div className="text-center space-y-3">
                    <div className="text-6xl animate-pulse-fun" style={{animationDelay: `${index * 0.2}s`}}>
                      {part.emoji}
                    </div>
                    <h3 className="text-xl font-bold capitalize text-primary">{part.name}</h3>
                    <p className="text-sm text-muted-foreground">{part.description}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🔄 Quick Review - Toys & Numbers!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Let's remember what we learned in Unit 3!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              <Card className="p-4 text-center hover:shadow-lg transition-all">
                <div className="text-4xl mb-2">🚗</div>
                <p className="font-semibold">Car</p>
                <p className="text-sm text-muted-foreground">1 car</p>
              </Card>
              <Card className="p-4 text-center hover:shadow-lg transition-all">
                <div className="text-4xl mb-2">🪀</div>
                <p className="font-semibold">Yo-yo</p>
                <p className="text-sm text-muted-foreground">2 yo-yos</p>
              </Card>
              <Card className="p-4 text-center hover:shadow-lg transition-all">
                <div className="text-4xl mb-2">🧸</div>
                <p className="font-semibold">Teddy</p>
                <p className="text-sm text-muted-foreground">3 teddies</p>
              </Card>
              <Card className="p-4 text-center hover:shadow-lg transition-all">
                <div className="text-4xl mb-2">⚽</div>
                <p className="font-semibold">Ball</p>
                <p className="text-sm text-muted-foreground">4 balls</p>
              </Card>
            </div>
            <Card className="p-6 max-w-md mx-auto bg-gradient-accent text-white">
              <h3 className="text-xl font-bold mb-2">Great job remembering!</h3>
              <p className="text-lg">Now let's learn about our body! 🧍</p>
            </Card>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎵 Phonics Warm-Up: A-F Review + New Letter G!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Let's chant A-F and learn new letter G for Goat!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-7 gap-4 max-w-5xl mx-auto">
              {['A', 'B', 'C', 'D', 'E', 'F', 'G'].map((letter, index) => (
                <Card key={letter} className="p-4 text-center hover:shadow-lg transition-all animate-bounce-gentle" style={{animationDelay: `${index * 0.2}s`}}>
                  <div className="space-y-3">
                    <div className={`text-4xl font-bold ${letter === 'G' ? 'text-accent animate-pulse' : 'text-primary'}`}>
                      {letter}{letter.toLowerCase()}
                    </div>
                    <p className="text-sm font-semibold">
                      {letter === 'A' ? 'Apple' : 
                       letter === 'B' ? 'Ball' : 
                       letter === 'C' ? 'Car' : 
                       letter === 'D' ? 'Doll' : 
                       letter === 'E' ? 'Elephant' :
                       letter === 'F' ? 'Fish' :
                       'Goat'}
                    </p>
                    <div className="text-2xl">
                      {letter === 'A' ? '🍎' : 
                       letter === 'B' ? '⚽' : 
                       letter === 'C' ? '🚗' : 
                       letter === 'D' ? '🪆' : 
                       letter === 'E' ? '🐘' :
                       letter === 'F' ? '🐟' :
                       '🐐'}
                    </div>
                    <AudioButton text={letter} />
                  </div>
                </Card>
              ))}
            </div>
            <Card className="p-6 max-w-md mx-auto bg-gradient-accent text-white">
              <h3 className="text-xl font-bold mb-2">New Letter: G</h3>
              <p className="text-lg">G says /g/ like Goat, Girl, Go! 🐐</p>
              <AudioButton text="G for Goat" className="mt-2 text-white border-white" />
            </Card>
          </div>
        );

      // Slides 4-8: Vocabulary Building
      case 4:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              👤 Flashcard: Head
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Tap to see the head highlight! This is the top part of your body!
            </p>
            <div className="space-y-6">
              <div className="text-9xl cursor-pointer hover:scale-110 transition-all animate-bounce-gentle">
                👤
              </div>
              <Card className="p-8 max-w-md mx-auto bg-gradient-to-r from-blue-400 to-purple-400 text-white">
                <div className="text-center space-y-4">
                  <h3 className="text-4xl font-bold">HEAD</h3>
                  <AudioButton text="head" className="text-xl text-white border-white" />
                  <p className="text-lg">Touch your head! 👤</p>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <p className="text-sm">Your head has your brain, hair, and face!</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              👀 Flashcard: Eyes
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Tap to see the eyes blink! We see with our eyes!
            </p>
            <div className="space-y-6">
              <div className="text-9xl cursor-pointer hover:scale-110 transition-all animate-bounce-gentle">
                👀
              </div>
              <Card className="p-8 max-w-md mx-auto bg-gradient-to-r from-green-400 to-blue-400 text-white">
                <div className="text-center space-y-4">
                  <h3 className="text-4xl font-bold">EYES</h3>
                  <AudioButton text="eyes" className="text-xl text-white border-white" />
                  <p className="text-lg">Point to your eyes! 👀</p>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <p className="text-sm">You have two eyes to see the world!</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              👃 Flashcard: Nose
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Tap to see the nose wiggle and sniff! We smell with our nose!
            </p>
            <div className="space-y-6">
              <div className="text-9xl cursor-pointer hover:scale-110 transition-all animate-bounce-gentle">
                👃
              </div>
              <Card className="p-8 max-w-md mx-auto bg-gradient-to-r from-orange-400 to-pink-400 text-white">
                <div className="text-center space-y-4">
                  <h3 className="text-4xl font-bold">NOSE</h3>
                  <AudioButton text="nose" className="text-xl text-white border-white" />
                  <p className="text-lg">Touch your nose! 👃</p>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <p className="text-sm">Your nose helps you smell flowers and food!</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🔊 Audio Buttons - Click to Hear!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Click each body part to hear the pronunciation!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {bodyParts.map((part, index) => (
                <Card key={part.name} className="p-8 hover:shadow-lg transition-all hover:scale-105">
                  <div className="text-center space-y-4">
                    <div className="text-8xl animate-pulse-fun" style={{animationDelay: `${index * 0.3}s`}}>
                      {part.emoji}
                    </div>
                    <h3 className="text-2xl font-bold uppercase text-primary">{part.name}</h3>
                    <AudioButton text={part.name} className="text-lg" />
                    <p className="text-sm text-muted-foreground">{part.description}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 8:
        return (
          <DragDropActivity
            title="🧩 Drag & Drop Puzzle - Complete the Face!"
            items={[
              { id: 'eyes-word', content: 'Eyes 👀', type: 'source', matchId: 'eyes-face' },
              { id: 'nose-word', content: 'Nose 👃', type: 'source', matchId: 'nose-face' },
              { id: 'eyes-face', content: '👤 Eyes go here', type: 'target' },
              { id: 'nose-face', content: '👤 Nose goes here', type: 'target' }
            ]}
            onComplete={() => {}}
          />
        );

      // Slides 9-13: Sentence Practice
      case 9:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              💬 Model Sentence 1: "This is my head."
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Learn to talk about your head!
            </p>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-blue-400 to-purple-400 text-white">
              <div className="text-center space-y-6">
                <div className="text-9xl">👤</div>
                <div className="bg-white/20 p-6 rounded-xl">
                  <h3 className="text-3xl font-bold mb-4">This is my head.</h3>
                  <AudioButton text="This is my head" className="text-xl text-white border-white" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👆 Point gesture</p>
                    <p className="text-2xl">This is</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👆 Point to yourself</p>
                    <p className="text-2xl">my</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👤 Touch head</p>
                    <p className="text-2xl">head</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              💬 Model Sentence 2: "These are my eyes."
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Learn to talk about your eyes! Notice "These are" for two eyes!
            </p>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-green-400 to-blue-400 text-white">
              <div className="text-center space-y-6">
                <div className="text-9xl">👀</div>
                <div className="bg-white/20 p-6 rounded-xl">
                  <h3 className="text-3xl font-bold mb-4">These are my eyes.</h3>
                  <AudioButton text="These are my eyes" className="text-xl text-white border-white" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👆 Point gesture</p>
                    <p className="text-2xl">These are</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👆 Point to yourself</p>
                    <p className="text-2xl">my</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👀 Point to eyes</p>
                    <p className="text-2xl">eyes</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              💬 Model Sentence 3: "This is my nose."
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Learn to talk about your nose!
            </p>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-orange-400 to-pink-400 text-white">
              <div className="text-center space-y-6">
                <div className="text-9xl">👃</div>
                <div className="bg-white/20 p-6 rounded-xl">
                  <h3 className="text-3xl font-bold mb-4">This is my nose.</h3>
                  <AudioButton text="This is my nose" className="text-xl text-white border-white" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👆 Point gesture</p>
                    <p className="text-2xl">This is</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👆 Point to yourself</p>
                    <p className="text-2xl">my</p>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <p className="text-sm font-semibold">👃 Touch nose</p>
                    <p className="text-2xl">nose</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🗣️ Speaking Drill - Teacher Shows, You Say!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              When teacher points to a body part, say the full sentence!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <Card className="p-6 hover:shadow-lg transition-all hover:scale-105">
                <div className="text-center space-y-4">
                  <div className="text-8xl">👤</div>
                  <SpeakingActivity 
                    prompt="Teacher points to head - You say:"
                    expectedResponse="This is my head"
                    onComplete={() => {}}
                  />
                </div>
              </Card>
              <Card className="p-6 hover:shadow-lg transition-all hover:scale-105">
                <div className="text-center space-y-4">
                  <div className="text-8xl">👀</div>
                  <SpeakingActivity 
                    prompt="Teacher points to eyes - You say:"
                    expectedResponse="These are my eyes"
                    onComplete={() => {}}
                  />
                </div>
              </Card>
              <Card className="p-6 hover:shadow-lg transition-all hover:scale-105">
                <div className="text-center space-y-4">
                  <div className="text-8xl">👃</div>
                  <SpeakingActivity 
                    prompt="Teacher points to nose - You say:"
                    expectedResponse="This is my nose"
                    onComplete={() => {}}
                  />
                </div>
              </Card>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🧩 Sentence Builder - Drag Words into Order!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Put the words in the right order: "This is my nose."
            </p>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="text-6xl">👃</div>
                <div className="bg-muted p-4 rounded-xl mb-4">
                  <p className="text-lg font-semibold">Target sentence:</p>
                  <p className="text-2xl">"This is my nose."</p>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-primary text-white rounded-lg cursor-move text-center font-semibold">
                    This
                  </div>
                  <div className="p-4 bg-primary text-white rounded-lg cursor-move text-center font-semibold">
                    is
                  </div>
                  <div className="p-4 bg-primary text-white rounded-lg cursor-move text-center font-semibold">
                    my
                  </div>
                  <div className="p-4 bg-primary text-white rounded-lg cursor-move text-center font-semibold">
                    nose
                  </div>
                </div>
                <div className="border-2 border-dashed border-muted-foreground p-4 rounded-xl min-h-16">
                  <p className="text-muted-foreground">Drag words here to build the sentence</p>
                </div>
              </div>
            </Card>
          </div>
        );

      // Slides 14-17: Games & Fun
      case 14:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎯 Simon Says Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Listen to Simon and click the correct body part!
            </p>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="bg-accent text-white p-4 rounded-xl">
                  <h3 className="text-2xl font-bold">Simon Says:</h3>
                  <p className="text-xl">"Touch your head!"</p>
                  <AudioButton text="Touch your head" className="mt-2 text-white border-white" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {bodyParts.map((part) => (
                    <Card 
                      key={part.name} 
                      className={`p-6 cursor-pointer transition-all hover:scale-105 ${
                        simonSaysClicked.includes(part.name) ? 'bg-success text-white' : 'hover:shadow-lg'
                      }`}
                      onClick={() => handleSimonSaysClick(part.name)}
                    >
                      <div className="text-center space-y-3">
                        <div className="text-6xl">{part.emoji}</div>
                        <p className="text-lg font-bold capitalize">{part.name}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              ❓ Body Match Quiz: "Where are the eyes?"
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Click the correct body part when asked!
            </p>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="bg-warning text-white p-4 rounded-xl">
                  <h3 className="text-2xl font-bold">Question:</h3>
                  <p className="text-xl">"Where are the eyes?"</p>
                  <AudioButton text="Where are the eyes" className="mt-2 text-white border-white" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {bodyParts.map((part) => (
                    <Card 
                      key={part.name} 
                      className="p-6 cursor-pointer transition-all hover:scale-105 hover:shadow-lg"
                      onClick={() => handleQuizAnswer(part.name)}
                    >
                      <div className="text-center space-y-3">
                        <div className="text-6xl">{part.emoji}</div>
                        <p className="text-lg font-bold capitalize">{part.name}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎡 Spin & Speak Wheel!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Spin the wheel and say the sentence for the body part!
            </p>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="relative">
                  <div className="w-48 h-48 mx-auto bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center cursor-pointer transition-all hover:scale-105" onClick={handleSpinWheel}>
                    <div className="text-center text-white">
                      <div className="text-4xl mb-2">🎡</div>
                      <p className="font-bold">SPIN ME!</p>
                    </div>
                  </div>
                </div>
                {spinResult && (
                  <div className="bg-success text-white p-6 rounded-xl">
                    <h3 className="text-xl font-bold mb-2">You got: {spinResult}!</h3>
                    <div className="text-4xl mb-2">
                      {spinResult === 'head' ? '👤' : spinResult === 'eyes' ? '👀' : '👃'}
                    </div>
                    <p className="text-lg">
                      Now say: "{spinResult === 'eyes' ? 'These are my eyes' : `This is my ${spinResult}`}"
                    </p>
                    <AudioButton 
                      text={spinResult === 'eyes' ? 'These are my eyes' : `This is my ${spinResult}`} 
                      className="mt-2 text-white border-white" 
                    />
                  </div>
                )}
              </div>
            </Card>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🔍 Guess the Part Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Look at the silhouette and guess which body part it is!
            </p>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="bg-muted p-8 rounded-xl">
                  <div className="text-8xl text-muted-foreground">❓</div>
                  <p className="text-xl font-bold mt-4">Mystery Body Part</p>
                  <p className="text-muted-foreground">Click to reveal!</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {bodyParts.map((part) => (
                    <Card key={part.name} className="p-6 cursor-pointer transition-all hover:scale-105 hover:shadow-lg">
                      <div className="text-center space-y-3">
                        <div className="text-6xl">{part.emoji}</div>
                        <p className="text-lg font-bold capitalize">{part.name}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        );

      // Slides 18-20: Story & Review
      case 18:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📖 Mini Comic 1 - Tom and Anna!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Listen to Tom and Anna talk about their body parts!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <Card className="p-6 bg-gradient-to-r from-blue-400 to-purple-400 text-white">
                <div className="text-center space-y-4">
                  <div className="text-6xl">👦</div>
                  <h3 className="text-xl font-bold">Tom says:</h3>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <p className="text-lg">"This is my head."</p>
                    <div className="text-4xl mt-2">👤</div>
                  </div>
                  <AudioButton text="This is my head" className="text-white border-white" />
                </div>
              </Card>
              <Card className="p-6 bg-gradient-to-r from-pink-400 to-rose-400 text-white">
                <div className="text-center space-y-4">
                  <div className="text-6xl">👧</div>
                  <h3 className="text-xl font-bold">Anna says:</h3>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <p className="text-lg">"These are my eyes."</p>
                    <div className="text-4xl mt-2">👀</div>
                  </div>
                  <AudioButton text="These are my eyes" className="text-white border-white" />
                </div>
              </Card>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📖 Mini Comic 2 - Leo Joins In!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Now Leo talks about his nose! Repeat after each character!
            </p>
            <div className="max-w-4xl mx-auto space-y-6">
              <Card className="p-6 bg-gradient-to-r from-green-400 to-blue-400 text-white">
                <div className="text-center space-y-4">
                  <div className="text-6xl">👶</div>
                  <h3 className="text-xl font-bold">Leo says:</h3>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <p className="text-lg">"This is my nose."</p>
                    <div className="text-4xl mt-2">👃</div>
                  </div>
                  <AudioButton text="This is my nose" className="text-white border-white" />
                </div>
              </Card>
              <Card className="p-6 bg-gradient-accent text-white">
                <h3 className="text-xl font-bold mb-4">Now you try!</h3>
                <p className="text-lg">Repeat each sentence:</p>
                <div className="space-y-2 mt-4">
                  <AudioButton text="This is my head" className="text-white border-white mr-2" />
                  <AudioButton text="These are my eyes" className="text-white border-white mr-2" />
                  <AudioButton text="This is my nose" className="text-white border-white" />
                </div>
              </Card>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🗣️ Speaking Role-Play - Teacher Asks, You Answer!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher asks "What is this?" - You answer with full sentences!
            </p>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="bg-primary text-white p-4 rounded-xl">
                  <h3 className="text-xl font-bold">Teacher asks:</h3>
                  <p className="text-lg">"What is this?" 👤</p>
                  <AudioButton text="What is this" className="mt-2 text-white border-white" />
                </div>
                <div className="bg-success text-white p-4 rounded-xl">
                  <h3 className="text-xl font-bold">You answer:</h3>
                  <p className="text-lg">"This is my head."</p>
                  <AudioButton text="This is my head" className="mt-2 text-white border-white" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {bodyParts.map((part) => (
                    <div key={part.name} className="p-4 bg-muted rounded-xl">
                      <div className="text-4xl mb-2">{part.emoji}</div>
                      <p className="text-sm font-semibold">
                        {part.name === 'eyes' ? 'These are my eyes' : `This is my ${part.name}`}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        );

      // Slide 21: Wrap-Up & Badge
      case 21:
        return (
          <div className="text-center space-y-8">
            <div className="text-6xl animate-bounce-gentle">🏅</div>
            <h1 className="text-5xl font-bold font-fredoka rainbow-text">
              Congratulations!
            </h1>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-success text-white">
              <div className="text-center space-y-6">
                <div className="text-4xl">🧍 Body Explorer Badge 🏅</div>
                <h2 className="text-3xl font-bold">Amazing Work!</h2>
                <p className="text-xl">You've learned all about body parts!</p>
                <div className="bg-white/20 p-6 rounded-xl">
                  <h3 className="text-lg font-bold mb-4">You can now say:</h3>
                  <div className="space-y-2">
                    <p>✅ "This is my head." 👤</p>
                    <p>✅ "These are my eyes." 👀</p>
                    <p>✅ "This is my nose." 👃</p>
                    <p>✅ Letter G for Goat! 🐐</p>
                  </div>
                </div>
                <div className="text-4xl">🎉 🎊 🎉</div>
              </div>
            </Card>
            <Card className="p-6 max-w-md mx-auto bg-gradient-accent text-white">
              <h3 className="text-xl font-bold mb-2">Homework:</h3>
              <p className="text-lg">Draw a face and label: head, eyes, nose! 🎨</p>
            </Card>
          </div>
        );

      default:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">Lesson Complete!</h2>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <FloatingLogo />
      
      <div className="max-w-6xl mx-auto pt-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="text-lg px-4 py-2">
              Unit 4 • Lesson 1
            </Badge>
            <div className="hidden sm:block">
              <ProgressBar current={currentSlide} total={totalSlides} />
            </div>
            <span className="text-lg font-semibold text-primary">
              {currentSlide} / {totalSlides}
            </span>
          </div>
        </div>

        {/* Main Content */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8 min-h-[600px]">
          <div className="p-8">
            {renderSlide()}
          </div>
        </Card>

        {/* Navigation */}
        <div className="flex justify-center gap-4">
          <Button
            variant="outline"
            onClick={prevSlide}
            disabled={currentSlide === 1}
            className="px-8 py-6 text-lg"
          >
            ← Previous
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="px-8 py-6 text-lg"
          >
            🏠 Home
          </Button>
          <Button
            onClick={nextSlide}
            className="px-8 py-6 text-lg bg-gradient-primary hover:bg-gradient-primary/90"
          >
            {currentSlide >= totalSlides ? "Finish! 🏅" : "Next →"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Lesson41;