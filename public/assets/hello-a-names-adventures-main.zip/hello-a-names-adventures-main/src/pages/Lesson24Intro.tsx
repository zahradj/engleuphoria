import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";

export const Lesson24Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
      <FloatingLogo />
      
      <div className="max-w-4xl mx-auto text-center space-y-8">
        
        {/* Animated Header */}
        <div className="space-y-6">
          <div className="flex justify-center">
            <div className="relative">
              <div className="text-8xl animate-bounce-gentle">🌈</div>
              <div className="absolute -top-2 -right-2 text-2xl animate-pulse-fun">✨</div>
              <div className="absolute -bottom-1 -left-3 text-xl animate-bounce-gentle" style={{animationDelay: '0.5s'}}>🎮</div>
              <div className="absolute top-4 -left-4 text-lg animate-pulse-fun" style={{animationDelay: '1s'}}>🏅</div>
            </div>
          </div>
          
          <h1 className="text-5xl font-bold font-fredoka rainbow-text">
            Lesson 2.4
          </h1>
          <h2 className="text-4xl font-bold font-fredoka text-primary">
            Color Review & Games! 🎮
          </h2>
          <p className="text-xl text-muted-foreground font-fredoka">
            Unit 2 - Lesson 4 • 20 Fun Slides • 25-30 minutes
          </p>
        </div>

        {/* Lesson Preview */}
        <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl border-2 border-primary/30 shadow-glow">
          <h3 className="text-2xl font-bold font-fredoka text-center text-primary mb-6">
            🎯 Today's Adventure: Rainbow Champion Challenge!
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* What We'll Learn */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-success mb-4">🌟 What We'll Review:</h4>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-foreground font-semibold">All Six Colors: Red, Blue, Yellow</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-foreground font-semibold">Green, Black, White</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-primary rounded-full"></div>
                  <span className="text-foreground font-semibold">Phonics: A, B, C, D</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-accent rounded-full"></div>
                  <span className="text-foreground font-semibold">Sentences: "It is ___" / "This is ___"</span>
                </div>
              </div>
            </div>

            {/* Fun Activities */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-warning mb-4">🎮 Fun Games & Activities:</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🌈</span>
                  <span className="text-foreground">Rainbow Balloon Pop</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎯</span>
                  <span className="text-foreground">Rainbow Bingo Board</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎪</span>
                  <span className="text-foreground">Spin & Speak Wheel</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🔍</span>
                  <span className="text-foreground">Guess the Hidden Color</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🧩</span>
                  <span className="text-foreground">Memory Flip Game</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎭</span>
                  <span className="text-foreground">Role-Play: "What color is it?"</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Learning Goals */}
        <div className="bg-gradient-to-r from-success/20 to-primary/20 p-6 rounded-2xl border border-success/30">
          <h3 className="text-xl font-bold text-center mb-4 font-fredoka">🎯 Learning Goals</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="bg-white/80 p-4 rounded-xl">
              <div className="text-2xl mb-2">🗣️</div>
              <p className="font-semibold text-sm">Master Color Sentences</p>
            </div>
            <div className="bg-white/80 p-4 rounded-xl">
              <div className="text-2xl mb-2">🎮</div>
              <p className="font-semibold text-sm">Play Fun Color Games</p>
            </div>
            <div className="bg-white/80 p-4 rounded-xl">
              <div className="text-2xl mb-2">🏅</div>
              <p className="font-semibold text-sm">Earn Rainbow Champion Badge</p>
            </div>
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="space-y-4">
          <div className="flex gap-4 justify-center flex-wrap">
            <Button
              onClick={() => navigate("/lesson24")}
              size="fun"
              variant="kid"
              className="text-2xl font-bold font-fredoka shadow-glow hover:shadow-fun transform hover:scale-110 transition-all duration-300"
            >
              🚀 Start Color Games! 🌈
            </Button>
            <Button
              onClick={() => navigate("/")}
              variant="outline"
              size="fun"
              className="text-xl font-bold font-fredoka border-primary text-primary hover:bg-primary/10"
            >
              ← Back to Program
            </Button>
          </div>
          <p className="text-sm text-muted-foreground font-fredoka">
            Ready for the ultimate color review adventure?
          </p>
        </div>
      </div>
    </div>
  );
};