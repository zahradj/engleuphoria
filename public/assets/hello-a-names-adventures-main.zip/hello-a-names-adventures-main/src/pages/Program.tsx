import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import logo from "@/assets/englphoria-logo.png";

export const Program = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
      <div className="max-w-4xl mx-auto text-center space-y-12">
        
        {/* Animated Logo */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-primary to-accent rounded-full shadow-glow animate-bounce-gentle flex items-center justify-center">
              <img 
                src={logo} 
                alt="EnglEphoria Logo" 
                className="w-20 h-20 object-contain filter brightness-0 invert"
              />
            </div>
            <div className="absolute -top-2 -right-2 text-2xl animate-pulse-fun">✨</div>
            <div className="absolute -bottom-1 -left-3 text-xl animate-bounce-gentle" style={{animationDelay: '0.5s'}}>⭐</div>
            <div className="absolute top-4 -left-4 text-lg animate-pulse-fun" style={{animationDelay: '1s'}}>🌟</div>
          </div>
        </div>

        {/* Program Title */}
        <div className="space-y-6">
          <h1 className="text-5xl font-bold font-fredoka rainbow-text">
            Pre-Starter English Program
          </h1>
          <p className="text-xl text-muted-foreground font-fredoka">
            The complete journey from A to Z for young learners
          </p>
        </div>

        {/* Program Overview Section */}
        <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl border-2 border-accent/30 shadow-glow">
          <h3 className="text-3xl font-bold font-fredoka text-center text-accent mb-6">
            📚 Complete Program Overview
          </h3>
          <div className="text-center mb-6">
            <div className="inline-block bg-gradient-to-r from-primary to-accent text-white px-6 py-3 rounded-2xl font-bold text-xl">
              30 Fun Minutes per Lesson • Perfect for Young Learners
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* Program Features */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-primary mb-4">🎯 Program Features:</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span className="text-foreground">Interactive games & activities</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span className="text-foreground">Phonics foundation (A-Z)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span className="text-foreground">Basic vocabulary building</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span className="text-foreground">Speaking & listening practice</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span className="text-foreground">One-on-one online format</span>
                </div>
              </div>
            </div>

            {/* Lesson List */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-success mb-4">📋 Complete Lesson List:</h4>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {/* Unit 1 */}
                <div className="bg-gradient-to-r from-success/20 to-success/10 p-3 rounded-xl border border-success/30">
                  <h5 className="font-bold text-success mb-2">Unit 1: Greetings & Self</h5>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 1.1: Greetings & Names</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Letter A</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-primary/10 rounded-xl border border-primary/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 1.2: Yes, No, Thank You</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Letter B</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-accent/10 rounded-xl border border-accent/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-accent rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 1.3: Review Role-Play</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Review A-B</span>
                </div>

                {/* Unit 2 */}
                <div className="bg-gradient-to-r from-primary/20 to-primary/10 p-3 rounded-xl border border-primary/30 mt-4">
                  <h5 className="font-bold text-primary mb-2">Unit 2: Colors & Objects</h5>
                </div>

                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 2.1: My Colors (Red, Blue, Yellow)</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Letter C</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 2.2: More Colors (Green, Black, White)</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Letter D</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 2.3: Rainbow Review</span>
                  </div>
                  <span className="text-xs text-muted-foreground">All Colors</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 2.4: Color Review & Games</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Letter E</span>
                </div>

                {/* Unit 3 */}
                <div className="bg-gradient-to-r from-accent/20 to-accent/10 p-3 rounded-xl border border-accent/30 mt-4">
                  <h5 className="font-bold text-accent mb-2">Unit 3: Numbers & Counting</h5>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 3.1: Numbers 1-3 & Toys</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Letter F</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 3.2: Numbers 4-5 & More Toys</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Letter G</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 3.3: Toy Shop Role-Play</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Review A–F</span>
                </div>
                
                {/* More Units */}
                <div className="bg-gradient-to-r from-warning/20 to-warning/10 p-3 rounded-xl border border-warning/30 mt-4">
                  <h5 className="font-bold text-warning mb-2">Unit 4: Coming Soon</h5>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-success/10 rounded-xl border border-success/20">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-success rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <span className="font-semibold">Lesson 4.1: My Body (Head, Eyes, Nose)</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Letter G</span>
                </div>
                
                <div className="text-center p-3">
                  <span className="text-sm text-muted-foreground italic">+ 20 more exciting lessons coming soon! 🚀</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Program Stats */}
          <div className="mt-6 grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-gradient-primary rounded-2xl text-white">
              <div className="text-2xl font-bold">26</div>
              <div className="text-sm">Lessons Total</div>
            </div>
            <div className="text-center p-4 bg-gradient-success rounded-2xl text-white">
              <div className="text-2xl font-bold">A-Z</div>
              <div className="text-sm">Phonics Coverage</div>
            </div>
            <div className="text-center p-4 bg-gradient-accent rounded-2xl text-white">
              <div className="text-2xl font-bold">13h</div>
              <div className="text-sm">Total Learning</div>
            </div>
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="space-y-4">
          <div className="flex gap-4 justify-center flex-wrap">
            <Button
              onClick={() => navigate("/lesson-intro")}
              size="fun"
              variant="kid"
              className="text-2xl font-bold font-fredoka shadow-glow hover:shadow-fun transform hover:scale-110 transition-all duration-300"
            >
              🚀 Start Learning! 🌟
            </Button>
            <Button
              onClick={() => navigate("/lesson33-intro")}
              size="fun"
              className="text-xl font-bold font-fredoka bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-glow hover:scale-110 transition-all"
            >
              🧸 Latest Lesson 3.3
            </Button>
            <Button
              onClick={() => navigate(-1)}
              variant="outline"
              size="fun"
              className="text-xl font-bold font-fredoka border-primary text-primary hover:bg-primary/10"
            >
              ← Back
            </Button>
          </div>
          <p className="text-sm text-muted-foreground font-fredoka">
            Begin your English learning adventure!
          </p>
        </div>
      </div>
    </div>
  );
};

export default Program;