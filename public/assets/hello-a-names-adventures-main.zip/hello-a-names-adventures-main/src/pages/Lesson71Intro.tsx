import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";
import { AudioButton } from "@/components/AudioButton";

export default function Lesson71Intro() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              🍎 Lesson 7.1
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-white/90 mb-2">
              Food Fun: Fruits
            </h2>
            <p className="text-lg text-white/80">
              Learn about Apple and Banana!
            </p>
          </div>

          {/* Lesson Overview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              📚 What We'll Learn Today
            </h3>
            <div className="grid md:grid-cols-2 gap-4 text-white/90">
              <div>
                <h4 className="font-semibold mb-2">🗣️ New Words:</h4>
                <ul className="space-y-1">
                  <li>• Apple 🍎</li>
                  <li>• Banana 🍌</li>
                  <li>• Fruit 🍇</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">📝 Grammar:</h4>
                <ul className="space-y-1">
                  <li>• "I like apples."</li>
                  <li>• "I like bananas."</li>
                  <li>• Phonics: Nn /n/ (nose, net)</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Activities Preview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">🎮 Fun Activities</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl mb-2">🍎🍌</div>
                <p className="text-white/90">Fruit Flashcards</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🛒</div>
                <p className="text-white/90">Fruit Shopping Game</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🎭</div>
                <p className="text-white/90">Fruit Taste Test</p>
              </div>
            </div>
          </Card>

          {/* Audio Practice */}
          <div className="text-center mb-8">
            <h3 className="text-xl font-bold text-white mb-4">🔊 Listen & Repeat</h3>
            <div className="flex flex-wrap justify-center gap-4">
              <AudioButton text="Apple" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Banana" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Fruit" className="bg-white/20 hover:bg-white/30 text-white" />
            </div>
          </div>

          {/* Start Button */}
          <div className="text-center">
            <Button 
              onClick={() => navigate('/lesson/7-1')}
              className="bg-gradient-primary hover:shadow-button transition-all duration-300 text-lg font-semibold px-8 py-4"
            >
              Start Fruit Lesson! 🍎🍌
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}