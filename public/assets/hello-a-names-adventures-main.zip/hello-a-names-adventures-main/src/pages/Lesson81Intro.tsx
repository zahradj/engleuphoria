import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";
import { AudioButton } from "@/components/AudioButton";

export default function Lesson81Intro() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              📚 Lesson 8.1
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-white/90 mb-2">
              My Classroom: School Items 1
            </h2>
            <p className="text-lg text-white/80">
              Learn about Book and Pen!
            </p>
          </div>

          {/* Lesson Overview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              📚 What We'll Learn Today
            </h3>
            <div className="grid md:grid-cols-2 gap-4 text-white/90">
              <div>
                <h4 className="font-semibold mb-2">🗣️ New Words:</h4>
                <ul className="space-y-1">
                  <li>• Book 📚</li>
                  <li>• Pen ✏️</li>
                  <li>• School 🏫</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">📝 Grammar:</h4>
                <ul className="space-y-1">
                  <li>• "I have a book."</li>
                  <li>• "I have a pen."</li>
                  <li>• Phonics: Qq /kw/ (queen, quack)</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Activities Preview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">🎮 Fun Activities</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl mb-2">📚✏️</div>
                <p className="text-white/90">School Flashcards</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🏫</div>
                <p className="text-white/90">Classroom Tour</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🎒</div>
                <p className="text-white/90">Pack Your Bag Game</p>
              </div>
            </div>
          </Card>

          {/* Audio Practice */}
          <div className="text-center mb-8">
            <h3 className="text-xl font-bold text-white mb-4">🔊 Listen & Repeat</h3>
            <div className="flex flex-wrap justify-center gap-4">
              <AudioButton text="Book" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Pen" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="School" className="bg-white/20 hover:bg-white/30 text-white" />
            </div>
          </div>

          {/* Start Button */}
          <div className="text-center">
            <Button 
              onClick={() => navigate('/lesson/8-1')}
              className="bg-gradient-primary hover:shadow-button transition-all duration-300 text-lg font-semibold px-8 py-4"
            >
              Start School Lesson! 📚✏️
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}