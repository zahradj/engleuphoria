import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { Clock, Users, Target, Gamepad2, MessageCircle, Award } from "lucide-react";
import { AudioButton } from "@/components/AudioButton";
import { FloatingLogo } from "@/components/FloatingLogo";

export const Lesson33Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <FloatingLogo />
      
      <div className="max-w-4xl mx-auto pt-8">
        {/* Header */}
        <div className="text-center mb-8 space-y-4">
          <Badge variant="secondary" className="text-lg px-4 py-2">
            Unit 3 • Lesson 3
          </Badge>
          <div className="space-y-2">
            <h1 className="text-4xl md:text-6xl font-bold font-fredoka rainbow-text">
              🛍️ Toy Shop Role-Play!
            </h1>
            <p className="text-xl md:text-2xl text-primary font-fredoka">
              Review Numbers 1-5, Toys & Practice Shopping!
            </p>
          </div>
        </div>

        {/* Lesson Preview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="text-center p-4 bg-gradient-card hover-grow">
            <div className="text-4xl mb-2">🔢</div>
            <p className="font-semibold">Numbers 1-5</p>
            <p className="text-sm text-muted-foreground">Count & Review</p>
          </Card>
          <Card className="text-center p-4 bg-gradient-card hover-grow">
            <div className="text-4xl mb-2">🧸</div>
            <p className="font-semibold">All Toys</p>
            <p className="text-sm text-muted-foreground">Ball, Car, Doll, Teddy</p>
          </Card>
          <Card className="text-center p-4 bg-gradient-card hover-grow">
            <div className="text-4xl mb-2">🛒</div>
            <p className="font-semibold">Shopping Role-Play</p>
            <p className="text-sm text-muted-foreground">"I want..." sentences</p>
          </Card>
          <Card className="text-center p-4 bg-gradient-card hover-grow">
            <div className="text-4xl mb-2">🎵</div>
            <p className="font-semibold">Phonics A-F</p>
            <p className="text-sm text-muted-foreground">Complete Review</p>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Lesson Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <Target className="w-6 h-6" />
                  What We'll Learn Today
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-lesson-blue">🔢 Numbers & Counting</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Review numbers 1-5</li>
                      <li>• Count toy sets</li>
                      <li>• Number recognition games</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-lesson-pink">🧸 Toy Vocabulary</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Ball, car, doll, teddy</li>
                      <li>• Toy flashcards with audio</li>
                      <li>• Plural forms (cars, dolls)</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-lesson-green">💬 Shopping Sentences</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• "I have a ___"</li>
                      <li>• "I want a ___"</li>
                      <li>• "Here you are"</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-lesson-purple">🎭 Role-Play Skills</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Customer role practice</li>
                      <li>• Shopkeeper responses</li>
                      <li>• Interactive dialogues</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <Gamepad2 className="w-6 h-6" />
                  Fun Activities & Games
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🎲</span>
                      <div>
                        <p className="font-semibold">Spin & Speak Wheel</p>
                        <p className="text-sm text-muted-foreground">Random toy + number combinations</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🎯</span>
                      <div>
                        <p className="font-semibold">Toy Bingo</p>
                        <p className="text-sm text-muted-foreground">Click the called toys on the board</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🔍</span>
                      <div>
                        <p className="font-semibold">Toy Hunt Scene</p>
                        <p className="text-sm text-muted-foreground">Find hidden toys in classroom</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">📖</span>
                      <div>
                        <p className="font-semibold">Mini Comics</p>
                        <p className="text-sm text-muted-foreground">Anna & Tom shopping stories</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🎭</span>
                      <div>
                        <p className="font-semibold">Role-Play Tasks</p>
                        <p className="text-sm text-muted-foreground">Customer & shopkeeper practice</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">🧠</span>
                      <div>
                        <p className="font-semibold">Review Quiz</p>
                        <p className="text-sm text-muted-foreground">Mixed numbers + toys questions</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Lesson Info Sidebar */}
          <div className="space-y-6">
            <Card className="bg-gradient-accent text-white border-0 shadow-card">
              <CardHeader>
                <CardTitle className="text-white">Lesson Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5" />
                  <div>
                    <p className="font-semibold">Duration</p>
                    <p className="text-sm opacity-90">25-30 minutes</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="w-5 h-5" />
                  <div>
                    <p className="font-semibold">Class Size</p>
                    <p className="text-sm opacity-90">1-on-1 or Small Groups</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <MessageCircle className="w-5 h-5" />
                  <div>
                    <p className="font-semibold">Language Focus</p>
                    <p className="text-sm opacity-90">Shopping Dialogue</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Award className="w-5 h-5" />
                  <div>
                    <p className="font-semibold">Reward</p>
                    <p className="text-sm opacity-90">Toy Shop Champion Badge</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="text-primary">Key Vocabulary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div className="text-center p-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg">
                    <div className="text-2xl">⚽</div>
                    <p className="text-sm font-bold">Ball</p>
                    <AudioButton text="ball" className="text-xs" />
                  </div>
                  <div className="text-center p-2 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg">
                    <div className="text-2xl">🚗</div>
                    <p className="text-sm font-bold">Car</p>
                    <AudioButton text="car" className="text-xs" />
                  </div>
                  <div className="text-center p-2 bg-gradient-to-r from-pink-100 to-purple-100 rounded-lg">
                    <div className="text-2xl">👧</div>
                    <p className="text-sm font-bold">Doll</p>
                    <AudioButton text="doll" className="text-xs" />
                  </div>
                  <div className="text-center p-2 bg-gradient-to-r from-brown-100 to-orange-100 rounded-lg">
                    <div className="text-2xl">🧸</div>
                    <p className="text-sm font-bold">Teddy</p>
                    <AudioButton text="teddy" className="text-xs" />
                  </div>
                </div>
                
                <div className="space-y-2 mt-4">
                  <h4 className="font-semibold text-sm">Key Sentences:</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center gap-2">
                      <span>💬</span>
                      <span>"I want a ball."</span>
                      <AudioButton text="I want a ball" className="text-xs" />
                    </div>
                    <div className="flex items-center gap-2">
                      <span>💬</span>
                      <span>"Here you are."</span>
                      <AudioButton text="Here you are" className="text-xs" />
                    </div>
                    <div className="flex items-center gap-2">
                      <span>💬</span>
                      <span>"Two cars."</span>
                      <AudioButton text="Two cars" className="text-xs" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Teacher Notes */}
        <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-l-4 border-l-warning mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-warning">
              👨‍🏫 One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <ul className="space-y-1 text-sm">
              <li>• Keep role-play playful and repeat scenarios with different toys/numbers</li>
              <li>• Encourage student to use full sentences "I want ___" not just single words</li>
              <li>• If possible, ask student to bring a toy to class and use it in role-play</li>
              <li>• Practice switching roles multiple times (customer ↔ shopkeeper)</li>
              <li>• End with positive feedback, badge celebration, and mini-homework assignment</li>
            </ul>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="text-lg px-8 py-6"
          >
            ← Back to Home
          </Button>
          <Button
            onClick={() => navigate("/lesson33")}
            className="text-lg px-8 py-6 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            Start Toy Shop Role-Play! 🛍️
          </Button>
        </div>
      </div>
    </div>
  );
};