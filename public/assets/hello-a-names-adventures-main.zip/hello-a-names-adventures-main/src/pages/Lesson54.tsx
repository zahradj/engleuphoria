import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson54 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 21;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🐾</div>
            <h1 className="text-4xl font-bold text-primary">Animal Actions!</h1>
            <p className="text-xl text-muted-foreground">Let's learn what animals can do!</p>
            <div className="flex justify-center space-x-4">
              <div className="text-4xl animate-bounce">🏊‍♀️</div>
              <div className="text-4xl animate-bounce" style={{ animationDelay: '0.2s' }}>🦅</div>
              <div className="text-4xl animate-bounce" style={{ animationDelay: '0.4s' }}>🏃‍♂️</div>
              <div className="text-4xl animate-bounce" style={{ animationDelay: '0.6s' }}>🦘</div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">All Our Animals</h2>
            <p className="text-lg text-muted-foreground">Look at all the animals we've learned!</p>
            <div className="grid grid-cols-3 gap-6">
              <div>
                <h3 className="text-xl font-bold mb-4">Pets</h3>
                <div className="flex justify-center space-x-2">
                  <span className="text-2xl">🐱</span>
                  <span className="text-2xl">🐶</span>
                  <span className="text-2xl">🐟</span>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Farm</h3>
                <div className="flex justify-center space-x-2">
                  <span className="text-2xl">🐦</span>
                  <span className="text-2xl">🐄</span>
                  <span className="text-2xl">🦆</span>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Wild</h3>
                <div className="flex justify-center space-x-2">
                  <span className="text-2xl">🦁</span>
                  <span className="text-2xl">🐘</span>
                  <span className="text-2xl">🐵</span>
                </div>
              </div>
            </div>
            <p className="text-success font-semibold">Now let's see what they can do!</p>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Time</h2>
            <div className="text-6xl mb-4">🎵</div>
            <p className="text-lg">Let's chant: A, B, C, D, E, F, G, H, I, J, K...</p>
            <div className="bg-primary/10 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">New Letter: Ll</h3>
              <div className="text-4xl mb-2">🦁</div>
              <p className="text-xl">/l/ like Lion, Leaf, Love</p>
              <AudioButton text="L, lion, leaf, love" className="mt-4" />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Action: Swim!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4">🏊‍♀️</div>
              <h3 className="text-3xl font-bold text-primary">Swim</h3>
              <p className="text-lg text-muted-foreground">Move your arms like swimming!</p>
              <AudioButton text="swim" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Action: Fly!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4">🦅</div>
              <h3 className="text-3xl font-bold text-primary">Fly</h3>
              <p className="text-lg text-muted-foreground">Flap your arms like wings!</p>
              <AudioButton text="fly" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Action: Run!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4">🏃‍♂️</div>
              <h3 className="text-3xl font-bold text-primary">Run</h3>
              <p className="text-lg text-muted-foreground">Move your legs in place!</p>
              <AudioButton text="run" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Action: Jump!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4">🦘</div>
              <h3 className="text-3xl font-bold text-primary">Jump</h3>
              <p className="text-lg text-muted-foreground">Jump up and down!</p>
              <AudioButton text="jump" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Practice All Actions</h2>
            <p className="text-lg text-muted-foreground">Click and do the action!</p>
            <div className="grid grid-cols-2 gap-4 max-w-lg mx-auto">
              <Button variant="outline" size="lg" className="flex flex-col items-center p-6">
                <div className="text-4xl mb-2">🏊‍♀️</div>
                <span>Swim</span>
                <AudioButton text="swim" />
              </Button>
              <Button variant="outline" size="lg" className="flex flex-col items-center p-6">
                <div className="text-4xl mb-2">🦅</div>
                <span>Fly</span>
                <AudioButton text="fly" />
              </Button>
              <Button variant="outline" size="lg" className="flex flex-col items-center p-6">
                <div className="text-4xl mb-2">🏃‍♂️</div>
                <span>Run</span>
                <AudioButton text="run" />
              </Button>
              <Button variant="outline" size="lg" className="flex flex-col items-center p-6">
                <div className="text-4xl mb-2">🦘</div>
                <span>Jump</span>
                <AudioButton text="jump" />
              </Button>
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Fish Can Swim</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐟💧</div>
              <h3 className="text-2xl font-bold text-primary">Fish can swim.</h3>
              <AudioButton text="Fish can swim" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Fish live in water!</p>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Birds Can Fly</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐦☁️</div>
              <h3 className="text-2xl font-bold text-primary">Birds can fly.</h3>
              <AudioButton text="Birds can fly" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Birds have wings!</p>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Dogs Can Run</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐶💨</div>
              <h3 className="text-2xl font-bold text-primary">Dogs can run.</h3>
              <AudioButton text="Dogs can run" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Dogs have strong legs!</p>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Monkeys Can Jump</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐵🌳</div>
              <h3 className="text-2xl font-bold text-primary">Monkeys can jump.</h3>
              <AudioButton text="Monkeys can jump" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">From tree to tree!</p>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Animal Action Matching</h2>
            <p className="text-lg text-muted-foreground">Match animals to what they can do!</p>
            <DragDropActivity
              title="Match Animals to Actions"
              items={[
                { id: "fish", content: "🐟", type: "source", matchId: "swim-target" },
                { id: "bird", content: "🐦", type: "source", matchId: "fly-target" },
                { id: "dog", content: "🐶", type: "source", matchId: "run-target" },
                { id: "swim-target", content: "🏊‍♀️ swim", type: "target" },
                { id: "fly-target", content: "🦅 fly", type: "target" },
                { id: "run-target", content: "🏃‍♂️ run", type: "target" }
              ]}
              onComplete={() => console.log("Animal actions matched!")}
            />
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Action Charades!</h2>
            <div className="text-6xl mb-4">🎭</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">I'll show an action. You guess and do it!</h3>
              <div className="text-6xl mb-4">🦅</div>
              <div className="grid grid-cols-4 gap-4">
                <Button variant="outline">Swim</Button>
                <Button variant="outline" className="bg-success/20">Fly ✓</Button>
                <Button variant="outline">Run</Button>
                <Button variant="outline">Jump</Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Great! Now flap your arms like flying!
              </p>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Swimming Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🏊‍♀️💙</div>
              <p className="text-lg mb-4">Let's practice swimming!</p>
              <Button size="lg" className="bg-blue-500 hover:bg-blue-600">
                Move your arms like swimming! 🌊
              </Button>
              <p className="text-sm text-muted-foreground mt-4">
                Great swimming! Fish can swim in water!
              </p>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Flying Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🦅☁️</div>
              <p className="text-lg mb-4">Let's practice flying!</p>
              <Button size="lg" className="bg-sky-500 hover:bg-sky-600">
                Flap your arms like wings! ☁️
              </Button>
              <p className="text-sm text-muted-foreground mt-4">
                Excellent flying! Birds can fly in the sky!
              </p>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Speaking Challenge</h2>
            <SpeakingActivity
              prompt="Look at the animal and say what it can do"
              expectedResponse="Fish can swim"
              onComplete={() => console.log("Action speaking completed!")}
            />
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Animal Ability Quiz</h2>
            <p className="text-lg text-muted-foreground">What can elephants do?</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐘</div>
              <div className="grid grid-cols-4 gap-4">
                <Button variant="outline">Swim</Button>
                <Button variant="outline">Fly</Button>
                <Button variant="outline" className="bg-success/20">Walk ✓</Button>
                <Button variant="outline">Climb</Button>
              </div>
              <p className="text-success font-semibold mt-4">Yes! Elephants can walk!</p>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Build "Can" Sentences</h2>
            <p className="text-lg text-muted-foreground">Complete: "Birds can fly"</p>
            <DragDropActivity
              title="Complete the Sentence"
              items={[
                { id: "birds", content: "Birds", type: "source", matchId: "word1" },
                { id: "can", content: "can", type: "source", matchId: "word2" },
                { id: "fly", content: "fly", type: "source", matchId: "word3" },
                { id: "period", content: ".", type: "source", matchId: "word4" },
                { id: "word1", content: "1st word", type: "target" },
                { id: "word2", content: "2nd word", type: "target" },
                { id: "word3", content: "3rd word", type: "target" },
                { id: "word4", content: "4th word", type: "target" }
              ]}
              onComplete={() => console.log("Can sentence built!")}
            />
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">All Animal Actions</h2>
            <p className="text-lg text-muted-foreground">Review all the actions!</p>
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4">
                <div className="text-3xl mb-2">🐟</div>
                <p className="font-semibold">Fish can swim</p>
                <AudioButton text="Fish can swim" />
              </Card>
              <Card className="p-4">
                <div className="text-3xl mb-2">🐦</div>
                <p className="font-semibold">Birds can fly</p>
                <AudioButton text="Birds can fly" />
              </Card>
              <Card className="p-4">
                <div className="text-3xl mb-2">🐶</div>
                <p className="font-semibold">Dogs can run</p>
                <AudioButton text="Dogs can run" />
              </Card>
              <Card className="p-4">
                <div className="text-3xl mb-2">🐵</div>
                <p className="font-semibold">Monkeys can jump</p>
                <AudioButton text="Monkeys can jump" />
              </Card>
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-3xl font-bold text-primary">Action Master!</h2>
            <p className="text-xl">You learned what animals can do!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Animal Expert Badge Earned!</h3>
              <p className="text-muted-foreground">You know animal actions!</p>
            </div>
            <div className="flex justify-center space-x-3">
              <span className="text-3xl">🏊‍♀️</span>
              <span className="text-3xl">🦅</span>
              <span className="text-3xl">🏃‍♂️</span>
              <span className="text-3xl">🦘</span>
            </div>
            <div className="bg-success/10 p-4 rounded-lg">
              <p className="text-lg font-semibold">🐾 Animal Actions Mastered! 🐾</p>
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Animal Expert Badge"
        description="You learned what animals can do: swim, fly, run, jump!"
        badgeName="Animal Expert"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson54-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 5.4 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson54;