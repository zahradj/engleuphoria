import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";
import { AudioButton } from "@/components/AudioButton";

export default function Lesson101Intro() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              🌍 Lesson 10.1
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-white/90 mb-2">
              My World Review: Spin & Speak
            </h2>
            <p className="text-lg text-white/80">
              Review all vocabulary with fun games!
            </p>
          </div>

          {/* Lesson Overview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              📚 What We'll Review Today
            </h3>
            <div className="grid md:grid-cols-2 gap-4 text-white/90">
              <div>
                <h4 className="font-semibold mb-2">🗣️ All Vocabulary:</h4>
                <ul className="space-y-1">
                  <li>• Colors, Numbers, Body</li>
                  <li>• Animals, Family, Food</li>
                  <li>• School, Weather, Clothes</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">🎮 Activities:</h4>
                <ul className="space-y-1">
                  <li>• Spin & Speak Wheel</li>
                  <li>• Mixed Vocabulary Game</li>
                  <li>• Phonics: A-Z Review</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Activities Preview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">🎮 Fun Activities</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl mb-2">🎡</div>
                <p className="text-white/90">Spin & Speak Wheel</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🎯</div>
                <p className="text-white/90">Vocabulary Challenge</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🏆</div>
                <p className="text-white/90">Final Quiz</p>
              </div>
            </div>
          </Card>

          {/* Start Button */}
          <div className="text-center">
            <Button 
              onClick={() => navigate('/lesson/10-1')}
              className="bg-gradient-primary hover:shadow-button transition-all duration-300 text-lg font-semibold px-8 py-4"
            >
              Start Final Review! 🌍
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}