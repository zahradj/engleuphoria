import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap } from "lucide-react";

export const Lesson52Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 5 • Lesson 2
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🐮 Farm Animals!
          </h1>
          <p className="text-xl text-muted-foreground">
            Visit the farm and meet bird, cow, and duck!
          </p>
        </div>

        {/* Farm Animals Preview Cards */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🐦</div>
              <h3 className="font-bold">Bird</h3>
              <p className="text-sm text-muted-foreground">It is a bird</p>
              <p className="text-xs text-muted-foreground">Tweet! 🔊</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🐄</div>
              <h3 className="font-bold">Cow</h3>
              <p className="text-sm text-muted-foreground">It is a cow</p>
              <p className="text-xs text-muted-foreground">Moo! 🔊</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🦆</div>
              <h3 className="font-bold">Duck</h3>
              <p className="text-sm text-muted-foreground">It is a duck</p>
              <p className="text-xs text-muted-foreground">Quack! 🔊</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Learn Today */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                What We'll Learn Today
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Farm animals: bird, cow, duck</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Animal sounds: tweet, moo, quack</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Sentences: "It is a bird/cow/duck"</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Phonics: Letter Jj /ʤ/ (jam, juice, jump)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Review: Pet animals from Lesson 5.1</span>
              </div>
            </CardContent>
          </Card>

          {/* Fun Farm Activities */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Fun Farm Activities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Animal sounds guessing game</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Interactive farm bingo</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Barn door reveal game</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Farm animal spin wheel</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Farm scene role-play</span>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Lesson Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">25–30 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">22 interactive slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Theme:</span>
                <span className="font-medium">Farm animals</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Farm Friend Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Key Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Key Vocabulary & Sentences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Farm Animals:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>🐦 Bird (tweet)</span>
                    <AudioButton text="bird" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🐄 Cow (moo)</span>
                    <AudioButton text="cow" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦆 Duck (quack)</span>
                    <AudioButton text="duck" />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Key Sentences:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is a bird."</span>
                    <AudioButton text="It is a bird" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is a cow."</span>
                    <AudioButton text="It is a cow" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is a duck."</span>
                    <AudioButton text="It is a duck" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teaching Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Animal Sounds Focus:</strong> Use clear animal sounds to make recognition fun and memorable. Practice "tweet," "moo," and "quack" with animated gestures.
              </p>
              <p>
                <strong>Sentence Structure:</strong> Consistently encourage full sentences "It is a cow" rather than just saying "cow" to build proper language patterns.
              </p>
              <p>
                <strong>Farm Context:</strong> Create a farm scene narrative to help students understand where these animals live and what they do.
              </p>
              <p>
                <strong>Interactive Engagement:</strong> Use the farm bingo and hidden barn games to maintain high engagement throughout the lesson.
              </p>
              <p>
                <strong>Extension Activity:</strong> Ask "What is your favorite farm animal?" to encourage personal expression and additional speaking practice.
              </p>
              <p>
                <strong>Homework Suggestion:</strong> Have students draw a farm scene and label the bird, cow, and duck they learned.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson52")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Visit the Farm!
          </Button>
        </div>
      </div>
    </div>
  );
};