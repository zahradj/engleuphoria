import { useState } from "react";
import { ProgressBar } from "@/components/ProgressBar";
import { ActivityCard } from "@/components/ActivityCard";
import { DragDropActivity } from "@/components/DragDropActivity";
import { FillInTheGapActivity } from "@/components/FillInTheGapActivity";
import { MissingLetterActivity } from "@/components/MissingLetterActivity";
import { PhonicsActivity } from "@/components/PhonicsActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Volume2, Hand, ThumbsUp, ThumbsDown } from "lucide-react";
import { AudioButton } from "@/components/AudioButton";
import { TranslationCard } from "@/components/TranslationCard";

const TOTAL_SLIDES = 22;

// Import or create assets for this lesson
const yesIcon = "✅";
const noIcon = "❌";
const thankYouIcon = "🙏";

const Lesson2 = () => {
  const [currentSlide, setCurrentSlide] = useState(1);

  const nextSlide = () => {
    if (currentSlide < TOTAL_SLIDES) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const previousSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const yesNoWords = [
    { id: 'yes-word', content: 'YES', type: 'source' as const, matchId: 'yes-icon' },
    { id: 'no-word', content: 'NO', type: 'source' as const, matchId: 'no-icon' },
    { id: 'thank-word', content: 'THANK YOU', type: 'source' as const, matchId: 'thank-icon' },
    { id: 'yes-icon', content: '✅', type: 'target' as const },
    { id: 'no-icon', content: '❌', type: 'target' as const },
    { id: 'thank-icon', content: '🙏', type: 'target' as const }
  ];

  const phonicsBWords = [
    { word: 'ball', emoji: '⚽', sound: '/b/' },
    { word: 'boy', emoji: '👦', sound: '/b/' },
    { word: 'bat', emoji: '🦇', sound: '/b/' },
    { word: 'book', emoji: '📚', sound: '/b/' }
  ];

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return <ActivityCard title="Welcome Back, Super Star! 🎉" onNext={nextSlide}>
          <div className="text-center space-y-6">
            <div className="text-6xl animate-bounce-gentle">👋</div>
            <h2 className="text-3xl font-bold font-fredoka rainbow-text">
              Ready for Lesson 1.2?
            </h2>
            <p className="text-xl text-muted-foreground">
              Today we'll learn to be super polite!
            </p>
            <div className="bg-gradient-primary p-6 rounded-2xl text-white">
              <p className="text-lg font-semibold">Let's say: Yes, No, and Thank You!</p>
            </div>
          </div>
        </ActivityCard>;

      case 2:
        return <ActivityCard title="Quick Review Time! 📚" onNext={nextSlide}>
          <div className="text-center space-y-6">
            <h3 className="text-2xl font-semibold">Let's remember from Lesson 1.1!</h3>
            <div className="grid grid-cols-3 gap-4">
              <Card className="p-4 hover:scale-105 transition-transform">
                <div className="text-4xl mb-2">👋</div>
                <AudioButton text="Hello" className="w-full" />
              </Card>
              <Card className="p-4 hover:scale-105 transition-transform">
                <div className="text-4xl mb-2">👋</div>
                <AudioButton text="Hi" className="w-full" />
              </Card>
              <Card className="p-4 hover:scale-105 transition-transform">
                <div className="text-4xl mb-2">👋</div>
                <AudioButton text="Goodbye" className="w-full" />
              </Card>
            </div>
            <p className="text-lg font-medium text-primary">Great job! Now let's learn new words!</p>
          </div>
        </ActivityCard>;

      case 3:
        return <ActivityCard title="Phonics Warm-Up: A to B! 🔤" onNext={nextSlide}>
          <div className="text-center space-y-6">
            <div className="grid grid-cols-2 gap-8">
              <div className="bg-gradient-primary p-6 rounded-2xl text-white">
                <h3 className="text-3xl font-bold mb-4">Letter A</h3>
                <div className="text-6xl mb-4">🍎</div>
                <AudioButton text="A for Apple" className="bg-white text-primary" />
              </div>
              <div className="bg-gradient-success p-6 rounded-2xl text-white">
                <h3 className="text-3xl font-bold mb-4">Letter B</h3>
                <div className="text-6xl mb-4">⚽</div>
                <AudioButton text="B for Ball" className="bg-white text-success" />
              </div>
            </div>
            <p className="text-lg font-medium">Ready to explore Letter B?</p>
          </div>
        </ActivityCard>;

      case 4:
        return <ActivityCard title="New Word: YES ✅" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="text-8xl animate-bounce-gentle">✅</div>
            <div className="bg-gradient-success p-8 rounded-3xl text-white">
              <h2 className="text-4xl font-bold mb-4">YES</h2>
              <p className="text-xl mb-6">When you like something or agree!</p>
              <AudioButton text="Yes" className="bg-white text-success text-xl p-4" />
            </div>
            <div className="flex justify-center">
              <div className="bg-white p-4 rounded-xl border-2 border-success animate-pulse">
                <p className="text-lg font-semibold">👦 Teacher models → 👧 Student repeats</p>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 5:
        return <ActivityCard title="New Word: NO ❌" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="text-8xl animate-bounce-gentle">❌</div>
            <div className="bg-gradient-destructive p-8 rounded-3xl text-white">
              <h2 className="text-4xl font-bold mb-4">NO</h2>
              <p className="text-xl mb-6">When you don't want something!</p>
              <AudioButton text="No" className="bg-white text-destructive text-xl p-4" />
            </div>
            <div className="flex justify-center">
              <div className="bg-white p-4 rounded-xl border-2 border-destructive animate-pulse">
                <p className="text-lg font-semibold">👦 Shake your head and say "No"</p>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 6:
        return <ActivityCard title="New Word: THANK YOU 🙏" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="text-8xl animate-bounce-gentle">🙏</div>
            <div className="bg-gradient-primary p-8 rounded-3xl text-white">
              <h2 className="text-4xl font-bold mb-4">THANK YOU</h2>
              <p className="text-xl mb-6">To show you are grateful!</p>
              <AudioButton text="Thank you" className="bg-white text-primary text-xl p-4" />
            </div>
            <div className="flex justify-center">
              <div className="bg-white p-4 rounded-xl border-2 border-primary animate-pulse">
                <p className="text-lg font-semibold">👦 Bow and say "Thank you"</p>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 7:
        return <ActivityCard title="Matching Game: Words & Icons" showNext={false}>
          <DragDropActivity
            title="Match each word to its icon!"
            items={yesNoWords}
            onComplete={nextSlide}
          />
        </ActivityCard>;

      case 8:
        return <ActivityCard title="Meet Letter B! 🅱️" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="grid grid-cols-2 gap-8">
              <div className="bg-gradient-primary p-8 rounded-3xl text-white">
                <h3 className="text-2xl font-bold mb-4">Uppercase</h3>
                <div className="text-8xl font-bold">B</div>
                <AudioButton audioSrc="/audio/alphasounds-b.mp3" className="bg-white text-primary mt-4" />
              </div>
              <div className="bg-gradient-success p-8 rounded-3xl text-white">
                <h3 className="text-2xl font-bold mb-4">Lowercase</h3>
                <div className="text-8xl font-bold">b</div>
                <AudioButton audioSrc="/audio/alphasounds-b.mp3" className="bg-white text-success mt-4" />
              </div>
            </div>
            <AudioButton text="Letter B" className="text-2xl p-6" />
            <p className="text-xl font-semibold text-primary">B makes the sound /b/</p>
          </div>
        </ActivityCard>;

      case 9:
        return <ActivityCard title="Phonics Sound: /b/ 🔊" onNext={nextSlide}>
          <div className="text-center space-y-6">
            <h3 className="text-2xl font-semibold">Letter B makes the /b/ sound!</h3>
            <div className="grid grid-cols-2 gap-6">
              {phonicsBWords.map((item, index) => (
                <Card key={index} className="p-6 hover:scale-105 transition-transform">
                  <div className="text-6xl mb-4">{item.emoji}</div>
                  <h4 className="text-xl font-bold mb-2">{item.word}</h4>
                  <AudioButton text={`${item.sound} ${item.word}`} className="w-full" />
                </Card>
              ))}
            </div>
            <p className="text-lg font-medium text-primary">Click each picture and repeat the sound!</p>
          </div>
        </ActivityCard>;

      case 10:
        return <ActivityCard title="Tap-to-Sound Game! 🎵" onNext={nextSlide}>
          <div className="text-center space-y-6">
            <h3 className="text-2xl font-semibold">Click the pictures to hear the /b/ sound!</h3>
            <div className="grid grid-cols-4 gap-4">
              {phonicsBWords.map((item, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-24 w-24 text-4xl hover:scale-110 transition-transform"
                  onClick={() => {
                    // Audio would play here
                    console.log(`Playing ${item.sound} for ${item.word}`);
                  }}
                >
                  {item.emoji}
                </Button>
              ))}
            </div>
            <div className="bg-gradient-primary p-4 rounded-2xl text-white">
              <p className="text-lg font-semibold">Great job! You hear the /b/ sound!</p>
            </div>
          </div>
        </ActivityCard>;

      case 11:
        return <ActivityCard title="Tracing Game: Write Bb ✏️" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Let's practice writing Letter B!</h3>
            <div className="bg-white p-8 rounded-3xl border-4 border-dashed border-primary">
              <div className="grid grid-cols-2 gap-12">
                <div className="text-center">
                  <p className="text-lg font-semibold mb-4">Uppercase B</p>
                  <div className="text-9xl font-bold text-primary/30 border-2 border-dashed border-primary rounded-xl p-4">
                    B
                  </div>
                  <p className="text-sm mt-2">Trace with your finger!</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-semibold mb-4">Lowercase b</p>
                  <div className="text-9xl font-bold text-primary/30 border-2 border-dashed border-primary rounded-xl p-4">
                    b
                  </div>
                  <p className="text-sm mt-2">Trace with your finger!</p>
                </div>
              </div>
            </div>
            <p className="text-lg font-medium text-primary">Great tracing! You're learning so well!</p>
          </div>
        </ActivityCard>;

      case 12:
        return <ActivityCard title="Learn: 'Yes, please.' ✅🙏" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="bg-gradient-success p-8 rounded-3xl text-white">
              <div className="text-6xl mb-4">✅🙏</div>
              <h2 className="text-3xl font-bold mb-4">"Yes, please."</h2>
              <p className="text-xl mb-6">When you want something politely!</p>
              <AudioButton text="Yes, please" className="bg-white text-success text-xl p-4" />
            </div>
            <div className="bg-white p-6 rounded-2xl border-2 border-success">
              <div className="text-4xl mb-2">🧸</div>
              <p className="text-lg font-semibold">"Do you want a teddy bear?"</p>
              <p className="text-2xl font-bold text-success mt-2">"Yes, please!"</p>
            </div>
          </div>
        </ActivityCard>;

      case 13:
        return <ActivityCard title="Learn: 'No, thank you.' ❌🙏" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="bg-gradient-primary p-8 rounded-3xl text-white">
              <div className="text-6xl mb-4">❌🙏</div>
              <h2 className="text-3xl font-bold mb-4">"No, thank you."</h2>
              <p className="text-xl mb-6">When you don't want something, but you're polite!</p>
              <AudioButton text="No, thank you" className="bg-white text-primary text-xl p-4" />
            </div>
            <div className="bg-white p-6 rounded-2xl border-2 border-primary">
              <div className="text-4xl mb-2">🥛</div>
              <p className="text-lg font-semibold">"Do you want some milk?"</p>
              <p className="text-2xl font-bold text-primary mt-2">"No, thank you!"</p>
            </div>
          </div>
        </ActivityCard>;

      case 14:
        return <ActivityCard title="Puppet Dialogue 1: Apple Time! 🍎" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="bg-gradient-primary p-6 rounded-3xl text-white">
              <h3 className="text-2xl font-bold mb-4">🎭 Puppet asks you:</h3>
              <div className="text-6xl mb-4">🍎</div>
              <p className="text-2xl font-semibold">"Do you want an apple?"</p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <Button
                size="fun"
                variant="kid"
                className="text-xl font-bold p-8 bg-gradient-success hover:scale-110 transition-transform"
                onClick={nextSlide}
              >
                ✅ "Yes, please!"
              </Button>
              <Button
                size="fun"
                variant="outline"
                className="text-xl font-bold p-8 border-primary text-primary hover:scale-110 transition-transform"
                onClick={nextSlide}
              >
                ❌ "No, thank you!"
              </Button>
            </div>
            <p className="text-lg font-medium">Click your answer!</p>
          </div>
        </ActivityCard>;

      case 15:
        return <ActivityCard title="Puppet Dialogue 2: Milk Time! 🥛" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <div className="bg-gradient-success p-6 rounded-3xl text-white">
              <h3 className="text-2xl font-bold mb-4">🎭 Puppet asks you:</h3>
              <div className="text-6xl mb-4">🥛</div>
              <p className="text-2xl font-semibold">"Do you want some milk?"</p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <Button
                size="fun"
                variant="kid"
                className="text-xl font-bold p-8 bg-gradient-success hover:scale-110 transition-transform"
                onClick={nextSlide}
              >
                ✅ "Yes, please!"
              </Button>
              <Button
                size="fun"
                variant="outline"
                className="text-xl font-bold p-8 border-primary text-primary hover:scale-110 transition-transform"
                onClick={nextSlide}
              >
                ❌ "No, thank you!"
              </Button>
            </div>
            <p className="text-lg font-medium">Both answers are perfect!</p>
          </div>
        </ActivityCard>;

      case 16:
        return <ActivityCard title="Yes/No Jump Game! 🦘" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Jump your character to the right side!</h3>
            <div className="bg-gradient-primary p-6 rounded-3xl text-white">
              <div className="text-4xl mb-2">🍦</div>
              <p className="text-2xl font-bold">Teacher asks: "Do you like ice cream?"</p>
            </div>
            <div className="grid grid-cols-2 gap-8">
              <div className="bg-gradient-success p-8 rounded-3xl">
                <h4 className="text-2xl font-bold text-white mb-4">YES SIDE ✅</h4>
                <Button
                  size="fun"
                  className="w-full bg-white text-success hover:scale-110 transition-transform"
                  onClick={nextSlide}
                >
                  <div className="text-4xl">🦘</div>
                  Jump Here!
                </Button>
              </div>
              <div className="bg-gradient-destructive p-8 rounded-3xl">
                <h4 className="text-2xl font-bold text-white mb-4">NO SIDE ❌</h4>
                <Button
                  size="fun"
                  className="w-full bg-white text-destructive hover:scale-110 transition-transform"
                  onClick={nextSlide}
                >
                  <div className="text-4xl">🦘</div>
                  Jump Here!
                </Button>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 17:
        return <ActivityCard title="Drag & Drop Role-Play! 🎭" showNext={false}>
          <DragDropActivity
            title="Match the sentence to the right scenario!"
            items={[
              { id: 'yes-please', content: '"Yes, please!"', type: 'source', matchId: 'accepting' },
              { id: 'no-thanks', content: '"No, thank you!"', type: 'source', matchId: 'rejecting' },
              { id: 'accepting', content: '🍪 Accepting cookies', type: 'target' },
              { id: 'rejecting', content: '🥤 Saying no to juice', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        </ActivityCard>;

      case 18:
        return <ActivityCard title="Speaking Practice! 🎤" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Practice saying these polite sentences!</h3>
            <div className="grid grid-cols-1 gap-6 max-w-md mx-auto">
              <Card className="p-6 bg-gradient-success text-white">
                <div className="text-4xl mb-4">✅🙏</div>
                <h4 className="text-2xl font-bold mb-4">"Yes, please!"</h4>
                <AudioButton text="Yes, please" className="bg-white text-success" />
                <div className="mt-4 p-3 bg-white/20 rounded-xl">
                  <p className="text-sm">🎤 Your turn to repeat!</p>
                </div>
              </Card>
              <Card className="p-6 bg-gradient-primary text-white">
                <div className="text-4xl mb-4">❌🙏</div>
                <h4 className="text-2xl font-bold mb-4">"No, thank you!"</h4>
                <AudioButton text="No, thank you" className="bg-white text-primary" />
                <div className="mt-4 p-3 bg-white/20 rounded-xl">
                  <p className="text-sm">🎤 Your turn to repeat!</p>
                </div>
              </Card>
            </div>
          </div>
        </ActivityCard>;

      case 19:
        return <ActivityCard title="Mini Role-Play! 🎭👨‍🏫" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Teacher will ask you questions live!</h3>
            <div className="bg-gradient-primary p-8 rounded-3xl text-white">
              <div className="text-6xl mb-4">👨‍🏫</div>
              <h4 className="text-2xl font-bold mb-4">Teacher's Live Questions:</h4>
              <div className="space-y-4 text-left">
                <p className="text-lg">• "Do you want pizza?" 🍕</p>
                <p className="text-lg">• "Do you like cats?" 🐱</p>
                <p className="text-lg">• "Do you want to play?" 🎮</p>
              </div>
            </div>
            <div className="bg-white p-6 rounded-2xl border-2 border-primary">
              <h4 className="text-xl font-bold text-primary mb-4">Remember to answer:</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-success/10 rounded-xl">
                  <p className="text-lg font-semibold text-success">"Yes, please!"</p>
                </div>
                <div className="p-3 bg-primary/10 rounded-xl">
                  <p className="text-lg font-semibold text-primary">"No, thank you!"</p>
                </div>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 20:
        return <ActivityCard title="Quick Quiz! 🧠" showNext={false}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Choose the right bubble for each situation!</h3>
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border-2 border-primary">
                <div className="text-4xl mb-4">🍰</div>
                <p className="text-lg font-semibold mb-4">Someone offers you cake and you want it:</p>
                <div className="grid grid-cols-3 gap-4">
                  <Button variant="outline" className="p-4" onClick={nextSlide}>
                    <div className="text-center">
                      <div className="text-2xl">✅</div>
                      <p>"Yes, please!"</p>
                    </div>
                  </Button>
                  <Button variant="outline" className="p-4">
                    <div className="text-center">
                      <div className="text-2xl">❌</div>
                      <p>"No"</p>
                    </div>
                  </Button>
                  <Button variant="outline" className="p-4">
                    <div className="text-center">
                      <div className="text-2xl">🙏</div>
                      <p>"Thank you"</p>
                    </div>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </ActivityCard>;

      case 21:
        return <ActivityCard title="Phonics Chant: A + B! 🎵" onNext={nextSlide}>
          <div className="text-center space-y-8">
            <h3 className="text-2xl font-semibold">Let's chant our letters with claps!</h3>
            <div className="grid grid-cols-2 gap-8">
              <div className="bg-gradient-primary p-8 rounded-3xl text-white">
                <div className="text-8xl mb-4">A</div>
                <h4 className="text-2xl font-bold mb-4">A is for Apple!</h4>
                <div className="text-4xl">🍎</div>
                <AudioButton text="A is for Apple" className="bg-white text-primary mt-4" />
              </div>
              <div className="bg-gradient-success p-8 rounded-3xl text-white">
                <div className="text-8xl mb-4">B</div>
                <h4 className="text-2xl font-bold mb-4">B is for Ball!</h4>
                <div className="text-4xl">⚽</div>
                <AudioButton text="B is for Ball" className="bg-white text-success mt-4" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-2xl border-2 border-primary">
              <p className="text-xl font-bold text-primary">👏 Clap along: A-B-A-B! 👏</p>
            </div>
          </div>
        </ActivityCard>;

      case 22:
        return <ActivityCard title="🎖️ Congratulations! 🎉" showNext={false}>
          <BadgeReward
            title="Polite Speaker Badge Unlocked!"
            description="You learned to say Yes, No, and Thank You politely!"
            badgeName="Polite Speaker"
            onContinue={() => {
              // Could navigate to next lesson or back to menu
              console.log("Lesson 1.2 completed!");
            }}
          />
        </ActivityCard>;

      default:
        return <ActivityCard title="Lesson Complete!" onNext={nextSlide}>
          <div className="text-center">
            <h2 className="text-2xl font-bold">Great job!</h2>
            <p>You've completed all the slides!</p>
          </div>
        </ActivityCard>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10">
      <FloatingLogo />
      <div className="container mx-auto px-4 py-6">
        <ProgressBar current={currentSlide} total={TOTAL_SLIDES} />
        
        <div className="mt-6">
          {renderSlide()}
        </div>

        <div className="flex justify-between items-center mt-6">
          <Button
            onClick={previousSlide}
            disabled={currentSlide === 1}
            variant="outline"
            className="flex items-center gap-2"
          >
            ← Previous
          </Button>
          
          <span className="text-sm text-muted-foreground">
            Slide {currentSlide} of {TOTAL_SLIDES}
          </span>
          
          <Button
            onClick={nextSlide}
            disabled={currentSlide === TOTAL_SLIDES}
            variant="outline"
            className="flex items-center gap-2"
          >
            Next →
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Lesson2;