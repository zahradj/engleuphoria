import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useNavigate } from "react-router-dom";
import { AudioButton } from "@/components/AudioButton";
import { DragDropActivity } from "@/components/DragDropActivity";
import { Badge } from "@/components/ui/badge";
import { FloatingLogo } from "@/components/FloatingLogo";
import logo from "@/assets/englphoria-logo.png";

export const Lesson21 = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();
  const totalSlides = 21;

  const nextSlide = () => {
    if (currentSlide < totalSlides - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const goToSlide = (slideNumber: number) => {
    setCurrentSlide(slideNumber);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 0:
        return (
          <div className="text-center space-y-8">
            <div className="flex justify-center mb-8">
              <div className="w-24 h-24 bg-gradient-to-br from-accent to-primary rounded-full shadow-glow flex items-center justify-center">
                <img src={logo} alt="EnglEphoria" className="w-16 h-16 object-contain filter brightness-0 invert" />
              </div>
            </div>
            <h1 className="text-6xl font-bold font-fredoka rainbow-text mb-8">My Colors!</h1>
            <div className="flex justify-center gap-8 animate-bounce-gentle">
              <div className="w-16 h-16 bg-red-500 rounded-full shadow-lg animate-float" style={{animationDelay: '0s'}}></div>
              <div className="w-16 h-16 bg-blue-500 rounded-full shadow-lg animate-float" style={{animationDelay: '0.3s'}}></div>
              <div className="w-16 h-16 bg-yellow-500 rounded-full shadow-lg animate-float" style={{animationDelay: '0.6s'}}></div>
            </div>
            <p className="text-2xl font-fredoka text-muted-foreground">Welcome to Unit 2, Lesson 1! 🎈</p>
          </div>
        );

      case 1:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-primary mb-8">Quick Review!</h2>
            <p className="text-xl font-fredoka text-muted-foreground mb-8">Let's remember Unit 1 greetings!</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-3xl border-2 border-primary/20 shadow-fun hover:shadow-glow transition-all duration-300 cursor-pointer hover:scale-105">
                <div className="text-4xl mb-4">👋</div>
                <AudioButton text="Hello" className="text-2xl font-fredoka font-bold text-primary" />
              </div>
              <div className="bg-white p-6 rounded-3xl border-2 border-accent/20 shadow-fun hover:shadow-glow transition-all duration-300 cursor-pointer hover:scale-105">
                <div className="text-4xl mb-4">🙋</div>
                <AudioButton text="Hi" className="text-2xl font-fredoka font-bold text-accent" />
              </div>
              <div className="bg-white p-6 rounded-3xl border-2 border-success/20 shadow-fun hover:shadow-glow transition-all duration-300 cursor-pointer hover:scale-105">
                <div className="text-4xl mb-4">👋</div>
                <AudioButton text="Bye" className="text-2xl font-fredoka font-bold text-success" />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-primary mb-8">Phonics Warm-Up!</h2>
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-8 rounded-3xl border-2 border-primary/20">
              <div className="text-6xl mb-6">🎵</div>
              <p className="text-3xl font-fredoka font-bold text-primary mb-4">Let's Chant Together!</p>
              <div className="space-y-4">
                <div className="text-2xl font-fredoka">🅰️ A is for Apple! /æ/ /æ/ /æ/</div>
                <div className="text-2xl font-fredoka">🅱️ B is for Ball! /b/ /b/ /b/</div>
                <div className="text-2xl font-fredoka text-accent font-bold">🅲 C is for Cat! /k/ /k/ /k/</div>
              </div>
              <div className="mt-6 flex justify-center gap-4">
                <div className="text-4xl animate-bounce">🐱</div>
                <div className="text-4xl animate-bounce" style={{animationDelay: '0.2s'}}>☕</div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-red-500 mb-8">RED</h2>
            <div className="flex justify-center mb-8">
              <div className="relative">
                <div className="w-48 h-48 bg-red-500 rounded-full shadow-glow animate-pulse-fun flex items-center justify-center">
                  <div className="text-8xl">🍎</div>
                </div>
                <div className="absolute -top-4 -right-4 text-4xl animate-bounce">✨</div>
              </div>
            </div>
            <AudioButton 
              text="Red" 
              className="text-4xl font-fredoka font-bold bg-red-500 text-white px-8 py-4 rounded-2xl hover:bg-red-600 transition-all duration-300 shadow-glow"
            />
            <p className="text-2xl font-fredoka text-muted-foreground">Click the apple to hear "RED"!</p>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-blue-500 mb-8">BLUE</h2>
            <div className="flex justify-center mb-8">
              <div className="relative">
                <div className="w-48 h-48 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full shadow-glow animate-pulse-fun flex items-center justify-center">
                  <div className="text-8xl">☁️</div>
                </div>
                <div className="absolute -bottom-4 -left-4 text-4xl animate-bounce">🌟</div>
              </div>
            </div>
            <AudioButton 
              text="Blue" 
              className="text-4xl font-fredoka font-bold bg-blue-500 text-white px-8 py-4 rounded-2xl hover:bg-blue-600 transition-all duration-300 shadow-glow"
            />
            <p className="text-2xl font-fredoka text-muted-foreground">The beautiful blue sky!</p>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-5xl font-bold font-fredoka text-yellow-500 mb-8">YELLOW</h2>
            <div className="flex justify-center mb-8">
              <div className="relative">
                <div className="w-48 h-48 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-full shadow-glow animate-pulse-fun flex items-center justify-center">
                  <div className="text-8xl">☀️</div>
                </div>
                <div className="absolute -top-4 -left-4 text-4xl animate-bounce">⭐</div>
              </div>
            </div>
            <AudioButton 
              text="Yellow" 
              className="text-4xl font-fredoka font-bold bg-yellow-500 text-white px-8 py-4 rounded-2xl hover:bg-yellow-600 transition-all duration-300 shadow-glow"
            />
            <p className="text-2xl font-fredoka text-muted-foreground">The bright yellow sun!</p>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Listen & Learn!</h2>
            <p className="text-xl font-fredoka text-muted-foreground mb-8">Click each color to hear it!</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-3xl border-2 border-red-300 shadow-fun hover:shadow-glow transition-all duration-300">
                <div className="w-24 h-24 bg-red-500 rounded-full mx-auto mb-4"></div>
                <AudioButton text="Red" className="text-2xl font-fredoka font-bold text-red-500" />
              </div>
              <div className="bg-white p-6 rounded-3xl border-2 border-blue-300 shadow-fun hover:shadow-glow transition-all duration-300">
                <div className="w-24 h-24 bg-blue-500 rounded-full mx-auto mb-4"></div>
                <AudioButton text="Blue" className="text-2xl font-fredoka font-bold text-blue-500" />
              </div>
              <div className="bg-white p-6 rounded-3xl border-2 border-yellow-300 shadow-fun hover:shadow-glow transition-all duration-300">
                <div className="w-24 h-24 bg-yellow-500 rounded-full mx-auto mb-4"></div>
                <AudioButton text="Yellow" className="text-2xl font-fredoka font-bold text-yellow-500" />
              </div>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Match the Colors!</h2>
            <DragDropActivity
              title="Match the Colors!"
              items={[
                { id: 'red-word', content: 'RED', type: 'source', matchId: 'red-apple' },
                { id: 'blue-word', content: 'BLUE', type: 'source', matchId: 'blue-ball' },
                { id: 'yellow-word', content: 'YELLOW', type: 'source', matchId: 'yellow-sun' },
                { id: 'red-apple', content: '🍎', type: 'target' },
                { id: 'blue-ball', content: '⚽', type: 'target' },
                { id: 'yellow-sun', content: '☀️', type: 'target' }
              ]}
              onComplete={() => console.log('Activity completed!')}
            />
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Sentence Magic!</h2>
            <div className="bg-gradient-to-br from-red-100 to-red-200 p-8 rounded-3xl border-2 border-red-300">
              <div className="text-6xl mb-6">🍎</div>
              <p className="text-4xl font-fredoka font-bold text-red-600">"It is red."</p>
              <AudioButton 
                text="It is red" 
                className="mt-4 text-2xl font-fredoka bg-red-500 text-white px-6 py-3 rounded-xl hover:bg-red-600"
              />
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">More Sentences!</h2>
            <div className="bg-gradient-to-br from-blue-100 to-blue-200 p-8 rounded-3xl border-2 border-blue-300">
              <div className="text-6xl mb-6">⚽</div>
              <p className="text-4xl font-fredoka font-bold text-blue-600">"This is blue."</p>
              <AudioButton 
                text="This is blue" 
                className="mt-4 text-2xl font-fredoka bg-blue-500 text-white px-6 py-3 rounded-xl hover:bg-blue-600"
              />
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Yellow Sentence!</h2>
            <div className="bg-gradient-to-br from-yellow-100 to-yellow-200 p-8 rounded-3xl border-2 border-yellow-300">
              <div className="text-6xl mb-6">☀️</div>
              <p className="text-4xl font-fredoka font-bold text-yellow-600">"It is yellow."</p>
              <AudioButton 
                text="It is yellow" 
                className="mt-4 text-2xl font-fredoka bg-yellow-500 text-white px-6 py-3 rounded-xl hover:bg-yellow-600"
              />
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Speaking Practice!</h2>
            <p className="text-2xl font-fredoka text-muted-foreground mb-8">Look at the object and say "It is ___"</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-3xl border-2 border-red-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">🍎</div>
                <p className="text-xl font-fredoka text-red-500 font-bold">Say: "It is red"</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-blue-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">🌀</div>
                <p className="text-xl font-fredoka text-blue-500 font-bold">Say: "It is blue"</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-yellow-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">🌙</div>
                <p className="text-xl font-fredoka text-yellow-500 font-bold">Say: "It is yellow"</p>
              </div>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Color Hunt! 🔍</h2>
            <p className="text-xl font-fredoka text-muted-foreground mb-8">Find and click all the hidden colors!</p>
            <div className="bg-gradient-to-br from-green-100 to-blue-100 p-8 rounded-3xl border-2 border-primary/20 min-h-64 relative">
              <div className="absolute top-4 left-8 w-8 h-8 bg-red-500 rounded-full cursor-pointer hover:scale-125 transition-all animate-pulse"></div>
              <div className="absolute bottom-8 right-12 w-8 h-8 bg-blue-500 rounded-full cursor-pointer hover:scale-125 transition-all animate-pulse"></div>
              <div className="absolute top-16 right-8 w-8 h-8 bg-yellow-500 rounded-full cursor-pointer hover:scale-125 transition-all animate-pulse"></div>
              <div className="text-6xl mt-8">🏠🌳🌸🦋</div>
              <p className="text-lg font-fredoka mt-4">Look carefully for red, blue, and yellow dots!</p>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Spin & Speak! 🎡</h2>
            <div className="flex justify-center mb-8">
              <div className="relative w-48 h-48">
                <div className="w-full h-full rounded-full border-8 border-primary animate-spin-slow">
                  <div className="w-full h-full rounded-full bg-gradient-to-r from-red-400 via-blue-400 to-yellow-400 flex items-center justify-center">
                    <div className="text-4xl font-fredoka font-bold text-white">SPIN!</div>
                  </div>
                </div>
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-2 text-2xl">📍</div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-2xl border-2 border-accent/20 shadow-fun">
              <p className="text-2xl font-fredoka font-bold text-accent">Wheel says: "BLUE"</p>
              <p className="text-xl font-fredoka text-muted-foreground mt-2">Now say: "It is blue!"</p>
            </div>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Color Quiz! 🧩</h2>
            <p className="text-2xl font-fredoka text-muted-foreground mb-8">Which one is BLUE?</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-3xl border-2 border-red-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="w-20 h-20 bg-red-500 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">A</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-blue-300 shadow-fun cursor-pointer hover:scale-105 transition-all border-4 border-green-400">
                <div className="w-20 h-20 bg-blue-500 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">B ✓</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-yellow-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="w-20 h-20 bg-yellow-500 rounded-full mx-auto mb-4"></div>
                <p className="text-lg font-fredoka font-bold">C</p>
              </div>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Digital Coloring! 🎨</h2>
            <p className="text-xl font-fredoka text-muted-foreground mb-8">Color the objects!</p>
            <div className="bg-white p-8 rounded-3xl border-2 border-primary/20 shadow-fun">
              <div className="grid grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="text-6xl mb-4 cursor-pointer hover:scale-110 transition-all">🍎</div>
                  <p className="text-lg font-fredoka">Color me RED!</p>
                </div>
                <div className="text-center">
                  <div className="text-6xl mb-4 cursor-pointer hover:scale-110 transition-all">⚽</div>
                  <p className="text-lg font-fredoka">Color me BLUE!</p>
                </div>
                <div className="text-center">
                  <div className="text-6xl mb-4 cursor-pointer hover:scale-110 transition-all">☀️</div>
                  <p className="text-lg font-fredoka">Color me YELLOW!</p>
                </div>
              </div>
              <div className="flex justify-center gap-4 mt-6">
                <div className="w-8 h-8 bg-red-500 rounded-full cursor-pointer border-2 border-gray-300"></div>
                <div className="w-8 h-8 bg-blue-500 rounded-full cursor-pointer border-2 border-gray-300"></div>
                <div className="w-8 h-8 bg-yellow-500 rounded-full cursor-pointer border-2 border-gray-300"></div>
              </div>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Phonics Fun! 🐱</h2>
            <div className="bg-gradient-to-br from-purple-100 to-pink-100 p-8 rounded-3xl border-2 border-purple-300">
              <div className="text-6xl mb-6">🎵</div>
              <p className="text-3xl font-fredoka font-bold text-purple-600 mb-4">C is for...</p>
              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-4xl mb-2">🐱</div>
                  <p className="text-xl font-fredoka font-bold">Cat</p>
                  <AudioButton text="Cat" className="text-sm mt-2" />
                </div>
                <div className="text-center">
                  <div className="text-4xl mb-2">☕</div>
                  <p className="text-xl font-fredoka font-bold">Cup</p>
                  <AudioButton text="Cup" className="text-sm mt-2" />
                </div>
                <div className="text-center">
                  <div className="text-4xl mb-2">🎨</div>
                  <p className="text-xl font-fredoka font-bold">Color</p>
                  <AudioButton text="Color" className="text-sm mt-2" />
                </div>
              </div>
              <p className="text-2xl font-fredoka mt-6">/k/ /k/ /k/ 👏</p>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Mini Story! 📚</h2>
            <div className="bg-gradient-to-br from-yellow-100 to-orange-100 p-8 rounded-3xl border-2 border-orange-300">
              <div className="grid grid-cols-3 gap-6">
                <div className="text-center bg-white p-4 rounded-2xl">
                  <div className="text-5xl mb-3">👦</div>
                  <p className="text-lg font-fredoka">"Tom has a <span className="text-red-500 font-bold">red</span> ball."</p>
                  <div className="text-3xl mt-2">⚽</div>
                </div>
                <div className="text-center bg-white p-4 rounded-2xl">
                  <div className="text-5xl mb-3">👧</div>
                  <p className="text-lg font-fredoka">"Anna has a <span className="text-blue-500 font-bold">blue</span> bag."</p>
                  <div className="text-3xl mt-2">👜</div>
                </div>
                <div className="text-center bg-white p-4 rounded-2xl">
                  <div className="text-5xl mb-3">☀️</div>
                  <p className="text-lg font-fredoka">"The sun is <span className="text-yellow-500 font-bold">yellow</span>."</p>
                  <div className="text-3xl mt-2">🌞</div>
                </div>
              </div>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Speaking Role-Play! 🎭</h2>
            <div className="bg-white p-8 rounded-3xl border-2 border-primary/20 shadow-fun">
              <div className="text-6xl mb-6">🤖</div>
              <div className="bg-primary/10 p-6 rounded-2xl mb-6">
                <p className="text-2xl font-fredoka font-bold text-primary">"What color is the ball?"</p>
                <div className="text-4xl mt-4">⚽</div>
              </div>
              <div className="bg-accent/10 p-6 rounded-2xl">
                <p className="text-xl font-fredoka text-muted-foreground">Your turn to answer!</p>
                <p className="text-2xl font-fredoka font-bold text-accent mt-2">"It is ___!"</p>
              </div>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary mb-8">Quick Quiz! 🏆</h2>
            <p className="text-2xl font-fredoka text-muted-foreground mb-8">Which is YELLOW?</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-3xl border-2 border-gray-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">🍎</div>
                <p className="text-lg font-fredoka font-bold">A</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-gray-300 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">🌊</div>
                <p className="text-lg font-fredoka font-bold">B</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-green-400 border-4 shadow-fun cursor-pointer hover:scale-105 transition-all">
                <div className="text-6xl mb-4">☀️</div>
                <p className="text-lg font-fredoka font-bold text-green-600">C ✓</p>
              </div>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-8">
            <div className="animate-bounce-gentle mb-8">
              <div className="text-8xl mb-4">🏅</div>
              <h1 className="text-5xl font-bold font-fredoka rainbow-text">Congratulations!</h1>
            </div>
            
            <div className="bg-gradient-success p-8 rounded-3xl border-2 border-success/30 shadow-glow">
              <Badge className="text-2xl font-fredoka mb-4 bg-yellow-500 text-white px-6 py-3">
                🎨 Color Explorer Badge 🎨
              </Badge>
              <p className="text-2xl font-fredoka text-white mt-4">
                Amazing work learning colors!
              </p>
              <div className="flex justify-center gap-4 mt-6">
                <div className="w-12 h-12 bg-red-500 rounded-full animate-bounce"></div>
                <div className="w-12 h-12 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                <div className="w-12 h-12 bg-yellow-500 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
              </div>
            </div>

            <div className="space-y-4">
              <Button
                onClick={() => navigate("/lesson22-intro")}
                size="fun"
                variant="kid"
                className="text-2xl font-bold font-fredoka"
              >
                🎉 Next: More Colors! 🎉
              </Button>
              <Button
                onClick={() => navigate("/lesson21-intro")}
                variant="outline"
                size="default"
                className="text-lg font-fredoka"
              >
                🔄 Replay Lesson
              </Button>
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10">
      <FloatingLogo />
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white/80 backdrop-blur-sm border-b border-primary/20 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Button
            onClick={() => navigate("/lesson21-intro")}
            variant="outline"
            size="sm"
            className="font-fredoka"
          >
            ← Back to Intro
          </Button>
          
          <div className="text-center">
            <h2 className="text-lg font-bold font-fredoka text-primary">Lesson 2.1: My Colors</h2>
            <p className="text-sm text-muted-foreground">Slide {currentSlide + 1} of {totalSlides}</p>
          </div>
          
          <Button
            onClick={() => navigate("/")}
            variant="outline"
            size="sm"
            className="font-fredoka"
          >
            🏠 Home
          </Button>
        </div>
        
        <div className="max-w-4xl mx-auto mt-4">
          <Progress value={(currentSlide / (totalSlides - 1)) * 100} className="h-2" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-fun p-8 min-h-96">
            {renderSlide()}
          </div>
        </div>
      </div>

      {/* Navigation Footer */}
      <div className="sticky bottom-0 bg-white/80 backdrop-blur-sm border-t border-primary/20 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Button
            onClick={prevSlide}
            disabled={currentSlide === 0}
            variant="outline"
            size="sm"
            className="font-fredoka"
          >
            ← Previous
          </Button>
          
          <div className="flex gap-2">
            {Array.from({ length: Math.min(totalSlides, 10) }, (_, i) => {
              const slideIndex = Math.floor((currentSlide / totalSlides) * 10) * Math.floor(totalSlides / 10) + i;
              return slideIndex < totalSlides ? (
                <button
                  key={slideIndex}
                  onClick={() => goToSlide(slideIndex)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    slideIndex === currentSlide ? 'bg-primary' : 'bg-primary/20'
                  }`}
                />
              ) : null;
            })}
          </div>
          
          <Button
            onClick={nextSlide}
            disabled={currentSlide === totalSlides - 1}
            variant="outline"
            size="sm"
            className="font-fredoka"
          >
            Next →
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Lesson21;