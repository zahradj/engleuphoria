import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson45 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 22;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🏃‍♂️</div>
            <h1 className="text-4xl font-bold text-primary">Body Actions & Final Test!</h1>
            <p className="text-xl text-muted-foreground">Let's learn actions and complete Unit 4!</p>
            <div className="flex justify-center space-x-4">
              <div className="text-4xl">🏃‍♂️</div>
              <div className="text-4xl">🚶‍♂️</div>
              <div className="text-4xl">🤸‍♂️</div>
              <div className="text-4xl">💃</div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Unit 4 Complete Review</h2>
            <p className="text-lg text-muted-foreground">Look how much you learned!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">All 10 Body Parts</h3>
              <div className="grid grid-cols-5 gap-3">
                <div className="space-y-1">
                  <div className="text-2xl">🧠</div>
                  <span className="text-xs">Head</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">👀</div>
                  <span className="text-xs">Eyes</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">👃</div>
                  <span className="text-xs">Nose</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">👄</div>
                  <span className="text-xs">Mouth</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">👋</div>
                  <span className="text-xs">Hands</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">🦶</div>
                  <span className="text-xs">Feet</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">💪</div>
                  <span className="text-xs">Arms</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">🦵</div>
                  <span className="text-xs">Legs</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">👆</div>
                  <span className="text-xs">Fingers</span>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl">🦶</div>
                  <span className="text-xs">Toes</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Action Words</h2>
            <div className="text-6xl mb-4">🏃‍♂️</div>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🏃‍♂️</div>
              <h3 className="text-3xl font-bold text-primary">Run</h3>
              <p className="text-lg text-muted-foreground">I can run fast!</p>
              <AudioButton text="run" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Action Words</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🚶‍♂️</div>
              <h3 className="text-3xl font-bold text-primary">Walk</h3>
              <p className="text-lg text-muted-foreground">I can walk slowly!</p>
              <AudioButton text="walk" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Action Words</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🤸‍♂️</div>
              <h3 className="text-3xl font-bold text-primary">Jump</h3>
              <p className="text-lg text-muted-foreground">I can jump high!</p>
              <AudioButton text="jump" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Action Words</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">💃</div>
              <h3 className="text-3xl font-bold text-primary">Dance</h3>
              <p className="text-lg text-muted-foreground">I can dance!</p>
              <AudioButton text="dance" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Action Sentences</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6">
                <div className="text-4xl mb-2">🏃‍♂️</div>
                <h3 className="text-xl font-bold text-primary">I can run.</h3>
                <AudioButton text="I can run" className="mt-2" />
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-2">🚶‍♂️</div>
                <h3 className="text-xl font-bold text-primary">I can walk.</h3>
                <AudioButton text="I can walk" className="mt-2" />
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-2">🤸‍♂️</div>
                <h3 className="text-xl font-bold text-primary">I can jump.</h3>
                <AudioButton text="I can jump" className="mt-2" />
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-2">💃</div>
                <h3 className="text-xl font-bold text-primary">I can dance.</h3>
                <AudioButton text="I can dance" className="mt-2" />
              </Card>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Action Simon Says!</h2>
            <div className="text-6xl mb-4">🎮</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Simon Says:</h3>
              <div className="space-y-3">
                <Button size="lg" variant="outline" className="w-full">
                  "Run in place!" 🏃‍♂️
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  "Walk slowly!" 🚶‍♂️
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  "Jump up and down!" 🤸‍♂️
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  "Dance and wiggle!" 💃
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Do the action and say "I can..."!
              </p>
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Body Parts Test 1</h2>
            <p className="text-lg text-muted-foreground">Click the correct body part</p>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">Question 1: Where is your head?</p>
                <div className="grid grid-cols-5 gap-4 max-w-2xl mx-auto">
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🧠 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">👀</Button>
                  <Button variant="outline" size="lg" className="text-3xl">👃</Button>
                  <Button variant="outline" size="lg" className="text-3xl">👄</Button>
                  <Button variant="outline" size="lg" className="text-3xl">👋</Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Body Parts Test 2</h2>
            <p className="text-lg text-muted-foreground">Click all the correct answers</p>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">Question 2: Which are arms and legs?</p>
                <div className="grid grid-cols-5 gap-4 max-w-2xl mx-auto">
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">💪 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🦵 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">👆</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🦶</Button>
                  <Button variant="outline" size="lg" className="text-3xl">👄</Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Sentence Building</h2>
            <p className="text-lg text-muted-foreground">Complete the sentence: "This is my nose."</p>
            <DragDropActivity
              title="Build the Sentence"
              items={[
                { id: "this", content: "This", type: "source", matchId: "word1" },
                { id: "is", content: "is", type: "source", matchId: "word2" },
                { id: "my", content: "my", type: "source", matchId: "word3" },
                { id: "nose", content: "nose", type: "source", matchId: "word4" },
                { id: "word1", content: "1st", type: "target" },
                { id: "word2", content: "2nd", type: "target" },
                { id: "word3", content: "3rd", type: "target" },
                { id: "word4", content: "4th", type: "target" }
              ]}
              onComplete={() => console.log("Assessment sentence built!")}
            />
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Speaking Test</h2>
            <SpeakingActivity
              prompt="Say this sentence: These are my hands"
              expectedResponse="These are my hands"
              onComplete={() => console.log("Speaking assessment completed!")}
            />
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Actions Test</h2>
            <p className="text-lg text-muted-foreground">What action is this?</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4">🏃‍♂️</div>
              <div className="grid grid-cols-4 gap-4 max-w-lg mx-auto">
                <Button variant="outline" className="bg-success/20">Run ✓</Button>
                <Button variant="outline">Walk</Button>
                <Button variant="outline">Jump</Button>
                <Button variant="outline">Dance</Button>
              </div>
            </div>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Complete Body Matching</h2>
            <p className="text-lg text-muted-foreground">Match all body parts correctly</p>
            <DragDropActivity
              title="Final Body Parts Test"
              items={[
                { id: "head", content: "head", type: "source", matchId: "head-target" },
                { id: "hands", content: "hands", type: "source", matchId: "hands-target" },
                { id: "feet", content: "feet", type: "source", matchId: "feet-target" },
                { id: "arms", content: "arms", type: "source", matchId: "arms-target" },
                { id: "head-target", content: "🧠", type: "target" },
                { id: "hands-target", content: "👋", type: "target" },
                { id: "feet-target", content: "🦶", type: "target" },
                { id: "arms-target", content: "💪", type: "target" }
              ]}
              onComplete={() => console.log("Final body test completed!")}
            />
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Review Assessment</h2>
            <div className="text-6xl mb-4">🔤</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">A–I Phonics Test</h3>
              <div className="grid grid-cols-3 gap-4 text-lg font-bold mb-4">
                <div className="space-y-1">
                  <div>A a 🍎</div>
                  <div>B b ⚽</div>
                  <div>C c 🐱</div>
                </div>
                <div className="space-y-1">
                  <div>D d 🐕</div>
                  <div>E e 🥚</div>
                  <div>F f 🐟</div>
                </div>
                <div className="space-y-1">
                  <div>G g 🦒</div>
                  <div>H h 🎩</div>
                  <div>I i 🏠</div>
                </div>
              </div>
              <AudioButton text="A apple, B ball, C cat, D dog, E egg, F fish, G giraffe, H hat, I igloo" />
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Memory Challenge</h2>
            <p className="text-lg text-muted-foreground">Remember and click all body parts in order</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <p className="mb-4">Click them in this order: Head → Hands → Feet</p>
              <div className="grid grid-cols-6 gap-3">
                <Button variant="outline" size="lg" className="text-3xl">👀</Button>
                <Button variant="outline" size="lg" className="text-3xl bg-success/20">🧠 1</Button>
                <Button variant="outline" size="lg" className="text-3xl">👃</Button>
                <Button variant="outline" size="lg" className="text-3xl bg-success/20">👋 2</Button>
                <Button variant="outline" size="lg" className="text-3xl">💪</Button>
                <Button variant="outline" size="lg" className="text-3xl bg-success/20">🦶 3</Button>
              </div>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Action Performance</h2>
            <p className="text-lg text-muted-foreground">Show me each action while saying the sentence</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="space-y-4">
                <div className="p-4 border rounded">
                  <div className="text-4xl mb-2">🏃‍♂️</div>
                  <p className="font-semibold">Action: Run in place</p>
                  <p className="text-sm">Say: "I can run!"</p>
                </div>
                <div className="p-4 border rounded">
                  <div className="text-4xl mb-2">🤸‍♂️</div>
                  <p className="font-semibold">Action: Jump up and down</p>
                  <p className="text-sm">Say: "I can jump!"</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment Results</h2>
            <div className="text-6xl mb-4">📊</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Unit 4 Assessment Complete!</h3>
              <div className="grid grid-cols-2 gap-4 text-left">
                <div>
                  <h4 className="font-semibold">Body Parts:</h4>
                  <p className="text-success">✓ 10/10 mastered</p>
                </div>
                <div>
                  <h4 className="font-semibold">Sentences:</h4>
                  <p className="text-success">✓ Perfect structure</p>
                </div>
                <div>
                  <h4 className="font-semibold">Actions:</h4>
                  <p className="text-success">✓ All 4 learned</p>
                </div>
                <div>
                  <h4 className="font-semibold">Phonics A-I:</h4>
                  <p className="text-success">✓ Complete mastery</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Unit 4 Achievement Summary</h2>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">What You Accomplished:</h3>
              <div className="space-y-3 text-left">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Learned 10 complete body parts vocabulary</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Mastered "This is my..." and "These are my..." patterns</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Completed phonics letters A through I</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Learned action words with "I can..." sentences</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Passed comprehensive unit assessment</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Ready for Unit 5!</h2>
            <div className="text-6xl mb-4">🎓</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Next Learning Adventures:</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-3xl">👨‍👩‍👧‍👦</div>
                  <h4 className="font-semibold">Unit 5: Family</h4>
                  <p className="text-sm">Mom, Dad, Sister, Brother</p>
                </div>
                <div className="space-y-2">
                  <div className="text-3xl">🐱🐕</div>
                  <h4 className="font-semibold">Unit 6: Animals</h4>
                  <p className="text-sm">Cat, Dog, Bird, Fish</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Final Celebration Dance!</h2>
            <div className="text-6xl mb-4">🎉</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Celebration Time!</h3>
              <p className="mb-4">Let's use our body parts to celebrate!</p>
              <div className="space-y-2">
                <p>👋 Clap your hands!</p>
                <p>🦶 Stomp your feet!</p>
                <p>💪 Wave your arms!</p>
                <p>🧠 Nod your head!</p>
                <p>💃 Dance with your whole body!</p>
              </div>
            </div>
          </div>
        );

      case 22:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🏆</div>
            <h2 className="text-3xl font-bold text-primary">Unit 4 Master!</h2>
            <p className="text-xl">You completed the entire Body unit!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Unit 4 Master Badge Earned!</h3>
              <p className="text-muted-foreground">Ready for Unit 5: Family!</p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <span className="text-2xl">🧠</span>
              <span className="text-2xl">👀</span>
              <span className="text-2xl">👃</span>
              <span className="text-2xl">👄</span>
              <span className="text-2xl">👋</span>
              <span className="text-2xl">🦶</span>
              <span className="text-2xl">💪</span>
              <span className="text-2xl">🦵</span>
              <span className="text-2xl">👆</span>
              <span className="text-2xl">🦶</span>
            </div>
            <div className="text-lg font-semibold text-success">
              🎊 UNIT 4 COMPLETE! 🎊
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Unit 4 Master Badge"
        description="You completed all of Unit 4: My Body! Amazing work learning 10 body parts, actions, and phonics A-I!"
        badgeName="Unit 4 Master"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson45-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 4.5 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish Unit 4!" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson45;