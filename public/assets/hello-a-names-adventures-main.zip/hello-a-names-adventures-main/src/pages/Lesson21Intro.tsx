import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { FloatingLogo } from "@/components/FloatingLogo";
import logo from "@/assets/englphoria-logo.png";

export const Lesson21Intro = () => {
  const navigate = useNavigate();

  const startLesson = () => {
    navigate("/lesson21");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-primary/10 flex items-center justify-center p-4">
      <FloatingLogo />
      <div className="max-w-2xl mx-auto text-center space-y-12">
        
        {/* Animated Logo with Color Balloons */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-accent to-primary rounded-full shadow-glow animate-bounce-gentle flex items-center justify-center">
              <img 
                src={logo} 
                alt="EnglEphoria Logo" 
                className="w-20 h-20 object-contain filter brightness-0 invert"
              />
            </div>
            {/* Floating color balloons */}
            <div className="absolute -top-3 -right-4 text-3xl animate-pulse-fun">🔴</div>
            <div className="absolute -bottom-2 -left-4 text-3xl animate-bounce-gentle" style={{animationDelay: '0.5s'}}>🔵</div>
            <div className="absolute top-3 -left-5 text-3xl animate-pulse-fun" style={{animationDelay: '1s'}}>🟡</div>
          </div>
        </div>

        {/* Lesson Title */}
        <div className="space-y-6">
          <h1 className="text-5xl font-bold font-fredoka rainbow-text">
            Welcome to Unit 2!
          </h1>
          
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl border-2 border-accent/20 shadow-fun">
            <h2 className="text-3xl font-bold font-fredoka text-accent mb-4">
              🎨 Lesson 2.1
            </h2>
            <h3 className="text-2xl font-semibold text-foreground mb-3">
              My Colors: Red, Blue, Yellow
            </h3>
            <p className="text-lg text-muted-foreground">
              Pre-Starter Level • 25-30 Fun Minutes • 21 Interactive Slides
            </p>
          </div>
        </div>

        {/* What You'll Learn Section */}
        <div className="bg-gradient-to-br from-red-400 via-blue-400 to-yellow-400 p-8 rounded-3xl border-2 border-white/30 shadow-glow">
          <h3 className="text-2xl font-bold font-fredoka text-white mb-6 sparkle">
            🌈 Today's Colorful Adventure!
          </h3>
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🔴</div>
              <p className="text-white font-fredoka font-semibold">Learn RED!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🔵</div>
              <p className="text-white font-fredoka font-semibold">Discover BLUE!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🟡</div>
              <p className="text-white font-fredoka font-semibold">Find YELLOW!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🐱</div>
              <p className="text-white font-fredoka font-semibold">Meet Letter C!</p>
            </div>
          </div>
          
          {/* Lesson Navigation */}
          <div className="flex gap-3 justify-center flex-wrap">
            <Button
              onClick={() => navigate("/lesson3-intro")}
              variant="outline"
              size="default"
              className="text-lg font-bold font-fredoka border-white/30 text-white hover:bg-white/20 bg-white/10"
            >
              ← Unit 1 Review
            </Button>
            <Button
              onClick={startLesson}
              size="default"
              className="text-lg font-bold font-fredoka bg-white text-blue-600 hover:bg-white/90 shadow-lg"
            >
              🎨 Start Colors Lesson!
            </Button>
            <Button
              onClick={() => navigate("/lesson22-intro")}
              variant="outline"
              size="default"
              className="text-lg font-bold font-fredoka border-white/30 text-white hover:bg-white/20 bg-white/10"
            >
              Lesson 2.2 →
            </Button>
          </div>
        </div>

        {/* Ready Message */}
        <p className="text-lg text-muted-foreground font-fredoka">
          Ready to explore the world of colors? Let's paint with words! 🎨
        </p>
      </div>
    </div>
  );
};

export default Lesson21Intro;