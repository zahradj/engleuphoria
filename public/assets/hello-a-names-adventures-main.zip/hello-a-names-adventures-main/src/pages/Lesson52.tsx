import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson52 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 22;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🐮</div>
            <h1 className="text-4xl font-bold text-primary">Farm Animals!</h1>
            <p className="text-xl text-muted-foreground">Welcome to the farm! Meet our animal friends!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🌾</div>
              <div className="flex justify-center space-x-4">
                <div className="text-4xl animate-bounce">🐦</div>
                <div className="text-4xl animate-bounce" style={{ animationDelay: '0.2s' }}>🐄</div>
                <div className="text-4xl animate-bounce" style={{ animationDelay: '0.4s' }}>🦆</div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Quick Review</h2>
            <p className="text-lg text-muted-foreground">Let's remember our pets!</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="text-4xl">🐱</div>
                <h3 className="text-xl font-semibold">Cat</h3>
                <p className="text-sm">"It is a cat."</p>
                <AudioButton text="It is a cat" />
              </div>
              <div className="space-y-2">
                <div className="text-4xl">🐶</div>
                <h3 className="text-xl font-semibold">Dog</h3>
                <p className="text-sm">"It is a dog."</p>
                <AudioButton text="It is a dog" />
              </div>
              <div className="space-y-2">
                <div className="text-4xl">🐟</div>
                <h3 className="text-xl font-semibold">Fish</h3>
                <p className="text-sm">"It is a fish."</p>
                <AudioButton text="It is a fish" />
              </div>
            </div>
            <p className="text-success font-semibold">Perfect! Now let's visit the farm!</p>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Time</h2>
            <div className="text-6xl mb-4">🎵</div>
            <p className="text-lg">Let's chant: A, B, C, D, E, F, G, H, I...</p>
            <div className="bg-primary/10 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">New Letter: Jj</h3>
              <div className="text-4xl mb-2">🍯</div>
              <p className="text-xl">/ʤ/ like Jam, Juice, Jump</p>
              <AudioButton text="J, jam, juice, jump" className="mt-4" />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Bird!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🐦</div>
              <h3 className="text-3xl font-bold text-primary">Bird</h3>
              <p className="text-lg text-muted-foreground">Tap to hear the bird!</p>
              <div className="text-2xl mt-2">Tweet! Tweet! 🔊</div>
              <AudioButton text="bird" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Cow!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🐄</div>
              <h3 className="text-3xl font-bold text-primary">Cow</h3>
              <p className="text-lg text-muted-foreground">Tap to hear the cow!</p>
              <div className="text-2xl mt-2">Moooo! 🔊</div>
              <AudioButton text="cow" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Duck!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🦆</div>
              <h3 className="text-3xl font-bold text-primary">Duck</h3>
              <p className="text-lg text-muted-foreground">Tap to hear the duck!</p>
              <div className="text-2xl mt-2">Quack! Quack! 🔊</div>
              <AudioButton text="duck" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Listen & Repeat</h2>
            <p className="text-lg text-muted-foreground">Click each farm animal to hear its name</p>
            <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🐦 Bird</span>
                <AudioButton text="bird" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🐄 Cow</span>
                <AudioButton text="cow" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🦆 Duck</span>
                <AudioButton text="duck" />
              </Button>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Farm Animal Matching</h2>
            <p className="text-lg text-muted-foreground">Match the words to the farm animals!</p>
            <DragDropActivity
              title="Match Animals to Words"
              items={[
                { id: "bird", content: "bird", type: "source", matchId: "bird-target" },
                { id: "cow", content: "cow", type: "source", matchId: "cow-target" },
                { id: "duck", content: "duck", type: "source", matchId: "duck-target" },
                { id: "bird-target", content: "🐦", type: "target" },
                { id: "cow-target", content: "🐄", type: "target" },
                { id: "duck-target", content: "🦆", type: "target" }
              ]}
              onComplete={() => console.log("Farm matching completed!")}
            />
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐦</div>
              <h3 className="text-2xl font-bold text-primary">It is a bird.</h3>
              <AudioButton text="It is a bird" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐄</div>
              <h3 className="text-2xl font-bold text-primary">It is a cow.</h3>
              <AudioButton text="It is a cow" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🦆</div>
              <h3 className="text-2xl font-bold text-primary">It is a duck.</h3>
              <AudioButton text="It is a duck" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Speaking Drill</h2>
            <p className="text-lg text-muted-foreground">When I show a farm animal, say the full sentence!</p>
            <SpeakingActivity
              prompt="Look at the farm animal and say the sentence"
              expectedResponse="It is a bird"
              onComplete={() => console.log("Speaking completed!")}
            />
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Builder</h2>
            <p className="text-lg text-muted-foreground">Build the sentence: "It is a duck"</p>
            <DragDropActivity
              title="Complete the Sentence"
              items={[
                { id: "it", content: "It", type: "source", matchId: "word1" },
                { id: "is", content: "is", type: "source", matchId: "word2" },
                { id: "a", content: "a", type: "source", matchId: "word3" },
                { id: "duck", content: "duck", type: "source", matchId: "word4" },
                { id: "period", content: ".", type: "source", matchId: "word5" },
                { id: "word1", content: "1st word", type: "target" },
                { id: "word2", content: "2nd word", type: "target" },
                { id: "word3", content: "3rd word", type: "target" },
                { id: "word4", content: "4th word", type: "target" },
                { id: "word5", content: "5th word", type: "target" }
              ]}
              onComplete={() => console.log("Farm sentence built!")}
            />
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Animal Sounds Game!</h2>
            <div className="text-6xl mb-4">🔊</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Listen! What farm animal is it?</h3>
              <div className="text-4xl mb-4">🔊 "Moooo!"</div>
              <div className="grid grid-cols-3 gap-4">
                <Button variant="outline">🐦 Bird</Button>
                <Button variant="outline" className="bg-success/20">🐄 Cow ✓</Button>
                <Button variant="outline">🦆 Duck</Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Excellent! A cow says "Moo!"
              </p>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Farm Bingo!</h2>
            <div className="text-6xl mb-4">🎯</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">I call: "Duck!" - Click the duck!</h3>
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                <Button variant="outline" size="lg" className="p-8 text-4xl">🐦</Button>
                <Button variant="outline" size="lg" className="p-8 text-4xl">🐄</Button>
                <Button variant="outline" size="lg" className="p-8 text-4xl bg-success/20">🦆 ✓</Button>
                <Button variant="outline" size="lg" className="p-8 text-4xl">🐄</Button>
                <Button variant="outline" size="lg" className="p-8 text-4xl">🐦</Button>
                <Button variant="outline" size="lg" className="p-8 text-4xl">🦆</Button>
              </div>
              <p className="text-success font-semibold mt-4">Bingo! Great job!</p>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Spin & Speak Wheel</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="w-48 h-48 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <div className="text-6xl">🐄</div>
              </div>
              <p className="text-lg">The wheel landed on: <strong>Cow</strong></p>
              <div className="bg-primary/10 p-4 rounded mt-4">
                <p className="font-semibold">Now you say:</p>
                <p className="text-xl text-primary">"It is a cow!"</p>
              </div>
              <AudioButton text="It is a cow" className="mt-4" />
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Guess the Hidden Animal</h2>
            <p className="text-lg text-muted-foreground">What's behind the barn door?</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="relative w-48 h-32 mx-auto bg-red-700 rounded-lg mb-4">
                <div className="absolute inset-0 bg-gradient-to-r from-red-800 to-red-600 rounded-lg flex items-center justify-center">
                  <span className="text-white text-lg font-bold">BARN</span>
                </div>
                <div className="absolute right-2 top-1/2 transform -translate-y-1/2 w-8 h-16 bg-yellow-600 rounded"></div>
              </div>
              <p className="text-lg mb-4">🔊 "Tweet! Tweet!"</p>
              <Button 
                size="lg" 
                className="bg-gradient-primary hover:bg-gradient-primary/90"
                onClick={() => console.log("Open barn door!")}
              >
                Open the Barn Door!
              </Button>
              <div className="mt-4 text-6xl">🐦</div>
              <p className="text-xl text-primary font-bold">It is a bird!</p>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Comic Story 1</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6">
                <div className="text-4xl mb-2">👦</div>
                <h3 className="font-bold">Tom says:</h3>
                <div className="text-3xl my-2">🐄</div>
                <p className="text-lg">"It is a cow!"</p>
                <AudioButton text="It is a cow" className="mt-2" />
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-2">👧</div>
                <h3 className="font-bold">Anna says:</h3>
                <div className="text-3xl my-2">🐦</div>
                <p className="text-lg">"It is a bird!"</p>
                <AudioButton text="It is a bird" className="mt-2" />
              </Card>
            </div>
            <p className="text-muted-foreground">Listen and repeat what they say!</p>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Comic Story 2</h2>
            <Card className="p-8 max-w-md mx-auto">
              <div className="text-4xl mb-2">👶</div>
              <h3 className="font-bold">Ben says:</h3>
              <div className="text-4xl my-2">🦆</div>
              <p className="text-lg">"It is a duck!"</p>
              <AudioButton text="It is a duck" className="mt-2" />
            </Card>
            <div className="bg-primary/10 p-4 rounded-lg max-w-md mx-auto">
              <p className="font-semibold">Now you repeat:</p>
              <p className="text-lg">"It is a duck!"</p>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Farm Role-Play</h2>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-4">🚜</div>
              <h3 className="text-xl font-bold mb-4">Welcome to our farm! Teacher asks:</h3>
              <div className="text-5xl mb-4">🦆</div>
              <p className="text-lg mb-4">"What is it?"</p>
              <div className="bg-primary/10 p-4 rounded">
                <p className="font-semibold">Student answers:</p>
                <p className="text-xl text-primary">"It is a duck!"</p>
              </div>
              <AudioButton text="It is a duck" className="mt-4" />
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Farm Animal Quiz</h2>
            <p className="text-lg text-muted-foreground">Which one is a cow?</p>
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <Button variant="outline" size="lg" className="p-8 text-4xl">
                🐦
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="p-8 text-4xl hover:bg-success/20 border-success"
              >
                🐄 ✓
              </Button>
              <Button variant="outline" size="lg" className="p-8 text-4xl">
                🦆
              </Button>
            </div>
            <p className="text-success font-semibold">Perfect! It is a cow!</p>
          </div>
        );

      case 22:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-3xl font-bold text-primary">Farm Adventure Complete!</h2>
            <p className="text-xl">You met all the farm animals!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Farm Friend Badge Earned!</h3>
              <p className="text-muted-foreground">You know birds, cows, and ducks!</p>
            </div>
            <div className="flex justify-center space-x-3">
              <span className="text-3xl">🐦</span>
              <span className="text-3xl">🐄</span>
              <span className="text-3xl">🦆</span>
            </div>
            <div className="bg-success/10 p-4 rounded-lg">
              <p className="text-lg font-semibold">🌾 Farm visited! 🌾</p>
              <div className="text-4xl mt-2">🚜</div>
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Farm Friend Badge"
        description="You learned about farm animals: bird, cow, and duck!"
        badgeName="Farm Friend"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson52-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 5.2 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson52;