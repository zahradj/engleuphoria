import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { FloatingLogo } from "@/components/FloatingLogo";
import logo from "@/assets/englphoria-logo.png";

export const Lesson3Intro = () => {
  const navigate = useNavigate();

  const startLesson = () => {
    navigate("/lesson3");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
      <FloatingLogo />
      <div className="max-w-2xl mx-auto text-center space-y-12">
        
        {/* Animated Logo in Purple Bubble */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-accent to-warning rounded-full shadow-glow animate-bounce-gentle flex items-center justify-center">
              <img 
                src={logo} 
                alt="EnglEphoria Logo" 
                className="w-20 h-20 object-contain filter brightness-0 invert"
              />
            </div>
            {/* Floating sparkles around the bubble */}
            <div className="absolute -top-2 -right-2 text-2xl animate-pulse-fun">🏆</div>
            <div className="absolute -bottom-1 -left-3 text-xl animate-bounce-gentle" style={{animationDelay: '0.5s'}}>⭐</div>
            <div className="absolute top-4 -left-4 text-lg animate-pulse-fun" style={{animationDelay: '1s'}}>🎭</div>
          </div>
        </div>

        {/* Lesson Title */}
        <div className="space-y-6">
          <h1 className="text-5xl font-bold font-fredoka rainbow-text">
            Review Time, Champion!
          </h1>
          
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl border-2 border-accent/20 shadow-fun">
            <h2 className="text-3xl font-bold font-fredoka text-accent mb-4">
              🎓 Lesson 1.3
            </h2>
            <h3 className="text-2xl font-semibold text-foreground mb-3">
              Review Role-Play
            </h3>
            <p className="text-lg text-muted-foreground">
              Pre-Starter Level • Unit 1 Review • 25-30 Fun Minutes
            </p>
          </div>
        </div>

        {/* What You'll Review Section */}
        <div className="bg-gradient-accent p-8 rounded-3xl border-2 border-accent/30 shadow-glow">
          <h3 className="text-2xl font-bold font-fredoka text-white mb-6 sparkle">
            🎭 Today's Review Adventure!
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">👋</div>
              <p className="text-white font-fredoka font-semibold">All Greetings!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🔤</div>
              <p className="text-white font-fredoka font-semibold">Letters A & B!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🎰</div>
              <p className="text-white font-fredoka font-semibold">Spin & Speak!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🎯</div>
              <p className="text-white font-fredoka font-semibold">Greeting Bingo!</p>
            </div>
          </div>
        </div>

        {/* Review Focus */}
        <div className="bg-white/90 backdrop-blur-sm p-6 rounded-3xl border-2 border-warning/30">
          <h4 className="text-xl font-bold text-warning mb-4">🎯 What We'll Review:</h4>
          <div className="grid grid-cols-1 gap-3 text-left">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-warning rounded-full"></div>
              <span className="text-foreground">Hello, Hi, Bye greetings</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-warning rounded-full"></div>
              <span className="text-foreground">Phonics A & B sounds</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-warning rounded-full"></div>
              <span className="text-foreground">"Hello, I am ___" sentences</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-warning rounded-full"></div>
              <span className="text-foreground">Role-play with cartoon friends</span>
            </div>
          </div>
        </div>

        {/* Start Button */}
        <div className="space-y-4">
          <div className="flex gap-4 justify-center">
            <Button
              onClick={startLesson}
              size="fun"
              variant="kid"
              className="text-2xl font-bold font-fredoka shadow-glow hover:shadow-fun transform hover:scale-110 transition-all duration-300 bg-gradient-accent"
            >
              🎭 Start Review! 🏆
            </Button>
            <Button
              onClick={() => navigate("/lesson2-intro")}
              variant="outline"
              size="fun"
              className="text-xl font-bold font-fredoka border-primary text-primary hover:bg-primary/10"
            >
              ← Back to Lesson 1.2
            </Button>
          </div>
          <p className="text-sm text-muted-foreground font-fredoka">
            Ready to show what you've learned? Let's go!
          </p>
        </div>
      </div>
    </div>
  );
};

export default Lesson3Intro;