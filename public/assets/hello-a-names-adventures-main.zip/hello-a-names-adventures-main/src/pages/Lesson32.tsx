import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";

const totalSlides = 22;

const Lesson32 = () => {
  const [currentSlide, setCurrentSlide] = useState(1);
  const [showBadgeReward, setShowBadgeReward] = useState(false);
  const navigate = useNavigate();

  const allNumbers = [1, 2, 3, 4, 5];
  const newNumbers = [4, 5];
  const newToys = ["doll", "teddy"];
  const allToys = ["ball", "car", "doll", "teddy"];
  
  const [basketItems, setBasketItems] = useState<string[]>([]);
  const [spinResult, setSpinResult] = useState<{toy: string, number: number} | null>(null);
  const [clickedObjects, setClickedObjects] = useState<number[]>([]);
  const [reviewCorrect, setReviewCorrect] = useState<number[]>([]);

  const nextSlide = () => {
    if (currentSlide >= totalSlides) {
      setShowBadgeReward(true);
    } else {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const handleObjectClick = (id: number) => {
    if (!clickedObjects.includes(id)) {
      setClickedObjects(prev => [...prev, id]);
    }
  };

  const handleSpin = () => {
    const randomToy = allToys[Math.floor(Math.random() * allToys.length)];
    const randomNumber = newNumbers[Math.floor(Math.random() * newNumbers.length)];
    setSpinResult({ toy: randomToy, number: randomNumber });
  };

  const handleDragToBasket = (toy: string) => {
    setBasketItems(prev => [...prev, toy]);
  };

  const handleReviewAnswer = (answer: number) => {
    setReviewCorrect(prev => [...prev, answer]);
  };

  if (showBadgeReward) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
        <BadgeReward
          title="Toy Collector Champion!"
          description="You've mastered numbers 1-5 and all the toys! Amazing progress!"
          badgeName="Toy Collector Badge 🧸"
          onContinue={() => navigate("/")}
        />
      </div>
    );
  }

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-8">
            <div className="flex justify-center gap-4">
              <div className="text-8xl animate-bounce-gentle">🎲</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.3s'}}>👧</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.6s'}}>🧸</div>
            </div>
            <h1 className="text-5xl font-bold font-fredoka rainbow-text">
              More Numbers & Toys!
            </h1>
            <p className="text-2xl font-fredoka text-primary">
              Let's count to 5 and meet new toy friends! 🔢
            </p>
            <div className="flex justify-center gap-4">
              {newNumbers.map(num => (
                <div key={num} className="text-center">
                  <div className="w-20 h-20 bg-gradient-accent rounded-full flex items-center justify-center text-white text-3xl font-bold animate-pulse-fun">
                    {num}
                  </div>
                  <p className="text-xl font-bold mt-2">{num === 4 ? 'Four' : 'Five'}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🔢 Quick Number Review: 1-3!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Let's count together! Click each number and count aloud!
            </p>
            <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto">
              {[1, 2, 3].map(num => (
                <Card 
                  key={num} 
                  className={`p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105 ${
                    reviewCorrect.includes(num) ? 'border-success bg-success/10' : ''
                  }`}
                  onClick={() => handleReviewAnswer(num)}
                >
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto">
                      {num}
                    </div>
                    <div className="text-4xl">
                      {num === 1 ? '🍎' : 
                       num === 2 ? '⭐⭐' : 
                       '🎈🎈🎈'}
                    </div>
                    <p className="text-xl font-bold">
                      {num === 1 ? 'ONE' : num === 2 ? 'TWO' : 'THREE'}
                    </p>
                    <AudioButton text={num === 1 ? 'one' : num === 2 ? 'two' : 'three'} />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎵 Phonics Time: A-E & F!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Let's review A-E and learn the new letter F!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-4 max-w-5xl mx-auto">
              {['A', 'B', 'C', 'D', 'E', 'F'].map((letter, index) => (
                <Card key={letter} className="p-4 text-center hover:shadow-lg transition-all">
                  <div className="space-y-3">
                    <div className={`text-3xl font-bold ${letter === 'F' ? 'text-accent animate-pulse' : 'text-primary'}`}>
                      {letter}{letter.toLowerCase()}
                    </div>
                    <p className="text-sm font-semibold">
                      {letter === 'A' ? 'Apple' : 
                       letter === 'B' ? 'Ball' : 
                       letter === 'C' ? 'Cat' : 
                       letter === 'D' ? 'Duck' : 
                       letter === 'E' ? 'Elephant' :
                       'Fish'}
                    </p>
                    <div className="text-2xl">
                      {letter === 'A' ? '🍎' : 
                       letter === 'B' ? '⚽' : 
                       letter === 'C' ? '🐱' : 
                       letter === 'D' ? '🦆' : 
                       letter === 'E' ? '🐘' :
                       '🐟'}
                    </div>
                    <AudioButton text={letter} />
                  </div>
                </Card>
              ))}
            </div>
            <Card className="p-6 max-w-md mx-auto bg-gradient-accent text-white">
              <h3 className="text-xl font-bold mb-2">New Letter: F</h3>
              <p className="text-lg">F says /f/ like Fish, Fan, Frog! 🐟</p>
            </Card>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              4️⃣ Number Four!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Four stars appear! Count with me: ONE, TWO, THREE, FOUR!
            </p>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
                {[1, 2, 3, 4].map((star, index) => (
                  <div 
                    key={star}
                    className="text-6xl animate-bounce"
                    style={{animationDelay: `${index * 0.3}s`}}
                  >
                    ✨
                  </div>
                ))}
              </div>
              <div className="text-center space-y-4">
                <div className="w-28 h-28 bg-gradient-warning rounded-full flex items-center justify-center text-white text-5xl font-bold mx-auto">
                  4
                </div>
                <p className="text-4xl font-bold text-warning">FOUR</p>
                <AudioButton text="four" className="text-xl" />
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              5️⃣ Number Five!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Five balloons float up! Count: ONE, TWO, THREE, FOUR, FIVE!
            </p>
            <div className="space-y-6">
              <div className="flex justify-center gap-2 flex-wrap max-w-md mx-auto">
                {[1, 2, 3, 4, 5].map((balloon, index) => (
                  <div 
                    key={balloon}
                    className="text-5xl animate-float"
                    style={{animationDelay: `${index * 0.2}s`}}
                  >
                    🎈
                  </div>
                ))}
              </div>
              <div className="text-center space-y-4">
                <div className="w-28 h-28 bg-gradient-success rounded-full flex items-center justify-center text-white text-5xl font-bold mx-auto">
                  5
                </div>
                <p className="text-4xl font-bold text-success">FIVE</p>
                <AudioButton text="five" className="text-xl" />
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎯 Counting Game: Click & Count!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Click the items one by one while counting with teacher!
            </p>
            <div className="grid grid-cols-5 gap-4 max-w-3xl mx-auto">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(id => (
                <div
                  key={id}
                  className={`text-5xl cursor-pointer transition-all hover:scale-110 ${
                    clickedObjects.includes(id) ? 'opacity-50 scale-75' : ''
                  }`}
                  onClick={() => handleObjectClick(id)}
                >
                  {id <= 4 ? '✨' : '🎈'}
                </div>
              ))}
            </div>
            <div className="text-center space-y-4">
              <p className="text-xl font-bold">
                Clicked: {clickedObjects.length} objects
              </p>
              <p className="text-lg text-muted-foreground">
                Count aloud: {clickedObjects.map((_, i) => i + 1).join(', ')}
              </p>
              <Button 
                onClick={() => setClickedObjects([])} 
                variant="outline"
                className="mt-4"
              >
                Reset & Try Again
              </Button>
            </div>
          </div>
        );

      case 7:
        return (
          <DragDropActivity
            title="🔢 Match Numbers 4 & 5 to Sets!"
            items={[
              { id: '4', content: '4', type: 'source', matchId: 'four-stars' },
              { id: '5', content: '5', type: 'source', matchId: 'five-balloons' },
              { id: 'four-stars', content: '✨✨✨✨', type: 'target' },
              { id: 'five-balloons', content: '🎈🎈🎈🎈🎈', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 8:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              ❓ Quick Quiz: How Many Apples?
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Count the apples and choose the right number!
            </p>
            <div className="space-y-6">
              <div className="flex justify-center gap-2 flex-wrap">
                {[1, 2, 3, 4, 5].map(apple => (
                  <div key={apple} className="text-6xl">🍎</div>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                {[4, 5, 6].map(option => (
                  <Card key={option} className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-2">
                        {option}
                      </div>
                      <Button className="capitalize">
                        {option === 4 ? 'Four' : option === 5 ? 'Five' : 'Six'}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              👧 New Toy: Doll!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Meet our new toy friend! Tap to see the doll dance!
            </p>
            <div className="space-y-6">
              <div className="text-9xl animate-bounce cursor-pointer hover:scale-110 transition-all">
                👧
              </div>
              <Card className="p-8 max-w-md mx-auto bg-gradient-to-r from-pink-400 to-purple-400 text-white">
                <div className="text-center space-y-4">
                  <h3 className="text-4xl font-bold">DOLL</h3>
                  <AudioButton text="doll" className="text-xl text-white border-white" />
                  <p className="text-lg">
                    Say: "Doll" 👧
                  </p>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <p className="text-sm">A doll is a toy that looks like a person!</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🧸 New Toy: Teddy Bear!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Say hello to our cuddly teddy! Tap to see teddy wave!
            </p>
            <div className="space-y-6">
              <div className="text-9xl cursor-pointer hover:scale-110 transition-all animate-bounce-gentle">
                🧸
              </div>
              <Card className="p-8 max-w-md mx-auto bg-gradient-to-r from-brown-400 to-orange-400 text-white">
                <div className="text-center space-y-4">
                  <h3 className="text-4xl font-bold">TEDDY</h3>
                  <AudioButton text="teddy" className="text-xl text-white border-white" />
                  <p className="text-lg">
                    Say: "Teddy" 🧸
                  </p>
                  <div className="bg-white/20 p-4 rounded-xl">
                    <p className="text-sm">A teddy bear is soft and cuddly!</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🗣️ Speaking Drill: New Toys!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher models, you repeat: "Doll" and "Teddy"
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
              <Card className="p-8 bg-gradient-to-br from-pink-100 to-purple-100">
                <div className="text-center space-y-4">
                  <div className="text-8xl">👧</div>
                  <SpeakingActivity 
                    prompt="Say: Doll"
                    expectedResponse="Doll"
                    onComplete={() => {}}
                  />
                </div>
              </Card>
              <Card className="p-8 bg-gradient-to-br from-brown-100 to-orange-100">
                <div className="text-center space-y-4">
                  <div className="text-8xl">🧸</div>
                  <SpeakingActivity 
                    prompt="Say: Teddy"
                    expectedResponse="Teddy"
                    onComplete={() => {}}
                  />
                </div>
              </Card>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎯 Toy Matching Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Match the toy words to the pictures!
            </p>
            <div className="grid grid-cols-2 gap-8 max-w-3xl mx-auto">
              <div className="space-y-4">
                <h3 className="text-xl font-bold">Words:</h3>
                <div className="space-y-3">
                  {allToys.map(toy => (
                    <Card key={toy} className="p-4 cursor-pointer hover:shadow-lg transition-all">
                      <p className="text-xl font-bold uppercase">{toy}</p>
                    </Card>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-bold">Pictures:</h3>
                <div className="space-y-3">
                  <Card className="p-4 cursor-pointer hover:shadow-lg transition-all">
                    <div className="text-5xl">🧸</div>
                  </Card>
                  <Card className="p-4 cursor-pointer hover:shadow-lg transition-all">
                    <div className="text-5xl">⚽</div>
                  </Card>
                  <Card className="p-4 cursor-pointer hover:shadow-lg transition-all">
                    <div className="text-5xl">👧</div>
                  </Card>
                  <Card className="p-4 cursor-pointer hover:shadow-lg transition-all">
                    <div className="text-5xl">🚗</div>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Model Sentence 1
            </h2>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-pink-400 to-purple-400 text-white">
              <div className="text-center space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  {[1, 2, 3, 4].map(doll => (
                    <div key={doll} className="text-5xl">👧</div>
                  ))}
                </div>
                <div className="bg-white/20 p-6 rounded-2xl">
                  <p className="text-3xl font-bold">
                    "Four dolls."
                  </p>
                </div>
                <AudioButton text="Four dolls" className="text-white border-white" />
                <p className="text-xl">
                  Listen and repeat: "Four dolls."
                </p>
              </div>
            </Card>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Model Sentence 2
            </h2>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-brown-400 to-orange-400 text-white">
              <div className="text-center space-y-6">
                <div className="flex justify-center gap-2 flex-wrap">
                  {[1, 2, 3, 4, 5].map(teddy => (
                    <div key={teddy} className="text-4xl">🧸</div>
                  ))}
                </div>
                <div className="bg-white/20 p-6 rounded-2xl">
                  <p className="text-3xl font-bold">
                    "Five teddies."
                  </p>
                </div>
                <AudioButton text="Five teddies" className="text-white border-white" />
                <p className="text-xl">
                  Listen and repeat: "Five teddies."
                </p>
              </div>
            </Card>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Model Sentence 3
            </h2>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-success text-white">
              <div className="text-center space-y-6">
                <div className="text-8xl">🧸</div>
                <div className="bg-white/20 p-6 rounded-2xl">
                  <p className="text-3xl font-bold">
                    "I have a teddy."
                  </p>
                </div>
                <AudioButton text="I have a teddy" className="text-white border-white" />
                <p className="text-xl">
                  Listen and repeat: "I have a teddy."
                </p>
              </div>
            </Card>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🗣️ Speaking Drill: Number + Toy!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher shows toys → You respond with number + toy!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
              {[
                { toys: '👧👧👧👧', question: 'How many dolls?', answer: 'Four dolls' },
                { toys: '🧸🧸🧸🧸🧸', question: 'How many teddies?', answer: 'Five teddies' }
              ].map((item, index) => (
                <Card key={index} className="p-6">
                  <div className="space-y-4">
                    <div className="text-4xl leading-relaxed">{item.toys}</div>
                    <p className="font-bold text-lg">"{item.question}"</p>
                    <SpeakingActivity 
                      prompt={`Say: "${item.answer}"`}
                      expectedResponse={item.answer}
                      onComplete={() => {}}
                    />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🧺 Grab & Count Game: New Toys!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Drag dolls and teddies into the basket, then count them!
            </p>
            <div className="grid grid-cols-2 gap-8 max-w-3xl mx-auto">
              <div className="space-y-4">
                <h3 className="text-xl font-bold">Available Toys:</h3>
                <div className="grid grid-cols-2 gap-3">
                  {['👧', '🧸', '👧', '🧸', '👧', '🧸'].map((toy, index) => (
                    <div
                      key={index}
                      className="text-5xl cursor-pointer hover:scale-110 transition-all p-2 border-2 border-dashed border-primary/30 rounded-lg"
                      onClick={() => handleDragToBasket(toy)}
                    >
                      {toy}
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-bold">Toy Basket:</h3>
                <Card className="p-6 min-h-[250px] border-2 border-dashed border-primary">
                  <div className="text-5xl mb-4">🧺</div>
                  <div className="grid grid-cols-3 gap-2">
                    {basketItems.map((toy, index) => (
                      <span key={index} className="text-3xl">{toy}</span>
                    ))}
                  </div>
                  <div className="mt-4 space-y-2">
                    <p className="text-lg font-bold">
                      Total: {basketItems.length} toys
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Dolls: {basketItems.filter(toy => toy === '👧').length} | 
                      Teddies: {basketItems.filter(toy => toy === '🧸').length}
                    </p>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🛒 Extended Toy Shop Role-Play!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              More toys in the shop! Practice asking and answering!
            </p>
            <div className="max-w-3xl mx-auto">
              <Card className="p-8 bg-gradient-warm text-white">
                <div className="space-y-6">
                  <div className="flex items-center justify-center gap-4">
                    <div className="text-6xl">👨‍💼</div>
                    <div className="speech-bubble bg-white/20 p-4 rounded-2xl">
                      <p className="text-xl font-bold">
                        "What toy do you want?"
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { toy: '👧', name: 'doll', phrase: 'I want a doll' },
                      { toy: '🧸', name: 'teddy', phrase: 'I want a teddy' },
                      { toy: '⚽', name: 'ball', phrase: 'I want a ball' },
                      { toy: '🚗', name: 'car', phrase: 'I want a car' }
                    ].map((item, index) => (
                      <Card key={index} className="p-4 bg-white/20 hover:bg-white/30 cursor-pointer">
                        <div className="text-center space-y-2">
                          <div className="text-4xl">{item.toy}</div>
                          <p className="text-sm font-bold">{item.name}</p>
                          <Button variant="outline" className="text-xs">
                            "{item.phrase}"
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                  <p className="text-lg">
                    Choose your toy and practice speaking your answer!
                  </p>
                </div>
              </Card>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎪 Advanced Spin & Count Wheel!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Spin for any toy (1-5) and say the complete sentence!
            </p>
            <div className="space-y-6">
              <div className="relative mx-auto w-64 h-64">
                <div className="w-full h-full rounded-full border-8 border-primary shadow-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <div className="text-6xl animate-spin-slow">🎯</div>
                </div>
              </div>
              <Button onClick={handleSpin} size="fun" variant="kid">
                🎪 Spin the Magic Wheel!
              </Button>
              {spinResult && (
                <Card className="p-6 max-w-md mx-auto bg-gradient-success text-white">
                  <h3 className="text-2xl font-bold mb-4">Spin Result:</h3>
                  <div className="flex justify-center gap-2 mb-4 flex-wrap">
                    {Array.from({length: spinResult.number}, (_, i) => (
                      <span key={i} className="text-3xl">
                        {spinResult.toy === 'ball' ? '⚽' : 
                         spinResult.toy === 'car' ? '🚗' : 
                         spinResult.toy === 'doll' ? '👧' : '🧸'}
                      </span>
                    ))}
                  </div>
                  <p className="text-xl font-bold mb-4">
                    Now say: "{spinResult.number === 4 ? 'Four' : 'Five'} {spinResult.toy}{spinResult.number > 1 ? 's' : ''}."
                  </p>
                  <AudioButton 
                    text={`${spinResult.number === 4 ? 'Four' : 'Five'} ${spinResult.toy}${spinResult.number > 1 ? 's' : ''}`}
                    className="text-white border-white"
                  />
                </Card>
              )}
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Final Quiz: How Many Teddies?
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Count carefully and choose the right answer!
            </p>
            <div className="space-y-6">
              <div className="flex justify-center gap-2 flex-wrap">
                {[1, 2, 3, 4].map(teddy => (
                  <div key={teddy} className="text-6xl">🧸</div>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                {[3, 4, 5].map(option => (
                  <Card key={option} className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-2">
                        {option}
                      </div>
                      <Button className="capitalize">
                        {option === 3 ? 'Three' : option === 4 ? 'Four' : 'Five'}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎵 Final Phonics Recap: A-F!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Let's chant all letters with rhythm - A to F!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-4 max-w-5xl mx-auto">
              {[
                { letter: 'A', word: 'Apple', emoji: '🍎' },
                { letter: 'B', word: 'Ball', emoji: '⚽' },
                { letter: 'C', word: 'Cat', emoji: '🐱' },
                { letter: 'D', word: 'Duck', emoji: '🦆' },
                { letter: 'E', word: 'Elephant', emoji: '🐘' },
                { letter: 'F', word: 'Fish', emoji: '🐟' }
              ].map((item) => (
                <Card key={item.letter} className="p-4 text-center hover:shadow-lg transition-all">
                  <div className="space-y-2">
                    <div className="text-3xl font-bold text-primary">{item.letter}{item.letter.toLowerCase()}</div>
                    <div className="text-2xl">{item.emoji}</div>
                    <p className="text-sm font-semibold">{item.word}</p>
                    <AudioButton text={item.letter} />
                  </div>
                </Card>
              ))}
            </div>
            <Card className="p-6 max-w-2xl mx-auto bg-gradient-primary text-white">
              <h3 className="text-xl font-bold mb-4">Complete A-F Chant!</h3>
              <p className="text-lg">
                🍎 A-Apple, ⚽ B-Ball, 🐱 C-Cat, 🦆 D-Duck, 🐘 E-Elephant, 🐟 F-Fish!
              </p>
              <AudioButton text="A Apple B Ball C Cat D Duck E Elephant F Fish" className="mt-4 text-white border-white" />
            </Card>
          </div>
        );

      case 22:
        return (
          <div className="text-center space-y-8">
            <div className="text-8xl animate-bounce">🏅</div>
            <h2 className="text-5xl font-bold font-fredoka rainbow-text">
              Congratulations!
            </h2>
            <h3 className="text-3xl font-bold font-fredoka text-primary">
              Toy Collector Badge Earned! 🧸
            </h3>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-primary/20 to-accent/20">
              <div className="space-y-4">
                <div className="text-6xl">🏆</div>
                <h4 className="text-2xl font-bold">You are now a Master Toy Collector!</h4>
                <p className="text-lg">
                  You've learned to count 1-5 and know four amazing toys! 
                  Fantastic work with numbers, toys, and sentences!
                </p>
                <div className="grid grid-cols-5 gap-2 max-w-md mx-auto">
                  {[1, 2, 3, 4, 5].map(num => (
                    <div key={num} className="text-center">
                      <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {num}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex justify-center gap-4">
                  <span className="text-3xl">⚽</span>
                  <span className="text-3xl">🚗</span>
                  <span className="text-3xl">👧</span>
                  <span className="text-3xl">🧸</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Ball, Car, Doll, Teddy - All mastered!
                </p>
              </div>
            </Card>
            <div className="text-6xl animate-pulse">✨🎉✨</div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 p-4">
      <FloatingLogo />
      
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Lesson 3.2 • Numbers 4-5 & More Toys
          </Badge>
          <ProgressBar current={currentSlide} total={totalSlides} />
        </div>

        {/* Slide Content */}
        <Card className="p-8 mb-8 min-h-[500px] flex items-center justify-center">
          {renderSlide()}
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button
            onClick={prevSlide}
            disabled={currentSlide === 1}
            variant="outline"
            size="lg"
          >
            ← Previous
          </Button>
          
          <span className="text-lg font-semibold">
            {currentSlide} / {totalSlides}
          </span>
          
          <Button
            onClick={nextSlide}
            size="lg"
            className="bg-gradient-primary hover:shadow-button"
          >
            {currentSlide === totalSlides ? "Finish! 🏅" : "Next →"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Lesson32;