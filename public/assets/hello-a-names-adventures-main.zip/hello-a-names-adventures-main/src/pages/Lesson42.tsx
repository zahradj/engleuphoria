import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson42 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 22;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🎉</div>
            <h1 className="text-4xl font-bold text-primary">More Body Parts!</h1>
            <p className="text-xl text-muted-foreground">Let's learn about mouth, hands, and feet!</p>
            <div className="flex justify-center space-x-4">
              <div className="text-4xl">👄</div>
              <div className="text-4xl">👋</div>
              <div className="text-4xl">🦶</div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Quick Review</h2>
            <p className="text-lg text-muted-foreground">Let's remember from Lesson 4.1</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="text-5xl">🧠</div>
                <h3 className="text-xl font-semibold">Head</h3>
                <AudioButton text="head" />
              </div>
              <div className="space-y-2">
                <div className="text-5xl">👀</div>
                <h3 className="text-xl font-semibold">Eyes</h3>
                <AudioButton text="eyes" />
              </div>
              <div className="space-y-2">
                <div className="text-5xl">👃</div>
                <h3 className="text-xl font-semibold">Nose</h3>
                <AudioButton text="nose" />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Warm-Up</h2>
            <div className="text-6xl mb-4">🎵</div>
            <p className="text-lg">Let's sing: A, B, C, D, E, F, G...</p>
            <div className="bg-primary/10 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">New Letter: Hh</h3>
              <div className="text-4xl mb-2">🎩</div>
              <p className="text-xl">/h/ like Hat, Horse, Hand</p>
              <AudioButton text="H, hat, horse, hand" className="mt-4" />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Body Part</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">👄</div>
              <h3 className="text-3xl font-bold text-primary">Mouth</h3>
              <p className="text-lg text-muted-foreground">Tap to see it smile!</p>
              <AudioButton text="mouth" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Body Part</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">👋</div>
              <h3 className="text-3xl font-bold text-primary">Hands</h3>
              <p className="text-lg text-muted-foreground">Tap to see them clap!</p>
              <AudioButton text="hands" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Body Part</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🦶</div>
              <h3 className="text-3xl font-bold text-primary">Feet</h3>
              <p className="text-lg text-muted-foreground">Tap to see them stomp!</p>
              <AudioButton text="feet" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Listen & Repeat</h2>
            <p className="text-lg text-muted-foreground">Click each word to hear it</p>
            <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">👄 Mouth</span>
                <AudioButton text="mouth" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">👋 Hands</span>
                <AudioButton text="hands" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🦶 Feet</span>
                <AudioButton text="feet" />
              </Button>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Body Puzzle</h2>
            <p className="text-lg text-muted-foreground">Drag the labels to the correct body parts</p>
            <DragDropActivity
              title="Body Puzzle"
              items={[
                { id: "mouth", content: "mouth", type: "source", matchId: "mouth-target" },
                { id: "hands", content: "hands", type: "source", matchId: "hands-target" },
                { id: "feet", content: "feet", type: "source", matchId: "feet-target" },
                { id: "mouth-target", content: "👄 Mouth", type: "target" },
                { id: "hands-target", content: "👋 Hands", type: "target" },
                { id: "feet-target", content: "🦶 Feet", type: "target" }
              ]}
              onComplete={() => console.log("Puzzle completed!")}
            />
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">👄</div>
              <h3 className="text-2xl font-bold text-primary">This is my mouth.</h3>
              <AudioButton text="This is my mouth" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">👋</div>
              <h3 className="text-2xl font-bold text-primary">These are my hands.</h3>
              <AudioButton text="These are my hands" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🦶</div>
              <h3 className="text-2xl font-bold text-primary">These are my feet.</h3>
              <AudioButton text="These are my feet" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Speaking Drill</h2>
            <p className="text-lg text-muted-foreground">When I show a body part, say the full sentence!</p>
            <SpeakingActivity
              prompt="Look at the body part and say the sentence"
              expectedResponse="This is my mouth"
              onComplete={() => console.log("Speaking completed!")}
            />
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Builder</h2>
            <p className="text-lg text-muted-foreground">Drag the words to make the sentence</p>
            <DragDropActivity
              title="Sentence Builder"
              items={[
                { id: "these", content: "These", type: "source", matchId: "word1" },
                { id: "are", content: "are", type: "source", matchId: "word2" },
                { id: "my", content: "my", type: "source", matchId: "word3" },
                { id: "hands", content: "hands", type: "source", matchId: "word4" },
                { id: "period", content: ".", type: "source", matchId: "word5" },
                { id: "word1", content: "Word 1", type: "target" },
                { id: "word2", content: "Word 2", type: "target" },
                { id: "word3", content: "Word 3", type: "target" },
                { id: "word4", content: "Word 4", type: "target" },
                { id: "word5", content: "Word 5", type: "target" }
              ]}
              onComplete={() => console.log("Sentence built!")}
            />
            <div className="text-xl font-bold text-primary mt-4">
              "These are my hands."
            </div>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Simon Says Game!</h2>
            <div className="text-6xl mb-4">🎮</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Teacher Says:</h3>
              <div className="space-y-3">
                <Button size="lg" variant="outline" className="w-full">
                  "Touch your mouth!" 👄
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  "Clap your hands!" 👋
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  "Stomp your feet!" 🦶
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Student: Do the action and say the sentence!
              </p>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Guess the Body Part</h2>
            <p className="text-lg text-muted-foreground">Look at the zoomed picture. What is it?</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4">👄</div>
              <div className="grid grid-cols-3 gap-4">
                <Button variant="outline">Mouth ✓</Button>
                <Button variant="outline">Hands</Button>
                <Button variant="outline">Feet</Button>
              </div>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Spin & Speak Wheel</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="w-48 h-48 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <div className="text-6xl">👋</div>
              </div>
              <p className="text-lg">The wheel landed on: <strong>Hands</strong></p>
              <Button size="lg" className="mt-4">
                "These are my hands!" 🗣️
              </Button>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Match Game</h2>
            <p className="text-lg text-muted-foreground">Match the words to the pictures</p>
            <div className="grid grid-cols-2 gap-6 max-w-lg mx-auto">
              <div className="space-y-4">
                <h3 className="font-bold">Words</h3>
                <Button variant="outline" className="w-full">mouth</Button>
                <Button variant="outline" className="w-full">hands</Button>
                <Button variant="outline" className="w-full">feet</Button>
              </div>
              <div className="space-y-4">
                <h3 className="font-bold">Pictures</h3>
                <div className="text-4xl p-4 border-2 border-dashed border-border rounded">👄</div>
                <div className="text-4xl p-4 border-2 border-dashed border-border rounded">👋</div>
                <div className="text-4xl p-4 border-2 border-dashed border-border rounded">🦶</div>
              </div>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Comic Story</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6">
                <div className="text-4xl mb-2">👦</div>
                <h3 className="font-bold">Tom says:</h3>
                <p className="text-lg">"This is my mouth!"</p>
                <AudioButton text="This is my mouth" className="mt-2" />
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-2">👧</div>
                <h3 className="font-bold">Anna says:</h3>
                <p className="text-lg">"These are my hands!"</p>
                <AudioButton text="These are my hands" className="mt-2" />
              </Card>
            </div>
            <p className="text-muted-foreground">Listen and repeat what they say!</p>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Comic Story</h2>
            <Card className="p-8 max-w-md mx-auto">
              <div className="text-4xl mb-2">👶</div>
              <h3 className="font-bold">Ben says:</h3>
              <p className="text-lg">"These are my feet!"</p>
              <AudioButton text="These are my feet" className="mt-2" />
            </Card>
            <div className="bg-primary/10 p-4 rounded-lg">
              <p className="font-semibold">Now you repeat:</p>
              <p className="text-lg">"These are my feet!"</p>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Role-Play Time</h2>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-4">🎭</div>
              <h3 className="text-xl font-bold mb-4">Teacher asks:</h3>
              <p className="text-lg mb-4">"What are these?" 👋</p>
              <div className="bg-primary/10 p-4 rounded">
                <p className="font-semibold">Student answers:</p>
                <p className="text-lg">"These are my hands!"</p>
              </div>
              <AudioButton text="These are my hands" className="mt-4" />
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Quick Quiz</h2>
            <p className="text-lg text-muted-foreground">Which one is the mouth?</p>
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <Button 
                variant="outline" 
                size="lg"
                className="p-8 text-4xl hover:bg-success/20"
              >
                👄
              </Button>
              <Button variant="outline" size="lg" className="p-8 text-4xl">
                👋
              </Button>
              <Button variant="outline" size="lg" className="p-8 text-4xl">
                🦶
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">Click the correct answer!</p>
          </div>
        );

      case 22:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-3xl font-bold text-primary">Congratulations!</h2>
            <p className="text-xl">You learned about mouth, hands, and feet!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Body Builder Badge Earned!</h3>
              <p className="text-muted-foreground">Keep learning about your body!</p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <span className="text-2xl">👄</span>
              <span className="text-2xl">👋</span>
              <span className="text-2xl">🦶</span>
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Body Builder Badge"
        description="You learned about mouth, hands, and feet!"
        badgeName="Body Builder"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson42-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 4.2 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson42;