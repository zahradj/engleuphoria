import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FloatingLogo } from "@/components/FloatingLogo";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { DragDropActivity } from "@/components/DragDropActivity";
import { PhonicsActivity } from "@/components/PhonicsActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";

const totalSlides = 18;

export default function Lesson72() {
  const [currentSlide, setCurrentSlide] = useState(1);
  const navigate = useNavigate();

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-4xl font-bold text-white mb-4">🥛🍞🍚 Food Fun: Meals</h2>
            <p className="text-xl text-white/90">Let's learn about delicious meals!</p>
            <div className="text-6xl">🥛🍞🍚</div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Let's Start! →
            </Button>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📚 Quick Review</h2>
            <p className="text-lg text-white/90">Let's review fruits from Lesson 7.1!</p>
            <div className="flex justify-center gap-4">
              <AudioButton text="Apple" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Banana" className="bg-white/20 hover:bg-white/30 text-white" />
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 3:
        return (
          <PhonicsActivity
            letter="O"
            words={[
              { word: "orange", image: "orange", hasLetter: true },
              { word: "octopus", image: "octopus", hasLetter: true },
              { word: "cat", image: "cat", hasLetter: false }
            ]}
            onComplete={nextSlide}
          />
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🥛 Milk</h2>
            <div className="text-8xl mb-4">🥛</div>
            <AudioButton text="Milk" className="bg-white/20 hover:bg-white/30 text-white text-xl px-8 py-4" />
            <p className="text-lg text-white/90">White, creamy, and healthy!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Next →
            </Button>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🍞 Bread</h2>
            <div className="text-8xl mb-4">🍞</div>
            <AudioButton text="Bread" className="bg-white/20 hover:bg-white/30 text-white text-xl px-8 py-4" />
            <p className="text-lg text-white/90">Brown, soft, and filling!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Next →
            </Button>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🍚 Rice</h2>
            <div className="text-8xl mb-4">🍚</div>
            <AudioButton text="Rice" className="bg-white/20 hover:bg-white/30 text-white text-xl px-8 py-4" />
            <p className="text-lg text-white/90">White, small, and tasty!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Next →
            </Button>
          </div>
        );

      case 7:
        return (
          <DragDropActivity
            title="Match Meals"
            items={[
              { id: '1', content: 'Milk', type: 'source', matchId: '4' },
              { id: '2', content: 'Bread', type: 'source', matchId: '5' },
              { id: '3', content: 'Rice', type: 'source', matchId: '6' },
              { id: '4', content: '🥛', type: 'target' },
              { id: '5', content: '🍞', type: 'target' },
              { id: '6', content: '🍚', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📝 Grammar: I eat / I drink</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🥛</span>
                  <span className="text-white text-lg">"I drink milk."</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🍞</span>
                  <span className="text-white text-lg">"I eat bread."</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🍚</span>
                  <span className="text-white text-lg">"I eat rice."</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Practice →
            </Button>
          </div>
        );

      case 9:
        return (
          <SpeakingActivity
            prompt="Look at the food and say: 'I drink milk'"
            expectedResponse="I drink milk"
            onComplete={nextSlide}
          />
        );

      case 10:
        return (
          <SpeakingActivity
            prompt="Look at the food and say: 'I eat bread'"
            expectedResponse="I eat bread"
            onComplete={nextSlide}
          />
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🍽️ Meal Planning Game</h2>
            <p className="text-lg text-white/90">What do you have for breakfast?</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white p-4">
                <div className="text-3xl mb-1">🥛</div>
                <div className="text-sm">Milk</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">🚗</div>
                <div className="text-sm">Car</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">🐱</div>
                <div className="text-sm">Cat</div>
              </Button>
            </div>
            <p className="text-white/80">Choose what you drink for breakfast!</p>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎮 Food Quiz</h2>
            <p className="text-lg text-white/90">Which one do you EAT?</p>
            <div className="space-y-2">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white block mx-auto">
                🍞 Bread ✓
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white block mx-auto">
                🥛 Milk
              </Button>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Restaurant Role-Play</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👨‍🍳</span>
                  <span className="text-white">"What do you want to eat?"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white">"I want bread and rice!"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👨‍🍳</span>
                  <span className="text-white">"And to drink?"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white">"I want milk, please!"</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Your Turn!</h2>
            <p className="text-lg text-white/90">Order your meal!</p>
            <div className="space-y-4">
              <div className="text-6xl">🍽️</div>
              <p className="text-white/80">Say: "I want..." and choose milk, bread, or rice</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Delicious Choice! →
            </Button>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📝 Quick Review</h2>
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🥛</div>
                <p className="text-white">Milk</p>
                <p className="text-white/60 text-sm">Drink</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍞</div>
                <p className="text-white">Bread</p>
                <p className="text-white/60 text-sm">Eat</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍚</div>
                <p className="text-white">Rice</p>
                <p className="text-white/60 text-sm">Eat</p>
              </Card>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🏠 Homework</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4 text-white">
                <p className="font-semibold">For next time:</p>
                <ul className="text-left space-y-2">
                  <li>• Draw your favorite meal</li>
                  <li>• Practice: "I eat..." and "I drink..."</li>
                  <li>• Tell family what you eat for breakfast</li>
                  <li>• Count how many foods you know</li>
                </ul>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Finish Lesson →
            </Button>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🌟 Lesson Complete!</h2>
            <div className="text-6xl mb-4">🎉</div>
            <p className="text-xl text-white/90">You learned about meals!</p>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 max-w-md mx-auto">
              <p className="text-white font-semibold">New Words: Milk, Bread, Rice</p>
              <p className="text-white/80">Grammar: "I eat..." "I drink..."</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Get Badge! →
            </Button>
          </div>
        );

      case 18:
        return (
          <BadgeReward
            title="Congratulations!"
            description="You completed Lesson 7.2!"
            badgeName="Meal Master Badge"
            onContinue={() => navigate('/lesson/7-3-intro')}
          />
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <ProgressBar current={currentSlide} total={totalSlides} />
          
          <Card className="p-8 bg-white/10 backdrop-blur-sm border-white/20 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </Card>
          
          <div className="mt-6 flex justify-between">
            <Button 
              onClick={() => navigate('/lesson/7-2-intro')}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/10"
            >
              ← Back to Intro
            </Button>
            
            <div className="text-white/60">
              Slide {currentSlide} of {totalSlides}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}