import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { FillInTheGapActivity } from "@/components/FillInTheGapActivity";
import { useState } from "react";
import { FloatingLogo } from "@/components/FloatingLogo";
import logo from "@/assets/englphoria-logo.png";

export const Lesson2Intro = () => {
  const navigate = useNavigate();
  const [showPreview, setShowPreview] = useState(false);

  const startLesson = () => {
    navigate("/lesson2");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
      <FloatingLogo />
      <div className="max-w-2xl mx-auto text-center space-y-12">
        
        {/* Animated Logo in Purple Bubble */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-primary to-accent rounded-full shadow-glow animate-bounce-gentle flex items-center justify-center">
              <img 
                src={logo} 
                alt="EnglEphoria Logo" 
                className="w-20 h-20 object-contain filter brightness-0 invert"
              />
            </div>
            {/* Floating sparkles around the bubble */}
            <div className="absolute -top-2 -right-2 text-2xl animate-pulse-fun">✨</div>
            <div className="absolute -bottom-1 -left-3 text-xl animate-bounce-gentle" style={{animationDelay: '0.5s'}}>⭐</div>
            <div className="absolute top-4 -left-4 text-lg animate-pulse-fun" style={{animationDelay: '1s'}}>🌟</div>
          </div>
        </div>

        {/* Lesson Title */}
        <div className="space-y-6">
          <h1 className="text-5xl font-bold font-fredoka rainbow-text">
            Welcome Back, Super Star!
          </h1>
          
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl border-2 border-primary/20 shadow-fun">
            <h2 className="text-3xl font-bold font-fredoka text-primary mb-4">
              🎓 Lesson 1.2
            </h2>
            <h3 className="text-2xl font-semibold text-foreground mb-3">
              Yes, No, Thank You
            </h3>
            <p className="text-lg text-muted-foreground">
              Pre-Starter Level • 30 Fun Minutes • One-on-One Online
            </p>
          </div>
        </div>

        {/* What You'll Learn Section */}
        <div className="bg-gradient-success p-8 rounded-3xl border-2 border-success/30 shadow-glow">
          <h3 className="text-2xl font-bold font-fredoka text-white mb-6 sparkle">
            🌟 Today's Amazing Journey!
          </h3>
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">✅</div>
              <p className="text-white font-fredoka font-semibold">Say Yes & No!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🙏</div>
              <p className="text-white font-fredoka font-semibold">Thank You Magic!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🅱️</div>
              <p className="text-white font-fredoka font-semibold">Meet Letter B!</p>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
              <div className="text-3xl mb-2">🎭</div>
              <p className="text-white font-fredoka font-semibold">Fun Role-Play!</p>
            </div>
          </div>
          
          {/* Lesson Navigation */}
          <div className="flex gap-3 justify-center flex-wrap">
            <Button
              onClick={() => navigate("/")}
              variant="outline"
              size="default"
              className="text-lg font-bold font-fredoka border-white/30 text-white hover:bg-white/20 bg-white/10"
            >
              ← Lesson 1.1
            </Button>
            <Button
              onClick={startLesson}
              size="default"
              className="text-lg font-bold font-fredoka bg-white text-success hover:bg-white/90 shadow-lg"
            >
              🚀 Start Lesson 1.2!
            </Button>
            <Button
              onClick={() => navigate("/lesson3-intro")}
              variant="outline"
              size="default"
              className="text-lg font-bold font-fredoka border-white/30 text-white hover:bg-white/20 bg-white/10"
            >
              Lesson 1.3 →
            </Button>
          </div>
        </div>

        {/* Ready Message */}
        <p className="text-lg text-muted-foreground font-fredoka">
          Ready to learn polite words? Let's go! 🌟
        </p>
      </div>
    </div>
  );
};

export default Lesson2Intro;