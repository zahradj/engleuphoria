import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";

export const Lesson31Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
      <FloatingLogo />
      
      <div className="max-w-4xl mx-auto text-center space-y-8">
        
        {/* Animated Header */}
        <div className="space-y-6">
          <div className="flex justify-center">
            <div className="relative">
              <div className="text-8xl animate-bounce-gentle">🎲</div>
              <div className="absolute -top-2 -right-2 text-2xl animate-pulse-fun">⚽</div>
              <div className="absolute -bottom-1 -left-3 text-xl animate-bounce-gentle" style={{animationDelay: '0.5s'}}>🚗</div>
              <div className="absolute top-4 -left-4 text-lg animate-pulse-fun" style={{animationDelay: '1s'}}>🔢</div>
            </div>
          </div>
          
          <h1 className="text-5xl font-bold font-fredoka rainbow-text">
            Lesson 3.1
          </h1>
          <h2 className="text-4xl font-bold font-fredoka text-primary">
            Numbers 1-3 & Toys! 🎲⚽🚗
          </h2>
          <p className="text-xl text-muted-foreground font-fredoka">
            Unit 3 - Lesson 1 • 21 Fun Slides • 25-30 minutes
          </p>
        </div>

        {/* Lesson Preview */}
        <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl border-2 border-primary/30 shadow-glow">
          <h3 className="text-2xl font-bold font-fredoka text-center text-primary mb-6">
            🎯 Today's Adventure: Numbers & Toys Explorer!
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* What We'll Learn */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-success mb-4">🔢 What We'll Learn:</h4>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold">1</div>
                  <span className="text-foreground font-semibold">Number One (1)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">2</div>
                  <span className="text-foreground font-semibold">Number Two (2)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold">3</div>
                  <span className="text-foreground font-semibold">Number Three (3)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-primary rounded-full"></div>
                  <span className="text-foreground font-semibold">Toys: Ball & Car</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-accent rounded-full"></div>
                  <span className="text-foreground font-semibold">Phonics: Letter E</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-warning rounded-full"></div>
                  <span className="text-foreground font-semibold">Sentences: "One ball" / "I have ___"</span>
                </div>
              </div>
            </div>

            {/* Fun Activities */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-warning mb-4">🎮 Fun Games & Activities:</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🔢</span>
                  <span className="text-foreground">Count & Click Game</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎯</span>
                  <span className="text-foreground">Drag & Drop Numbers</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">⚽</span>
                  <span className="text-foreground">Bouncing Ball Flashcards</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🚗</span>
                  <span className="text-foreground">Racing Car Games</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🛒</span>
                  <span className="text-foreground">Toy Shop Role-Play</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎪</span>
                  <span className="text-foreground">Spin & Count Wheel</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Learning Goals */}
        <div className="bg-gradient-to-r from-success/20 to-primary/20 p-6 rounded-2xl border border-success/30">
          <h3 className="text-xl font-bold text-center mb-4 font-fredoka">🎯 Learning Goals</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="bg-white/80 p-4 rounded-xl">
              <div className="text-2xl mb-2">🔢</div>
              <p className="font-semibold text-sm">Count 1, 2, 3</p>
            </div>
            <div className="bg-white/80 p-4 rounded-xl">
              <div className="text-2xl mb-2">🎲</div>
              <p className="font-semibold text-sm">Learn Toy Words</p>
            </div>
            <div className="bg-white/80 p-4 rounded-xl">
              <div className="text-2xl mb-2">🗣️</div>
              <p className="font-semibold text-sm">Say Number Sentences</p>
            </div>
          </div>
        </div>

        {/* Unit Progress */}
        <div className="bg-gradient-warm p-6 rounded-2xl text-white">
          <h3 className="text-xl font-bold text-center mb-4 font-fredoka">📚 Unit 3: Numbers & Counting</h3>
          <div className="flex justify-center items-center gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/30 rounded-full flex items-center justify-center font-bold text-lg">3.1</div>
              <p className="text-sm mt-1">Current</p>
            </div>
            <div className="text-2xl">→</div>
            <div className="text-center opacity-60">
              <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center font-bold text-lg">3.2</div>
              <p className="text-sm mt-1">Next</p>
            </div>
            <div className="text-2xl opacity-60">→</div>
            <div className="text-center opacity-60">
              <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center font-bold text-lg">3.3</div>
              <p className="text-sm mt-1">Soon</p>
            </div>
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="space-y-4">
          <div className="flex gap-4 justify-center flex-wrap">
            <Button
              onClick={() => navigate("/lesson31")}
              size="fun"
              variant="kid"
              className="text-2xl font-bold font-fredoka shadow-glow hover:shadow-fun transform hover:scale-110 transition-all duration-300"
            >
              🚀 Start Counting! 🔢
            </Button>
            <Button
              onClick={() => navigate("/")}
              variant="outline"
              size="fun"
              className="text-xl font-bold font-fredoka border-primary text-primary hover:bg-primary/10"
            >
              ← Back to Program
            </Button>
          </div>
          <p className="text-sm text-muted-foreground font-fredoka">
            Ready to explore numbers and toys?
          </p>
        </div>
      </div>
    </div>
  );
};