import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FloatingLogo } from "@/components/FloatingLogo";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { DragDropActivity } from "@/components/DragDropActivity";
import { PhonicsActivity } from "@/components/PhonicsActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";

const totalSlides = 20;

export default function Lesson63() {
  const [currentSlide, setCurrentSlide] = useState(1);
  const navigate = useNavigate();

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-4xl font-bold text-white mb-4">👨‍👩‍👧‍👦 Family Review</h2>
            <p className="text-xl text-white/90">Let's review all our family members!</p>
            <div className="text-6xl">👨‍👩‍👧‍👦</div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Start Review! →
            </Button>
          </div>
        );

      case 2:
        return (
          <PhonicsActivity
            letter="M"
            words={[
              { word: "mom", image: "mom", hasLetter: true },
              { word: "milk", image: "milk", hasLetter: true },
              { word: "cat", image: "cat", hasLetter: false }
            ]}
            onComplete={nextSlide}
          />
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">👨‍👩‍👧‍👦 Family Members Review</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👩</div>
                <p className="text-white">Mother</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👨</div>
                <p className="text-white">Father</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👦</div>
                <p className="text-white">Brother</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👧</div>
                <p className="text-white">Sister</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👶</div>
                <p className="text-white">Baby</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👨‍👩‍👧‍👦</div>
                <p className="text-white">Family</p>
              </Card>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🔊 Family Pronunciation</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-w-2xl mx-auto">
              <AudioButton text="Mother" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Father" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Brother" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Sister" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Baby" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Family" className="bg-white/20 hover:bg-white/30 text-white" />
            </div>
            <p className="text-lg text-white/90">Click and repeat each word!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 5:
        return (
          <DragDropActivity
            title="Complete Family Tree"
            items={[
              { id: '1', content: 'Mother', type: 'source', matchId: '5' },
              { id: '2', content: 'Father', type: 'source', matchId: '6' },
              { id: '3', content: 'Brother', type: 'source', matchId: '7' },
              { id: '4', content: 'Sister', type: 'source', matchId: '8' },
              { id: '5', content: '👩', type: 'target' },
              { id: '6', content: '👨', type: 'target' },
              { id: '7', content: '👦', type: 'target' },
              { id: '8', content: '👧', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🌳 Build Your Family Tree</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-lg mx-auto">
              <div className="space-y-6">
                <div>
                  <p className="text-white/60 mb-2">Parents</p>
                  <div className="flex justify-center gap-8">
                    <div className="text-center">
                      <div className="text-4xl mb-1">👨</div>
                      <p className="text-white text-sm">Father</p>
                    </div>
                    <div className="text-center">
                      <div className="text-4xl mb-1">👩</div>
                      <p className="text-white text-sm">Mother</p>
                    </div>
                  </div>
                </div>
                <div className="h-px bg-white/30"></div>
                <div>
                  <p className="text-white/60 mb-2">Children</p>
                  <div className="flex justify-center gap-4">
                    <div className="text-center">
                      <div className="text-3xl mb-1">👦</div>
                      <p className="text-white text-sm">Brother</p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl mb-1">👧</div>
                      <p className="text-white text-sm">Sister</p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl mb-1">👶</div>
                      <p className="text-white text-sm">Baby</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 7:
        return (
          <SpeakingActivity
            prompt="Introduce your family! Say: 'This is my family'"
            expectedResponse="This is my family"
            onComplete={nextSlide}
          />
        );

      case 8:
        return (
          <SpeakingActivity
            prompt="Point to each family member and say their names"
            expectedResponse="Mother, Father, Brother, Sister, Baby"
            onComplete={nextSlide}
          />
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎮 Family Memory Game</h2>
            <p className="text-lg text-white/90">I will show a family member for 2 seconds. Remember who it is!</p>
            <div className="text-8xl mb-4">👩</div>
            <p className="text-white/80">Who was that?</p>
            <div className="space-y-2">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white block mx-auto">
                Mother ✓
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white block mx-auto">
                Sister
              </Button>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎮 Family Quiz</h2>
            <p className="text-lg text-white/90">Who is the youngest in the family?</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">👨</div>
                <div className="text-sm">Father</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">👦</div>
                <div className="text-sm">Brother</div>
              </Button>
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white p-4">
                <div className="text-3xl mb-1">👶</div>
                <div className="text-sm">Baby ✓</div>
              </Button>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Family Role-Play 1</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white">"This is my mother!"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🧑‍🏫</span>
                  <span className="text-white">"Very good! What about your father?"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white">"This is my father!"</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Your Turn! →
            </Button>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Your Family Role-Play</h2>
            <div className="space-y-4">
              <div className="text-6xl">👨‍👩‍👧‍👦</div>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
                <p className="text-white">Teacher: "Tell me about your family!"</p>
              </Card>
              <p className="text-white/80">Now you answer! Use: "This is my..." for each family member</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Great Job! →
            </Button>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Family Conversation</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🧑‍🏫</span>
                  <span className="text-white">"How many people in your family?"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white">"Five! Mother, father, brother, sister, and baby!"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🧑‍🏫</span>
                  <span className="text-white">"Wonderful! I love your family!"</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">💖 Family Love</h2>
            <p className="text-lg text-white/90">Families are special! Let's say why we love our family!</p>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-3xl mb-2">🤗</div>
                <p className="text-white text-sm">Hugs</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-3xl mb-2">❤️</div>
                <p className="text-white text-sm">Love</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-3xl mb-2">🎈</div>
                <p className="text-white text-sm">Fun</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-3xl mb-2">🍽️</div>
                <p className="text-white text-sm">Meals</p>
              </Card>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🏆 Family Champion Quiz</h2>
            <p className="text-lg text-white/90">Final challenge! Complete the sentence:</p>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <p className="text-white text-xl">"This is my ___"</p>
              <div className="text-6xl my-4">👨</div>
            </Card>
            <div className="space-y-2">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white block mx-auto">
                Father ✓
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white block mx-auto">
                Mother
              </Button>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📖 Family Story Time</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-3 text-white">
                <p>"Once upon a time, there was a happy family."</p>
                <p>"The mother was kind. The father was strong."</p>
                <p>"The brother and sister played together."</p>
                <p>"The baby laughed and smiled."</p>
                <p>"They loved each other very much!"</p>
                <div className="text-3xl mt-4">👨‍👩‍👧‍👦❤️</div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Beautiful Story! →
            </Button>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🏠 Homework</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4 text-white">
                <p className="font-semibold">For next time:</p>
                <ul className="text-left space-y-2">
                  <li>• Draw your complete family</li>
                  <li>• Practice family introductions</li>
                  <li>• Count how many people in your family</li>
                  <li>• Tell someone about your family</li>
                </ul>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Unit Complete! →
            </Button>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎊 Unit 6 Complete!</h2>
            <div className="text-6xl mb-4">🏆</div>
            <p className="text-xl text-white/90">You mastered the Family unit!</p>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-md mx-auto">
              <p className="text-white font-semibold mb-2">Unit 6 Summary:</p>
              <p className="text-white/80">✓ Parents: Mother, Father</p>
              <p className="text-white/80">✓ Siblings: Brother, Sister, Baby</p>
              <p className="text-white/80">✓ Grammar: "This is my..."</p>
              <p className="text-white/80">✓ Family conversations</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Get Unit Badge! →
            </Button>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🌟 Perfect Score!</h2>
            <div className="text-6xl mb-4">⭐⭐⭐</div>
            <p className="text-xl text-white/90">You are a Family Expert!</p>
            <Card className="p-6 bg-gradient-success max-w-md mx-auto">
              <div className="text-white space-y-2">
                <h3 className="text-xl font-bold">🏅 Achievement Unlocked!</h3>
                <p className="font-semibold">Family Master Badge</p>
                <p className="text-sm">Completed all family lessons with excellence!</p>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue to Next Unit →
            </Button>
          </div>
        );

      case 20:
        return (
          <BadgeReward
            title="Unit 6 Master!"
            description="You completed the entire Family unit!"
            badgeName="Family Master Badge"
            onContinue={() => navigate('/lesson/7-1-intro')}
          />
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <ProgressBar current={currentSlide} total={totalSlides} />
          
          <Card className="p-8 bg-white/10 backdrop-blur-sm border-white/20 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </Card>
          
          <div className="mt-6 flex justify-between">
            <Button 
              onClick={() => navigate('/lesson/6-3-intro')}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/10"
            >
              ← Back to Intro
            </Button>
            
            <div className="text-white/60">
              Slide {currentSlide} of {totalSlides}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}