import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";
import { AudioButton } from "@/components/AudioButton";

export default function Lesson73Intro() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              🛒 Lesson 7.3
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-white/90 mb-2">
              Food Review & Shopping Game
            </h2>
            <p className="text-lg text-white/80">
              Review all foods and play shopping games!
            </p>
          </div>

          {/* Lesson Overview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              📚 What We'll Review Today
            </h3>
            <div className="grid md:grid-cols-2 gap-4 text-white/90">
              <div>
                <h4 className="font-semibold mb-2">🍎 All Foods:</h4>
                <ul className="space-y-1">
                  <li>• Fruits: Apple, Banana</li>
                  <li>• Meals: Milk, Bread, Rice</li>
                  <li>• Food sentences</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">🎮 Activities:</h4>
                <ul className="space-y-1">
                  <li>• Food Shopping Game</li>
                  <li>• Restaurant Role-Play</li>
                  <li>• Phonics: Pp /p/ (pizza, pie)</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Activities Preview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">🎮 Fun Activities</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl mb-2">🍎🥛🍞</div>
                <p className="text-white/90">Food Memory Game</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🏪</div>
                <p className="text-white/90">Grocery Store Game</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🏆</div>
                <p className="text-white/90">Food Master Quiz</p>
              </div>
            </div>
          </Card>

          {/* Audio Practice */}
          <div className="text-center mb-8">
            <h3 className="text-xl font-bold text-white mb-4">🔊 Food Words Review</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <AudioButton text="Apple" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Banana" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Milk" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Bread" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Rice" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Food" className="bg-white/20 hover:bg-white/30 text-white" />
            </div>
          </div>

          {/* Start Button */}
          <div className="text-center">
            <Button 
              onClick={() => navigate('/lesson/7-3')}
              className="bg-gradient-primary hover:shadow-button transition-all duration-300 text-lg font-semibold px-8 py-4"
            >
              Start Food Review! 🛒
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}