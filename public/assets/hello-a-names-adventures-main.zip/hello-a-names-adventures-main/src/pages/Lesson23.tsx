import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";

export const Lesson23 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [showFeedback, setShowFeedback] = useState(false);
  const [bingoCard, setBingoCard] = useState<boolean[]>(new Array(6).fill(false));
  const [spinResult, setSpinResult] = useState<string>("");
  const [isSpinning, setIsSpinning] = useState(false);
  const [memoryCards, setMemoryCards] = useState<{id: number, color: string, isFlipped: boolean, isMatched: boolean}[]>([]);
  const [drawnColors, setDrawnColors] = useState<string[]>([]);

  const totalSlides = 20;
  const colors = [
    { name: "red", emoji: "🔴", class: "bg-red-500" },
    { name: "blue", emoji: "🔵", class: "bg-blue-500" },
    { name: "yellow", emoji: "🟡", class: "bg-yellow-500" },
    { name: "green", emoji: "🟢", class: "bg-green-500" },
    { name: "black", emoji: "⚫", class: "bg-gray-800" },
    { name: "white", emoji: "⚪", class: "bg-white border" }
  ];

  const phonicsLetters = [
    { letter: "A", word: "Apple", color: "red", emoji: "🍎" },
    { letter: "B", word: "Ball", color: "blue", emoji: "🔵" },
    { letter: "C", word: "Cat", color: "black", emoji: "🐱" },
    { letter: "D", word: "Duck", color: "yellow", emoji: "🦆" }
  ];

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
      setShowFeedback(false);
      setSelectedColors([]);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
      setShowFeedback(false);
      setSelectedColors([]);
    }
  };

  const handleColorSelect = (color: string) => {
    if (selectedColors.includes(color)) {
      setSelectedColors(selectedColors.filter(c => c !== color));
    } else {
      setSelectedColors([...selectedColors, color]);
    }
  };

  const handleBingoClick = (index: number) => {
    const newBingoCard = [...bingoCard];
    newBingoCard[index] = true;
    setBingoCard(newBingoCard);
  };

  const spinWheel = () => {
    setIsSpinning(true);
    setTimeout(() => {
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      setSpinResult(randomColor.name);
      setIsSpinning(false);
    }, 2000);
  };

  const initializeMemoryGame = () => {
    const shuffledColors = [...colors, ...colors]
      .sort(() => Math.random() - 0.5)
      .slice(0, 8)
      .map((color, index) => ({
        id: index,
        color: color.name,
        isFlipped: false,
        isMatched: false
      }));
    setMemoryCards(shuffledColors);
  };

  const handleMemoryCardClick = (id: number) => {
    const newCards = memoryCards.map(card => {
      if (card.id === id && !card.isFlipped && !card.isMatched) {
        return { ...card, isFlipped: true };
      }
      return card;
    });
    setMemoryCards(newCards);

    const flippedCards = newCards.filter(card => card.isFlipped && !card.isMatched);
    if (flippedCards.length === 2) {
      if (flippedCards[0].color === flippedCards[1].color) {
        setTimeout(() => {
          setMemoryCards(prev => prev.map(card => 
            flippedCards.some(fc => fc.id === card.id) 
              ? { ...card, isMatched: true, isFlipped: false }
              : card
          ));
        }, 1000);
      } else {
        setTimeout(() => {
          setMemoryCards(prev => prev.map(card => 
            flippedCards.some(fc => fc.id === card.id)
              ? { ...card, isFlipped: false }
              : card
          ));
        }, 1000);
      }
    }
  };

  const handleRainbowDraw = (color: string) => {
    if (!drawnColors.includes(color)) {
      setDrawnColors([...drawnColors, color]);
    }
  };

  const renderSlideContent = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-8xl animate-bounce mb-4">🌈</div>
            <h1 className="text-4xl font-bold text-white mb-4">Rainbow Review!</h1>
            <p className="text-xl text-white/90">Let's review all six colors together!</p>
            <div className="flex justify-center gap-2 mt-6">
              {colors.map((color, index) => (
                <div
                  key={color.name}
                  className={`w-8 h-8 ${color.class} rounded-full animate-pulse`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                />
              ))}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Quick Flash Review</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {colors.map((color) => (
                <Card
                  key={color.name}
                  className="p-6 cursor-pointer hover:scale-105 transition-transform bg-white/10 backdrop-blur-sm border-white/20"
                  onClick={() => handleColorSelect(color.name)}
                >
                  <div className="text-center space-y-2">
                    <div className="text-4xl">{color.emoji}</div>
                    <p className="text-white font-bold text-lg capitalize">{color.name}</p>
                    <AudioButton
                      text={color.name}
                      className="text-white hover:bg-white/20"
                    />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Phonics Warm-Up</h2>
            <p className="text-xl text-white/90 mb-6">Clap along with the chant!</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {phonicsLetters.map((letter) => (
                <Card
                  key={letter.letter}
                  className="p-6 bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-colors cursor-pointer"
                >
                  <div className="text-center space-y-2">
                    <div className="text-4xl font-bold text-white">{letter.letter}</div>
                    <div className="text-3xl">{letter.emoji}</div>
                    <p className="text-white font-semibold">{letter.word}</p>
                    <p className="text-white/80 text-sm capitalize">{letter.color}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Color Tap Game</h2>
            <p className="text-xl text-white/90 mb-6">Tap each color to hear its name!</p>
            <div className="relative mx-auto w-64 h-32">
              <svg viewBox="0 0 200 100" className="w-full h-full">
                {colors.map((color, index) => {
                  const angle = (index * 30) - 75;
                  const x = 100 + 80 * Math.cos(angle * Math.PI / 180);
                  const y = 90 + 40 * Math.sin(angle * Math.PI / 180);
                  return (
                    <circle
                      key={color.name}
                      cx={x}
                      cy={y}
                      r="12"
                      fill={color.name === 'white' ? '#ffffff' : color.name === 'black' ? '#000000' : color.name}
                      stroke={color.name === 'white' ? '#666' : 'none'}
                      strokeWidth="2"
                      className="cursor-pointer hover:scale-110 transition-transform"
                      onClick={() => handleColorSelect(color.name)}
                    />
                  );
                })}
              </svg>
            </div>
            {selectedColors.length > 0 && (
              <div className="mt-6">
                <AudioButton
                  text={selectedColors[selectedColors.length - 1]}
                  className="text-white hover:bg-white/20"
                />
              </div>
            )}
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Drag & Drop Match</h2>
            <p className="text-xl text-white/90 mb-6">Match the words to the objects!</p>
            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white">Words</h3>
                {colors.slice(0, 3).map((color) => (
                  <div
                    key={color.name}
                    className="p-3 bg-white/10 border border-white/20 rounded-lg cursor-move hover:bg-white/20 transition-colors"
                    draggable
                  >
                    <span className="text-white font-semibold capitalize">{color.name}</span>
                  </div>
                ))}
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white">Objects</h3>
                <div className="space-y-4">
                  <div className="p-4 border-2 border-dashed border-white/30 rounded-lg min-h-[60px] flex items-center justify-center">
                    <span className="text-4xl">🍎</span>
                  </div>
                  <div className="p-4 border-2 border-dashed border-white/30 rounded-lg min-h-[60px] flex items-center justify-center">
                    <span className="text-4xl">🔵</span>
                  </div>
                  <div className="p-4 border-2 border-dashed border-white/30 rounded-lg min-h-[60px] flex items-center justify-center">
                    <span className="text-4xl">🌻</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Model Sentence Practice</h2>
            <div className="space-y-8">
              <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="flex items-center justify-center gap-4">
                  <span className="text-4xl">🍎</span>
                  <span className="text-2xl font-bold text-white">"It is red."</span>
                  <AudioButton
                    text="It is red"
                    className="text-white hover:bg-white/20"
                  />
                </div>
              </Card>
              <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="flex items-center justify-center gap-4">
                  <span className="text-4xl">🌿</span>
                  <span className="text-2xl font-bold text-white">"It is green."</span>
                  <AudioButton
                    text="It is green"
                    className="text-white hover:bg-white/20"
                  />
                </div>
              </Card>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Speaking Drill</h2>
            <p className="text-xl text-white/90 mb-6">Say the full sentence for each object!</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { emoji: "🌞", answer: "It is yellow" },
                { emoji: "🐱", answer: "It is black" },
                { emoji: "❄️", answer: "It is white" },
                { emoji: "🔵", answer: "It is blue" },
                { emoji: "🍎", answer: "It is red" },
                { emoji: "🌿", answer: "It is green" }
              ].map((item, index) => (
                <Card
                  key={index}
                  className="p-6 cursor-pointer hover:scale-105 transition-transform bg-white/10 backdrop-blur-sm border-white/20"
                >
                  <div className="text-center space-y-3">
                    <div className="text-5xl">{item.emoji}</div>
                    <AudioButton
                      text={item.answer}
                      className="text-white hover:bg-white/20"
                    />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Sentence Builder</h2>
            <p className="text-xl text-white/90 mb-6">Drag words to make: "This is yellow."</p>
            <div className="flex justify-center items-center gap-4 mb-8">
              <span className="text-5xl">🌞</span>
            </div>
            <div className="space-y-6">
              <div className="flex justify-center gap-4">
                {["This", "is", "yellow", "."].map((word, index) => (
                  <div
                    key={index}
                    className="p-3 bg-white/10 border border-white/20 rounded-lg cursor-move hover:bg-white/20 transition-colors"
                    draggable
                  >
                    <span className="text-white font-semibold">{word}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-center gap-2">
                {[1, 2, 3, 4].map((slot) => (
                  <div
                    key={slot}
                    className="w-20 h-12 border-2 border-dashed border-white/30 rounded-lg flex items-center justify-center"
                  >
                    <span className="text-white/50 text-sm">{slot}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Spin & Speak Wheel</h2>
            <p className="text-xl text-white/90 mb-6">Spin the wheel and say "It is ___!"</p>
            <div className="relative mx-auto w-48 h-48">
              <div className={`w-full h-full rounded-full border-8 border-white flex items-center justify-center transition-transform duration-2000 ${isSpinning ? 'animate-spin' : ''}`}>
                {spinResult ? (
                  <div className="text-center">
                    <div className="text-4xl mb-2">{colors.find(c => c.name === spinResult)?.emoji}</div>
                    <p className="text-white font-bold text-lg capitalize">{spinResult}</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-1 w-32 h-32">
                    {colors.slice(0, 4).map((color, index) => (
                      <div
                        key={index}
                        className={`${color.class} flex items-center justify-center text-white font-bold text-xs`}
                      >
                        {color.name.slice(0, 1).toUpperCase()}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <Button
              onClick={spinWheel}
              disabled={isSpinning}
              className="bg-white text-primary hover:bg-white/90"
            >
              {isSpinning ? "Spinning..." : "🎲 Spin the Wheel!"}
            </Button>
            {spinResult && (
              <div className="mt-4">
                <AudioButton
                  text={`It is ${spinResult}`}
                  className="text-white hover:bg-white/20"
                />
              </div>
            )}
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Rainbow Bingo</h2>
            <p className="text-xl text-white/90 mb-6">Click the colors I call out!</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              {colors.map((color, index) => (
                <Card
                  key={index}
                  className={`p-6 cursor-pointer transition-all ${
                    bingoCard[index] 
                      ? 'bg-success scale-110 shadow-glow' 
                      : 'bg-white/10 backdrop-blur-sm border-white/20 hover:scale-105'
                  }`}
                  onClick={() => handleBingoClick(index)}
                >
                  <div className="text-center space-y-2">
                    <div className="text-3xl">{color.emoji}</div>
                    <p className={`font-bold text-sm capitalize ${bingoCard[index] ? 'text-white' : 'text-white'}`}>
                      {color.name}
                    </p>
                  </div>
                </Card>
              ))}
            </div>
            {bingoCard.filter(Boolean).length === 6 && (
              <div className="text-center space-y-4">
                <div className="text-6xl animate-bounce">🎉</div>
                <p className="text-2xl font-bold text-white">BINGO! Well done!</p>
              </div>
            )}
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Guess the Color</h2>
            <p className="text-xl text-white/90 mb-6">What color is this object?</p>
            <div className="grid grid-cols-2 gap-8">
              {[
                { emoji: "🍎", options: ["red", "green", "yellow"], correct: "red" },
                { emoji: "🌿", options: ["blue", "green", "white"], correct: "green" }
              ].map((quiz, index) => (
                <Card key={index} className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
                  <div className="text-center space-y-4">
                    <div className="text-6xl">{quiz.emoji}</div>
                    <div className="space-y-2">
                      {quiz.options.map((option) => (
                        <Button
                          key={option}
                          onClick={() => handleColorSelect(option)}
                          className={`w-full ${
                            selectedColors.includes(option)
                              ? option === quiz.correct
                                ? 'bg-success text-white'
                                : 'bg-destructive text-white'
                              : 'bg-white/20 text-white hover:bg-white/30'
                          }`}
                        >
                          {option}
                        </Button>
                      ))}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Memory Flip Game</h2>
            <p className="text-xl text-white/90 mb-6">Match pairs of color cards!</p>
            {memoryCards.length === 0 && (
              <Button
                onClick={initializeMemoryGame}
                className="bg-white text-primary hover:bg-white/90"
              >
                Start Memory Game
              </Button>
            )}
            {memoryCards.length > 0 && (
              <div className="grid grid-cols-4 gap-4 max-w-md mx-auto">
                {memoryCards.map((card) => (
                  <Card
                    key={card.id}
                    className={`aspect-square cursor-pointer transition-all ${
                      card.isFlipped || card.isMatched
                        ? 'bg-white text-primary'
                        : 'bg-white/10 backdrop-blur-sm border-white/20 hover:scale-105'
                    }`}
                    onClick={() => handleMemoryCardClick(card.id)}
                  >
                    <div className="h-full flex items-center justify-center">
                      {card.isFlipped || card.isMatched ? (
                        <span className="text-xl capitalize font-bold">{card.color}</span>
                      ) : (
                        <span className="text-2xl">?</span>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Rainbow Drawing</h2>
            <p className="text-xl text-white/90 mb-6">Fill in the missing colors!</p>
            <div className="space-y-4">
              <div className="flex justify-center gap-2">
                {colors.map((color, index) => (
                  <div
                    key={index}
                    className={`w-12 h-24 border-2 border-white/30 rounded cursor-pointer transition-all ${
                      drawnColors.includes(color.name)
                        ? `${color.class} scale-110`
                        : 'bg-white/10 hover:bg-white/20'
                    }`}
                    onClick={() => handleRainbowDraw(color.name)}
                  />
                ))}
              </div>
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                {colors.map((color) => (
                  <Button
                    key={color.name}
                    onClick={() => handleRainbowDraw(color.name)}
                    className={`${
                      drawnColors.includes(color.name)
                        ? 'bg-success text-white'
                        : 'bg-white/20 text-white hover:bg-white/30'
                    }`}
                  >
                    {color.emoji} {color.name}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Mini Comic 1</h2>
            <div className="max-w-2xl mx-auto">
              <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-white/20 rounded-full mx-auto flex items-center justify-center">
                      <span className="text-2xl">👦</span>
                    </div>
                    <p className="text-white font-bold">Tom</p>
                    <div className="bg-white/20 p-4 rounded-lg">
                      <p className="text-white">"My bag is blue."</p>
                      <div className="text-3xl mt-2">🎒</div>
                    </div>
                  </div>
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-white/20 rounded-full mx-auto flex items-center justify-center">
                      <span className="text-2xl">👧</span>
                    </div>
                    <p className="text-white font-bold">Anna</p>
                    <div className="bg-white/20 p-4 rounded-lg">
                      <p className="text-white">"My apple is red."</p>
                      <div className="text-3xl mt-2">🍎</div>
                    </div>
                  </div>
                </div>
              </Card>
              <div className="mt-6 space-y-2">
                <AudioButton
                  text="My bag is blue"
                  className="text-white hover:bg-white/20 mr-4"
                />
                <AudioButton
                  text="My apple is red"
                  className="text-white hover:bg-white/20"
                />
              </div>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Mini Comic 2</h2>
            <div className="max-w-2xl mx-auto">
              <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-white/20 rounded-full mx-auto flex items-center justify-center">
                      <span className="text-2xl">👦</span>
                    </div>
                    <p className="text-white font-bold">Leo</p>
                    <div className="bg-white/20 p-4 rounded-lg">
                      <p className="text-white">"The sun is yellow."</p>
                      <div className="text-3xl mt-2">🌞</div>
                    </div>
                  </div>
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-white/20 rounded-full mx-auto flex items-center justify-center">
                      <span className="text-2xl">👧</span>
                    </div>
                    <p className="text-white font-bold">Sara</p>
                    <div className="bg-white/20 p-4 rounded-lg">
                      <p className="text-white">"The leaf is green."</p>
                      <div className="text-3xl mt-2">🌿</div>
                    </div>
                  </div>
                </div>
              </Card>
              <div className="mt-6 space-y-2">
                <AudioButton
                  text="The sun is yellow"
                  className="text-white hover:bg-white/20 mr-4"
                />
                <AudioButton
                  text="The leaf is green"
                  className="text-white hover:bg-white/20"
                />
              </div>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Mini Comic 3</h2>
            <div className="max-w-2xl mx-auto">
              <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-white/20 rounded-full mx-auto flex items-center justify-center">
                      <span className="text-2xl">👦</span>
                    </div>
                    <p className="text-white font-bold">Ben</p>
                    <div className="bg-white/20 p-4 rounded-lg">
                      <p className="text-white">"The cat is black."</p>
                      <div className="text-3xl mt-2">🐱</div>
                    </div>
                  </div>
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-white/20 rounded-full mx-auto flex items-center justify-center">
                      <span className="text-2xl">👧</span>
                    </div>
                    <p className="text-white font-bold">Mia</p>
                    <div className="bg-white/20 p-4 rounded-lg">
                      <p className="text-white">"The snow is white."</p>
                      <div className="text-3xl mt-2">❄️</div>
                    </div>
                  </div>
                </div>
              </Card>
              <div className="mt-6 space-y-2">
                <AudioButton
                  text="The cat is black"
                  className="text-white hover:bg-white/20 mr-4"
                />
                <AudioButton
                  text="The snow is white"
                  className="text-white hover:bg-white/20"
                />
              </div>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Role-Play Practice</h2>
            <p className="text-xl text-white/90 mb-6">Practice with the teacher!</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { question: "What color is the apple?", answer: "It is red", emoji: "🍎" },
                { question: "What color is the sun?", answer: "It is yellow", emoji: "🌞" },
                { question: "What color is the leaf?", answer: "It is green", emoji: "🌿" },
                { question: "What color is the cat?", answer: "It is black", emoji: "🐱" },
                { question: "What color is the snow?", answer: "It is white", emoji: "❄️" },
                { question: "What color is the sky?", answer: "It is blue", emoji: "🔵" }
              ].map((rolePlay, index) => (
                <Card
                  key={index}
                  className="p-4 bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-colors cursor-pointer"
                >
                  <div className="text-center space-y-3">
                    <div className="text-4xl">{rolePlay.emoji}</div>
                    <p className="text-white text-sm font-semibold">"{rolePlay.question}"</p>
                    <AudioButton
                      text={rolePlay.answer}
                      className="text-white hover:bg-white/20 text-xs"
                    />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Quick Quiz</h2>
            <p className="text-xl text-white/90 mb-6">Which one is white? Which one is red?</p>
            <div className="space-y-8">
              <div className="space-y-4">
                <p className="text-xl text-white font-semibold">Which one is white?</p>
                <div className="flex justify-center gap-4">
                  {["❄️", "🌞", "🍎"].map((emoji, index) => (
                    <Button
                      key={index}
                      onClick={() => handleColorSelect(emoji)}
                      className={`text-4xl p-6 ${
                        selectedColors.includes(emoji)
                          ? emoji === "❄️"
                            ? 'bg-success text-white'
                            : 'bg-destructive text-white'
                          : 'bg-white/20 hover:bg-white/30'
                      }`}
                    >
                      {emoji}
                    </Button>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <p className="text-xl text-white font-semibold">Which one is red?</p>
                <div className="flex justify-center gap-4">
                  {["🌿", "🍎", "🔵"].map((emoji, index) => (
                    <Button
                      key={index}
                      onClick={() => handleColorSelect(emoji)}
                      className={`text-4xl p-6 ${
                        selectedColors.includes(emoji)
                          ? emoji === "🍎"
                            ? 'bg-success text-white'
                            : 'bg-destructive text-white'
                          : 'bg-white/20 hover:bg-white/30'
                      }`}
                    >
                      {emoji}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-6">Phonics Chant Recap</h2>
            <p className="text-xl text-white/90 mb-6">A-B-C-D with colors!</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { letter: "A", word: "Apple", color: "red", emoji: "🍎" },
                { letter: "B", word: "Ball", color: "blue", emoji: "🔵" },
                { letter: "C", word: "Cat", color: "black", emoji: "🐱" },
                { letter: "D", word: "Duck", color: "yellow", emoji: "🦆" }
              ].map((item) => (
                <Card
                  key={item.letter}
                  className="p-6 bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-colors cursor-pointer"
                >
                  <div className="text-center space-y-3">
                    <div className="text-3xl font-bold text-white">{item.letter}</div>
                    <div className="text-4xl">{item.emoji}</div>
                    <p className="text-white font-semibold">{item.word}</p>
                    <Badge className={`bg-${item.color}-500/20 text-white border-${item.color}-500/30`}>
                      {item.color}
                    </Badge>
                    <AudioButton
                      text={`${item.letter} for ${item.word} ${item.color}`}
                      className="text-white hover:bg-white/20"
                    />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 20:
        return (
          <BadgeReward
            title="Congratulations!"
            description="You completed the Rainbow Review!"
            badgeName="Rainbow Champion"
            onContinue={() => navigate("/program")}
          />
        );

      default:
        return null;
    }
  };

  if (currentSlide === 20) {
    return (
      <div className="min-h-screen bg-gradient-warm flex items-center justify-center p-4 relative">
        <FloatingLogo />
        {renderSlideContent()}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-warm flex flex-col relative">
      <FloatingLogo />
      
      {/* Progress Bar */}
      <div className="p-4">
        <ProgressBar current={currentSlide} total={totalSlides} />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          {renderSlideContent()}
        </div>
      </div>

      {/* Navigation */}
      <div className="p-4 flex justify-between items-center">
        <Button
          onClick={prevSlide}
          disabled={currentSlide === 1}
          variant="outline"
          className="text-white border-white/30 hover:bg-white/10 disabled:opacity-50"
        >
          ← Previous
        </Button>

        <div className="text-white font-semibold">
          {currentSlide} / {totalSlides}
        </div>

        <Button
          onClick={nextSlide}
          disabled={currentSlide === totalSlides}
          className="bg-white text-primary hover:bg-white/90 disabled:opacity-50"
        >
          Next →
        </Button>
      </div>
    </div>
  );
};