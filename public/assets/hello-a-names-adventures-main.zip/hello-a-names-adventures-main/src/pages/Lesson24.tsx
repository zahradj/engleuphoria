import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";
import { PhonicsActivity } from "@/components/PhonicsActivity";
import { DragDropActivity } from "@/components/DragDropActivity";
import { FillInTheGapActivity } from "@/components/FillInTheGapActivity";
import { MissingLetterActivity } from "@/components/MissingLetterActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";

const totalSlides = 20;

const Lesson24 = () => {
  const [currentSlide, setCurrentSlide] = useState(1);
  const [showBadgeReward, setShowBadgeReward] = useState(false);
  const navigate = useNavigate();

  const colors = ["red", "blue", "yellow", "green", "black", "white"];
  const colorEmojis = ["🔴", "🔵", "🟡", "🟢", "⚫", "⚪"];
  
  const [bingoBoard, setBingoBoard] = useState([
    ["red", "blue", "yellow"],
    ["green", "black", "white"],
    ["red", "blue", "green"]
  ]);
  const [bingoClicked, setBingoClicked] = useState(new Set());
  const [spinResult, setSpinResult] = useState("");
  const [memoryCards, setMemoryCards] = useState([...colors, ...colors].sort(() => Math.random() - 0.5));
  const [flippedCards, setFlippedCards] = useState(new Set<number>());
  const [matchedPairs, setMatchedPairs] = useState(new Set<number>());

  const nextSlide = () => {
    if (currentSlide >= totalSlides) {
      setShowBadgeReward(true);
    } else {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const handleBingoClick = (row: number, col: number) => {
    const key = `${row}-${col}`;
    setBingoClicked(prev => new Set([...prev, key]));
  };

  const handleSpin = () => {
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    setSpinResult(randomColor);
  };

  const handleCardFlip = (index: number) => {
    if (flippedCards.size === 2) return;
    setFlippedCards(prev => new Set([...prev, index]));
    
    if (flippedCards.size === 1) {
      const firstCardIndex = Array.from(flippedCards)[0];
      if (firstCardIndex !== undefined && memoryCards[firstCardIndex] === memoryCards[index]) {
        setMatchedPairs(prev => new Set([...prev, firstCardIndex, index]));
      }
      setTimeout(() => setFlippedCards(new Set()), 1000);
    }
  };

  if (showBadgeReward) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
        <BadgeReward
          title="Rainbow Champion!"
          description="You've mastered all the colors and games! Amazing work!"
          badgeName="Color Master Champion 🌈"
          onContinue={() => navigate("/")}
        />
      </div>
    );
  }

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-8">
            <div className="text-8xl animate-bounce-gentle">🌈</div>
            <h1 className="text-5xl font-bold font-fredoka rainbow-text">
              Color Review & Games!
            </h1>
            <p className="text-2xl font-fredoka text-primary">
              Welcome to our Rainbow Adventure! 🎮
            </p>
            <div className="flex justify-center gap-4 flex-wrap">
              {colors.map((color, index) => (
                <div
                  key={color}
                  className={`w-16 h-16 rounded-full animate-bounce-gentle cursor-pointer hover:scale-110 transition-all`}
                  style={{ 
                    backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                    border: color === 'white' ? '2px solid #ccc' : 'none',
                    animationDelay: `${index * 0.2}s`
                  }}
                >
                  <span className="text-2xl">{colorEmojis[index]}</span>
                </div>
              ))}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎈 Balloon Pop Review!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Tap each balloon to hear the color name!
            </p>
            <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              {colors.map((color, index) => (
                <div key={color} className="text-center space-y-2">
                  <div
                    className={`w-20 h-20 rounded-full mx-auto cursor-pointer hover:scale-110 transition-all shadow-lg`}
                    style={{ 
                      backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                      border: color === 'white' ? '2px solid #ccc' : 'none'
                    }}
                  >
                    <AudioButton 
                      text={color}
                      className="w-full h-full rounded-full bg-transparent border-none text-white text-2xl hover:bg-white/20"
                    />
                  </div>
                  <p className="font-bold text-lg capitalize">{color}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎵 Phonics Chant Time!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Let's chant A-B-C-D with clapping!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {['A', 'B', 'C', 'D'].map((letter, index) => (
                <Card key={letter} className="p-6 text-center">
                  <div className="text-4xl font-bold text-primary mb-2">{letter}{letter.toLowerCase()}</div>
                  <p className="text-lg font-semibold">{['Apple', 'Ball', 'Cat', 'Duck'][index]}</p>
                  <AudioButton text={letter} className="mt-2" />
                </Card>
              ))}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎯 Color Flashcard Tap Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Tap each flashcard to hear the color!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {colors.map((color, index) => (
                <Card key={color} className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105">
                  <div className="text-center space-y-4">
                    <div
                      className="w-24 h-24 rounded-lg mx-auto"
                      style={{ 
                        backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                        border: color === 'white' ? '2px solid #ccc' : 'none'
                      }}
                    />
                    <AudioButton text={color} className="text-lg font-bold capitalize" />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 5:
        return (
          <DragDropActivity
            title="🎨 Match Colors to Objects!"
            items={[
              { id: 'red', content: 'red', type: 'source', matchId: 'red-apple' },
              { id: 'blue', content: 'blue', type: 'source', matchId: 'blue-sky' },
              { id: 'yellow', content: 'yellow', type: 'source', matchId: 'yellow-sun' },
              { id: 'green', content: 'green', type: 'source', matchId: 'green-grass' },
              { id: 'black', content: 'black', type: 'source', matchId: 'black-cat' },
              { id: 'white', content: 'white', type: 'source', matchId: 'white-snow' },
              { id: 'red-apple', content: '🍎 Apple', type: 'target' },
              { id: 'blue-sky', content: '☁️ Sky', type: 'target' },
              { id: 'yellow-sun', content: '☀️ Sun', type: 'target' },
              { id: 'green-grass', content: '🌱 Grass', type: 'target' },
              { id: 'black-cat', content: '🐱 Cat', type: 'target' },
              { id: 'white-snow', content: '❄️ Snow', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 6:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              ❓ Quick Quiz 1: Which is Yellow?
            </h2>
            <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              {['red', 'yellow', 'blue'].map(color => (
                <Card key={color} className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105">
                  <div
                    className="w-20 h-20 rounded-lg mx-auto mb-4"
                    style={{ 
                      backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                      border: color === 'white' ? '2px solid #ccc' : 'none'
                    }}
                  />
                  <Button className="w-full capitalize">{color}</Button>
                </Card>
              ))}
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              ❓ Quick Quiz 2: Which is Black?
            </h2>
            <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              {['white', 'black', 'green'].map(color => (
                <Card key={color} className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105">
                  <div
                    className="w-20 h-20 rounded-lg mx-auto mb-4"
                    style={{ 
                      backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                      border: color === 'white' ? '2px solid #ccc' : 'none'
                    }}
                  />
                  <Button className="w-full capitalize">{color}</Button>
                </Card>
              ))}
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🗣️ Speaking Drill Time!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher shows items, you say: "It is ___"
            </p>
            <div className="grid grid-cols-2 gap-6 max-w-2xl mx-auto">
              {[
                { emoji: "🍎", response: "It is red" },
                { emoji: "☀️", response: "It is yellow" },
                { emoji: "🌱", response: "It is green" },
                { emoji: "❄️", response: "It is white" }
              ].map((item, index) => (
                <Card key={index} className="p-6">
                  <div className="space-y-4">
                    <div className="text-6xl">{item.emoji}</div>
                    <SpeakingActivity 
                      prompt={`Say: "${item.response}"`}
                      expectedResponse={item.response}
                      onComplete={nextSlide}
                    />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎪 Spin & Speak Wheel!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Spin the wheel, then say: "It is ___"
            </p>
            <div className="space-y-6">
              <div className="relative mx-auto w-64 h-64">
                <div className="w-full h-full rounded-full border-8 border-primary shadow-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <div className="text-6xl animate-spin-slow">🎯</div>
                </div>
              </div>
              <Button onClick={handleSpin} size="fun" variant="kid">
                🎪 Spin the Wheel!
              </Button>
              {spinResult && (
                <Card className="p-6 max-w-md mx-auto">
                  <h3 className="text-2xl font-bold mb-4">Result:</h3>
                  <div
                    className="w-16 h-16 rounded-full mx-auto mb-4"
                    style={{ 
                      backgroundColor: spinResult === 'black' ? '#000' : spinResult === 'white' ? '#fff' : spinResult,
                      border: spinResult === 'white' ? '2px solid #ccc' : 'none'
                    }}
                  />
                  <p className="text-xl font-bold">Now say: "It is {spinResult}"</p>
                </Card>
              )}
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎯 Rainbow Bingo Board!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher calls a color → Click the correct square!
            </p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              {bingoBoard.map((row, rowIndex) =>
                row.map((color, colIndex) => (
                  <div
                    key={`${rowIndex}-${colIndex}`}
                    className={`w-20 h-20 rounded-lg cursor-pointer transition-all hover:scale-105 ${
                      bingoClicked.has(`${rowIndex}-${colIndex}`) ? 'ring-4 ring-success' : ''
                    }`}
                    style={{ 
                      backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                      border: color === 'white' ? '2px solid #ccc' : 'none'
                    }}
                    onClick={() => handleBingoClick(rowIndex, colIndex)}
                  />
                ))
              )}
            </div>
            <p className="text-lg font-fredoka">
              Clicked: {bingoClicked.size}/9 squares
            </p>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🔍 Guess the Hidden Color!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              What color is hidden behind the question mark?
            </p>
            <div className="space-y-6">
              <div className="text-9xl">❓</div>
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                {colors.map(color => (
                  <Button key={color} variant="outline" className="capitalize">
                    {color}
                  </Button>
                ))}
              </div>
              <Card className="p-4 max-w-md mx-auto bg-gradient-warm">
                <p className="text-white font-bold">Hint: It's the color of grass! 🌱</p>
              </Card>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🧩 Memory Flip Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Find the matching color pairs!
            </p>
            <div className="grid grid-cols-4 gap-3 max-w-lg mx-auto">
              {memoryCards.map((color, index) => (
                <div
                  key={index}
                  className="w-16 h-16 rounded-lg cursor-pointer transition-all hover:scale-105"
                  onClick={() => handleCardFlip(index)}
                >
                  {flippedCards.has(index) || matchedPairs.has(index) ? (
                    <div
                      className="w-full h-full rounded-lg"
                      style={{ 
                        backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                        border: color === 'white' ? '2px solid #ccc' : 'none'
                      }}
                    />
                  ) : (
                    <div className="w-full h-full rounded-lg bg-primary flex items-center justify-center text-white font-bold">
                      ?
                    </div>
                  )}
                </div>
              ))}
            </div>
            <p className="text-lg font-fredoka">
              Pairs found: {matchedPairs.size / 2}/6
            </p>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎨 Color Hunt Scene!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Click on all the colorful objects in the picture!
            </p>
            <div className="relative bg-sky-200 p-8 rounded-3xl max-w-2xl mx-auto">
              <div className="space-y-4">
                <div className="flex justify-center items-end space-x-4">
                  <div className="cursor-pointer hover:scale-110 transition-all">
                    🍎 <span className="text-xs block">Red Apple</span>
                  </div>
                  <div className="cursor-pointer hover:scale-110 transition-all">
                    🌳 <span className="text-xs block">Green Tree</span>
                  </div>
                  <div className="cursor-pointer hover:scale-110 transition-all">
                    🏠 <span className="text-xs block">White House</span>
                  </div>
                </div>
                <div className="flex justify-center space-x-8">
                  <div className="cursor-pointer hover:scale-110 transition-all">
                    ☀️ <span className="text-xs block">Yellow Sun</span>
                  </div>
                  <div className="cursor-pointer hover:scale-110 transition-all">
                    🐱 <span className="text-xs block">Black Cat</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="cursor-pointer hover:scale-110 transition-all inline-block">
                    🌊 <span className="text-xs block">Blue Water</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎭 Mini Comic 1
            </h2>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="text-6xl">👦</div>
                  <div className="speech-bubble bg-primary text-white p-4 rounded-2xl">
                    <p className="text-xl font-bold">"My bag is blue!"</p>
                  </div>
                </div>
                <div className="text-center">
                  <div className="w-20 h-20 bg-blue-500 rounded-lg mx-auto mb-4"></div>
                  <p className="text-lg font-fredoka">Tom's blue bag 👜</p>
                </div>
                <Button size="fun" variant="kid">
                  🗣️ Now you say: "My bag is blue!"
                </Button>
              </div>
            </Card>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎭 Mini Comic 2
            </h2>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="text-6xl">👧</div>
                  <div className="speech-bubble bg-warning text-white p-4 rounded-2xl">
                    <p className="text-xl font-bold">"The sun is yellow!"</p>
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-8xl">☀️</div>
                  <p className="text-lg font-fredoka">Anna points to the yellow sun</p>
                </div>
                <Button size="fun" variant="kid">
                  🗣️ Now you say: "The sun is yellow!"
                </Button>
              </div>
            </Card>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎭 Mini Comic 3
            </h2>
            <Card className="p-8 max-w-2xl mx-auto">
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="text-6xl">👦</div>
                  <div className="speech-bubble bg-accent text-white p-4 rounded-2xl">
                    <p className="text-xl font-bold">"The snow is white!"</p>
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-8xl">❄️</div>
                  <p className="text-lg font-fredoka">Ben looks at the white snow</p>
                </div>
                <Button size="fun" variant="kid">
                  🗣️ Now you say: "The snow is white!"
                </Button>
              </div>
            </Card>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎮 Role-Play Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher asks: "What color is the ___?" → You answer!
            </p>
            <div className="grid grid-cols-2 gap-6 max-w-2xl mx-auto">
              {[
                { emoji: '🍎', question: 'What color is the apple?', answer: 'It is red' },
                { emoji: '🌱', question: 'What color is the grass?', answer: 'It is green' },
                { emoji: '☀️', question: 'What color is the sun?', answer: 'It is yellow' },
                { emoji: '❄️', question: 'What color is the snow?', answer: 'It is white' }
              ].map((item, index) => (
                <Card key={index} className="p-6">
                  <div className="space-y-4">
                    <div className="text-6xl">{item.emoji}</div>
                    <p className="font-bold text-lg">"{item.question}"</p>
                    <Button variant="outline">
                      🗣️ {item.answer}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Review Quiz Time!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Mix of all colors - Choose the correct answer!
            </p>
            <div className="space-y-6">
              <Card className="p-6 max-w-md mx-auto">
                <h3 className="text-xl font-bold mb-4">Question: What color is this? 🍌</h3>
                <div className="grid grid-cols-3 gap-3">
                  {['red', 'yellow', 'green'].map(color => (
                    <Button key={color} variant="outline" className="capitalize">
                      {color}
                    </Button>
                  ))}
                </div>
              </Card>
              <Card className="p-6 max-w-md mx-auto">
                <h3 className="text-xl font-bold mb-4">Question: What color is this? 🌊</h3>
                <div className="grid grid-cols-3 gap-3">
                  {['blue', 'white', 'black'].map(color => (
                    <Button key={color} variant="outline" className="capitalize">
                      {color}
                    </Button>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎵 Final Phonics Recap!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              A-B-C-D chant with rhythm - one last time!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[
                { letter: 'A', word: 'Apple red' },
                { letter: 'B', word: 'Ball blue' },
                { letter: 'C', word: 'Cat black' },
                { letter: 'D', word: 'Duck yellow' }
              ].map((item) => (
                <Card key={item.letter} className="p-6 text-center">
                  <div className="text-4xl font-bold text-primary mb-2">{item.letter}{item.letter.toLowerCase()}</div>
                  <p className="text-lg font-semibold">{item.word}</p>
                  <AudioButton text={item.letter} className="mt-2" />
                </Card>
              ))}
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-8">
            <div className="text-8xl animate-bounce">🏅</div>
            <h2 className="text-5xl font-bold font-fredoka rainbow-text">
              Congratulations!
            </h2>
            <h3 className="text-3xl font-bold font-fredoka text-primary">
              Rainbow Champion Badge Earned! 🌈
            </h3>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-primary/20 to-accent/20">
              <div className="space-y-4">
                <div className="text-6xl">🏆</div>
                <h4 className="text-2xl font-bold">You are now a Color Master!</h4>
                <p className="text-lg">
                  You've completed all the color games and activities! 
                  Amazing work learning all six colors and practicing your sentences!
                </p>
                <div className="flex justify-center gap-2 flex-wrap">
                  {colors.map((color, index) => (
                    <div
                      key={color}
                      className="w-8 h-8 rounded-full"
                      style={{ 
                        backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                        border: color === 'white' ? '2px solid #ccc' : 'none'
                      }}
                    />
                  ))}
                </div>
              </div>
            </Card>
            <div className="text-6xl animate-pulse">✨🎉✨</div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 p-4">
      <FloatingLogo />
      
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Lesson 2.4 • Color Review & Games
          </Badge>
          <ProgressBar current={currentSlide} total={totalSlides} />
        </div>

        {/* Slide Content */}
        <Card className="p-8 mb-8 min-h-[500px] flex items-center justify-center">
          {renderSlide()}
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button
            onClick={prevSlide}
            disabled={currentSlide === 1}
            variant="outline"
            size="lg"
          >
            ← Previous
          </Button>
          
          <span className="text-lg font-semibold">
            {currentSlide} / {totalSlides}
          </span>
          
          <Button
            onClick={nextSlide}
            size="lg"
            className="bg-gradient-primary hover:shadow-button"
          >
            {currentSlide === totalSlides ? "Finish! 🏅" : "Next →"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Lesson24;