import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap, Trophy } from "lucide-react";

export const Lesson45Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 4 • Lesson 5 • Final Assessment
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🏃‍♂️ Body Actions & Final Test!
          </h1>
          <p className="text-xl text-muted-foreground">
            Learn body actions and complete Unit 4 assessment
          </p>
        </div>

        {/* Actions Preview Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🏃‍♂️</div>
              <h3 className="font-bold">Run</h3>
              <p className="text-sm text-muted-foreground">I can run</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🚶‍♂️</div>
              <h3 className="font-bold">Walk</h3>
              <p className="text-sm text-muted-foreground">I can walk</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🤸‍♂️</div>
              <h3 className="font-bold">Jump</h3>
              <p className="text-sm text-muted-foreground">I can jump</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-success/20 hover:border-success/40 transition-colors bg-gradient-success/10">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🏆</div>
              <h3 className="font-bold text-success">Unit Test</h3>
              <p className="text-sm text-muted-foreground">Final Assessment</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Learn & Assess */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-warning" />
                What We'll Learn & Assess
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Body actions: run, walk, jump, dance</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Sentences: "I can run/walk/jump/dance"</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Complete Unit 4 body parts review</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Final assessment of all vocabulary</span>
              </div>
            </CardContent>
          </Card>

          {/* Assessment Activities */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Assessment Activities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Action Simon Says Challenge</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Complete body parts test</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Sentence building assessment</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Speaking fluency check</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Phonics A-I comprehensive review</span>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Assessment Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">30–35 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">22 assessment slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Focus:</span>
                <span className="font-medium">Unit 4 completion</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Unit 4 Master Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Complete Unit 4 Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Complete Unit 4 Vocabulary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">All Body Parts (10):</h4>
                <div className="grid grid-cols-2 gap-1 text-sm">
                  <span>🧠 Head</span>
                  <span>👀 Eyes</span>
                  <span>👃 Nose</span>
                  <span>👄 Mouth</span>
                  <span>👋 Hands</span>
                  <span>🦶 Feet</span>
                  <span>💪 Arms</span>
                  <span>🦵 Legs</span>
                  <span>👆 Fingers</span>
                  <span>🦶 Toes</span>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">New Actions:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>🏃‍♂️ Run</span>
                    <AudioButton text="run" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🚶‍♂️ Walk</span>
                    <AudioButton text="walk" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🤸‍♂️ Jump</span>
                    <AudioButton text="jump" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Assessment Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              Assessment & Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Comprehensive Assessment:</strong> This lesson evaluates all Unit 4 learning including body parts vocabulary, sentence structures, and phonics A-I.
              </p>
              <p>
                <strong>Action Learning:</strong> Students learn body actions (run, walk, jump) with "I can..." sentence patterns while being physically active.
              </p>
              <p>
                <strong>Progress Evaluation:</strong> Use this lesson to assess student readiness for Unit 5. Note areas needing additional practice.
              </p>
              <p>
                <strong>Celebration Focus:</strong> Emphasize student achievements throughout Unit 4 and build confidence for future learning.
              </p>
              <p>
                <strong>Next Steps:</strong> Upon successful completion, students are ready for Unit 5 topics (family, animals, etc.).
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson45")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Start Final Assessment!
          </Button>
        </div>
      </div>
    </div>
  );
};