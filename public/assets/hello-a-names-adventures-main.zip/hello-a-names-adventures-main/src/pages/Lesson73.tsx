import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FloatingLogo } from "@/components/FloatingLogo";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { DragDropActivity } from "@/components/DragDropActivity";
import { PhonicsActivity } from "@/components/PhonicsActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";

const totalSlides = 20;

export default function Lesson73() {
  const [currentSlide, setCurrentSlide] = useState(1);
  const navigate = useNavigate();

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-4xl font-bold text-white mb-4">🛒 Food Review & Shopping Game</h2>
            <p className="text-xl text-white/90">Let's review all our foods and go shopping!</p>
            <div className="text-6xl">🍎🥛🍞🍌🍚</div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Start Shopping! →
            </Button>
          </div>
        );

      case 2:
        return (
          <PhonicsActivity
            letter="P"
            words={[
              { word: "pizza", image: "pizza", hasLetter: true },
              { word: "pie", image: "pie", hasLetter: true },
              { word: "cat", image: "cat", hasLetter: false }
            ]}
            onComplete={nextSlide}
          />
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🍎🍌 All Foods Review</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍎</div>
                <p className="text-white">Apple</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍌</div>
                <p className="text-white">Banana</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🥛</div>
                <p className="text-white">Milk</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍞</div>
                <p className="text-white">Bread</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍚</div>
                <p className="text-white">Rice</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍽️</div>
                <p className="text-white">Food</p>
              </Card>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🔊 Food Pronunciation</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-w-2xl mx-auto">
              <AudioButton text="Apple" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Banana" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Milk" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Bread" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Rice" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Food" className="bg-white/20 hover:bg-white/30 text-white" />
            </div>
            <p className="text-lg text-white/90">Click and repeat each word!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 5:
        return (
          <DragDropActivity
            title="Sort Foods: Fruits vs Meals"
            items={[
              { id: '1', content: 'Apple', type: 'source', matchId: '6' },
              { id: '2', content: 'Banana', type: 'source', matchId: '6' },
              { id: '3', content: 'Milk', type: 'source', matchId: '7' },
              { id: '4', content: 'Bread', type: 'source', matchId: '7' },
              { id: '5', content: 'Rice', type: 'source', matchId: '7' },
              { id: '6', content: '🍎 Fruits', type: 'target' },
              { id: '7', content: '🍽️ Meals', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 6:
        return (
          <SpeakingActivity
            prompt="Tell me all the foods you know!"
            expectedResponse="Apple, Banana, Milk, Bread, Rice"
            onComplete={nextSlide}
          />
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🏪 Welcome to the Grocery Store!</h2>
            <p className="text-lg text-white/90">Let's go shopping for food!</p>
            <div className="text-6xl mb-4">🏪</div>
            <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <p className="text-white">👨‍💼 Shopkeeper: "Welcome! What would you like to buy?"</p>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Start Shopping →
            </Button>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🛒 Shopping Game: Choose Fruits</h2>
            <p className="text-lg text-white/90">What fruits do you want to buy?</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white p-4">
                <div className="text-3xl mb-1">🍎</div>
                <div className="text-sm">Apple</div>
              </Button>
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white p-4">
                <div className="text-3xl mb-1">🍌</div>
                <div className="text-sm">Banana</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">🚗</div>
                <div className="text-sm">Car</div>
              </Button>
            </div>
            <p className="text-white/80">Choose the fruits!</p>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🛒 Shopping Game: Choose Drinks</h2>
            <p className="text-lg text-white/90">What do you want to drink?</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white p-4">
                <div className="text-3xl mb-1">🥛</div>
                <div className="text-sm">Milk</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">🍞</div>
                <div className="text-sm">Bread</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">📚</div>
                <div className="text-sm">Book</div>
              </Button>
            </div>
            <p className="text-white/80">Choose what you drink!</p>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">💰 Paying at the Store</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👨‍💼</span>
                  <span className="text-white">"That's apple, banana, and milk!"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white">"Thank you!"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👨‍💼</span>
                  <span className="text-white">"Come again soon!"</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎮 Food Memory Game</h2>
            <p className="text-lg text-white/90">I will show you foods for 3 seconds. Remember them!</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="text-4xl">🍎</div>
              <div className="text-4xl">🥛</div>
              <div className="text-4xl">🍞</div>
            </div>
            <p className="text-white/80">What did you see?</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Tell Me! →
            </Button>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🧠 Memory Challenge</h2>
            <p className="text-lg text-white/90">Which foods did you see?</p>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white p-4">
                <div>🍎🥛🍞</div>
                <div className="text-sm">Apple, Milk, Bread ✓</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div>🍌🍚🐱</div>
                <div className="text-sm">Banana, Rice, Cat</div>
              </Button>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Restaurant Role-Play</h2>
            <p className="text-lg text-white/90">You are the customer, I am the waiter!</p>
            <div className="space-y-4">
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
                <p className="text-white">👨‍🍳 Waiter: "What would you like to eat and drink?"</p>
              </Card>
              <p className="text-white/80">Your turn! Say: "I want..." and choose foods</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Great Order! →
            </Button>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🏆 Food Master Quiz</h2>
            <p className="text-lg text-white/90">Final challenge! Which sentence is correct?</p>
            <div className="space-y-2">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white block mx-auto px-8 py-3">
                "I drink milk." ✓
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white block mx-auto px-8 py-3">
                "I eat milk."
              </Button>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎵 Food Song</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-2 text-white">
                <p>🎵 "Apple, apple, red and sweet"</p>
                <p>"Banana, banana, good to eat"</p>
                <p>"Milk to drink, bread to eat"</p>
                <p>"Rice and food make meals complete!" 🎵</p>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Sing Along! →
            </Button>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📊 Food Survey</h2>
            <p className="text-lg text-white/90">What is your favorite food from this unit?</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-w-lg mx-auto">
              <Button className="bg-white/20 hover:bg-white/30 text-white p-3">
                <div className="text-2xl mb-1">🍎</div>
                <div className="text-sm">Apple</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-3">
                <div className="text-2xl mb-1">🍌</div>
                <div className="text-sm">Banana</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-3">
                <div className="text-2xl mb-1">🥛</div>
                <div className="text-sm">Milk</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-3">
                <div className="text-2xl mb-1">🍞</div>
                <div className="text-sm">Bread</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-3">
                <div className="text-2xl mb-1">🍚</div>
                <div className="text-sm">Rice</div>
              </Button>
              <Button onClick={nextSlide} className="bg-gradient-primary text-white p-3 col-span-2 md:col-span-1">
                <div className="text-2xl mb-1">❤️</div>
                <div className="text-sm">All of them!</div>
              </Button>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🏠 Homework</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4 text-white">
                <p className="font-semibold">For next time:</p>
                <ul className="text-left space-y-2">
                  <li>• Make a food shopping list</li>
                  <li>• Practice food sentences with family</li>
                  <li>• Draw your favorite meal</li>
                  <li>• Count all the food words you know</li>
                </ul>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Unit Complete! →
            </Button>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎊 Unit 7 Complete!</h2>
            <div className="text-6xl mb-4">🏆</div>
            <p className="text-xl text-white/90">You mastered the Food Fun unit!</p>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-md mx-auto">
              <p className="text-white font-semibold mb-2">Unit 7 Summary:</p>
              <p className="text-white/80">✓ Fruits: Apple, Banana</p>
              <p className="text-white/80">✓ Meals: Milk, Bread, Rice</p>
              <p className="text-white/80">✓ Grammar: "I eat..." "I drink..."</p>
              <p className="text-white/80">✓ Shopping & Restaurant skills</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Get Unit Badge! →
            </Button>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🌟 Perfect Score!</h2>
            <div className="text-6xl mb-4">⭐⭐⭐</div>
            <p className="text-xl text-white/90">You are a Food Expert!</p>
            <Card className="p-6 bg-gradient-success max-w-md mx-auto">
              <div className="text-white space-y-2">
                <h3 className="text-xl font-bold">🏅 Achievement Unlocked!</h3>
                <p className="font-semibold">Food Master Badge</p>
                <p className="text-sm">Completed all food lessons with excellence!</p>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue to Next Unit →
            </Button>
          </div>
        );

      case 20:
        return (
          <BadgeReward
            title="Unit 7 Master!"
            description="You completed the entire Food Fun unit!"
            badgeName="Food Master Badge"
            onContinue={() => navigate('/lesson/8-1-intro')}
          />
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <ProgressBar current={currentSlide} total={totalSlides} />
          
          <Card className="p-8 bg-white/10 backdrop-blur-sm border-white/20 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </Card>
          
          <div className="mt-6 flex justify-between">
            <Button 
              onClick={() => navigate('/lesson/7-3-intro')}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/10"
            >
              ← Back to Intro
            </Button>
            
            <div className="text-white/60">
              Slide {currentSlide} of {totalSlides}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}