import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson44 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 20;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🦾</div>
            <h1 className="text-4xl font-bold text-primary">More Body Parts!</h1>
            <p className="text-xl text-muted-foreground">Let's learn about arms, legs, fingers, and toes!</p>
            <div className="flex justify-center space-x-4">
              <div className="text-4xl">💪</div>
              <div className="text-4xl">🦵</div>
              <div className="text-4xl">👆</div>
              <div className="text-4xl">🦶</div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Let's Review!</h2>
            <p className="text-lg text-muted-foreground">First, let's remember what we learned</p>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <div className="text-4xl">🧠</div>
                <span>Head</span>
              </div>
              <div className="space-y-2">
                <div className="text-4xl">👀</div>
                <span>Eyes</span>
              </div>
              <div className="space-y-2">
                <div className="text-4xl">👃</div>
                <span>Nose</span>
              </div>
              <div className="space-y-2">
                <div className="text-4xl">👄</div>
                <span>Mouth</span>
              </div>
              <div className="space-y-2">
                <div className="text-4xl">👋</div>
                <span>Hands</span>
              </div>
              <div className="space-y-2">
                <div className="text-4xl">🦶</div>
                <span>Feet</span>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Time</h2>
            <div className="text-6xl mb-4">🎵</div>
            <div className="bg-primary/10 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">New Letter: Ii</h3>
              <div className="text-4xl mb-2">🏠</div>
              <p className="text-xl">/i/ like Igloo, Ink, Insect</p>
              <AudioButton text="I, igloo, ink, insect" className="mt-4" />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Body Part</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">💪</div>
              <h3 className="text-3xl font-bold text-primary">Arms</h3>
              <p className="text-lg text-muted-foreground">Move your arms!</p>
              <AudioButton text="arms" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Body Part</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🦵</div>
              <h3 className="text-3xl font-bold text-primary">Legs</h3>
              <p className="text-lg text-muted-foreground">Kick your legs!</p>
              <AudioButton text="legs" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Body Part</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">👆</div>
              <h3 className="text-3xl font-bold text-primary">Fingers</h3>
              <p className="text-lg text-muted-foreground">Wiggle your fingers!</p>
              <AudioButton text="fingers" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">New Body Part</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🦶</div>
              <h3 className="text-3xl font-bold text-primary">Toes</h3>
              <p className="text-lg text-muted-foreground">Wiggle your toes!</p>
              <AudioButton text="toes" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Count Your Fingers!</h2>
            <p className="text-lg text-muted-foreground">Let's count from 1 to 10!</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="grid grid-cols-5 gap-2 text-2xl mb-4">
                <div>👆1</div>
                <div>✌️2</div>
                <div>🤟3</div>
                <div>🖖4</div>
                <div>🖐️5</div>
                <div>👆6</div>
                <div>✌️7</div>
                <div>🤟8</div>
                <div>🖖9</div>
                <div>🙌10</div>
              </div>
              <p className="text-lg">Show me your fingers and count!</p>
              <AudioButton text="One, two, three, four, five, six, seven, eight, nine, ten fingers" className="mt-4" />
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">💪</div>
              <h3 className="text-2xl font-bold text-primary">These are my arms.</h3>
              <AudioButton text="These are my arms" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🦵</div>
              <h3 className="text-2xl font-bold text-primary">These are my legs.</h3>
              <AudioButton text="These are my legs" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">👆</div>
              <h3 className="text-2xl font-bold text-primary">These are my fingers.</h3>
              <AudioButton text="These are my fingers" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🦶</div>
              <h3 className="text-2xl font-bold text-primary">These are my toes.</h3>
              <AudioButton text="These are my toes" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Body Parts Matching</h2>
            <p className="text-lg text-muted-foreground">Match the new body parts!</p>
            <DragDropActivity
              title="Match the Body Parts"
              items={[
                { id: "arms", content: "arms", type: "source", matchId: "arms-target" },
                { id: "legs", content: "legs", type: "source", matchId: "legs-target" },
                { id: "fingers", content: "fingers", type: "source", matchId: "fingers-target" },
                { id: "toes", content: "toes", type: "source", matchId: "toes-target" },
                { id: "arms-target", content: "💪", type: "target" },
                { id: "legs-target", content: "🦵", type: "target" },
                { id: "fingers-target", content: "👆", type: "target" },
                { id: "toes-target", content: "🦶", type: "target" }
              ]}
              onComplete={() => console.log("Body parts matched!")}
            />
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Move Your Body Dance!</h2>
            <div className="text-6xl mb-4">💃</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Follow the Dance!</h3>
              <div className="space-y-3">
                <Button size="lg" variant="outline" className="w-full">
                  "Wave your arms!" 💪
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  "Kick your legs!" 🦵
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  "Wiggle your fingers!" 👆
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  "Wiggle your toes!" 🦶
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Do the action and say the body part!
              </p>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Complete Body Review</h2>
            <p className="text-lg text-muted-foreground">Now you know 10 body parts!</p>
            <div className="grid grid-cols-5 gap-3">
              <div className="space-y-1">
                <div className="text-3xl">🧠</div>
                <span className="text-sm">Head</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">👀</div>
                <span className="text-sm">Eyes</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">👃</div>
                <span className="text-sm">Nose</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">👄</div>
                <span className="text-sm">Mouth</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">👋</div>
                <span className="text-sm">Hands</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">🦶</div>
                <span className="text-sm">Feet</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">💪</div>
                <span className="text-sm">Arms</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">🦵</div>
                <span className="text-sm">Legs</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">👆</div>
                <span className="text-sm">Fingers</span>
              </div>
              <div className="space-y-1">
                <div className="text-3xl">🦶</div>
                <span className="text-sm">Toes</span>
              </div>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Speaking Challenge</h2>
            <SpeakingActivity
              prompt="Look at the body part and say the sentence"
              expectedResponse="These are my arms"
              onComplete={() => console.log("Speaking completed!")}
            />
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Memory Game</h2>
            <p className="text-lg text-muted-foreground">Which body part is missing?</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="grid grid-cols-5 gap-3 mb-4">
                <div className="text-3xl">🧠</div>
                <div className="text-3xl">👀</div>
                <div className="text-3xl">👃</div>
                <div className="text-3xl">❓</div>
                <div className="text-3xl">👋</div>
              </div>
              <div className="grid grid-cols-4 gap-4">
                <Button variant="outline">Arms</Button>
                <Button variant="outline" className="bg-success/20">Mouth ✓</Button>
                <Button variant="outline">Legs</Button>
                <Button variant="outline">Toes</Button>
              </div>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Body Quiz</h2>
            <p className="text-lg text-muted-foreground">Test your knowledge!</p>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">Question: Which are your legs?</p>
                <div className="grid grid-cols-4 gap-4 max-w-lg mx-auto">
                  <Button variant="outline" size="lg" className="text-3xl">💪</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🦵 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">👆</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🦶</Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Complete Body Puzzle</h2>
            <p className="text-lg text-muted-foreground">Put all body parts together!</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="relative mx-auto w-48 h-72 bg-primary/5 rounded-lg border-2 border-dashed border-primary/30">
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 text-2xl">🧠</div>
                <div className="absolute top-10 left-1/2 transform -translate-x-1/2 text-xl">👀</div>
                <div className="absolute top-14 left-1/2 transform -translate-x-1/2 text-lg">👃</div>
                <div className="absolute top-18 left-1/2 transform -translate-x-1/2 text-lg">👄</div>
                <div className="absolute top-24 left-2 text-xl">💪</div>
                <div className="absolute top-24 right-2 text-xl">💪</div>
                <div className="absolute top-32 left-1/2 transform -translate-x-1/2 text-xl">👋</div>
                <div className="absolute top-40 left-8 text-2xl">🦵</div>
                <div className="absolute top-40 right-8 text-2xl">🦵</div>
                <div className="absolute bottom-8 left-8 text-xl">🦶</div>
                <div className="absolute bottom-8 right-8 text-xl">🦶</div>
                <div className="absolute top-28 left-6 text-sm">👆</div>
                <div className="absolute bottom-4 left-10 text-sm">🦶</div>
              </div>
              <p className="text-success font-semibold mt-4">Amazing! Complete body!</p>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🏆</div>
            <h2 className="text-3xl font-bold text-primary">Fantastic Work!</h2>
            <p className="text-xl">You learned 4 new body parts!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Body Expert Badge Earned!</h3>
              <p className="text-muted-foreground">You know 10 body parts now!</p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <span className="text-2xl">💪</span>
              <span className="text-2xl">🦵</span>
              <span className="text-2xl">👆</span>
              <span className="text-2xl">🦶</span>
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Body Expert Badge"
        description="You learned arms, legs, fingers, and toes!"
        badgeName="Body Expert"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson44-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 4.4 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson44;