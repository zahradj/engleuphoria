import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FloatingLogo } from "@/components/FloatingLogo";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { DragDropActivity } from "@/components/DragDropActivity";
import { PhonicsActivity } from "@/components/PhonicsActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";

const totalSlides = 19;

export default function Lesson62() {
  const [currentSlide, setCurrentSlide] = useState(1);
  const navigate = useNavigate();

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-4xl font-bold text-white mb-4">👦👧👶 My Family: Siblings</h2>
            <p className="text-xl text-white/90">Let's learn about Brother, Sister, and Baby!</p>
            <div className="text-6xl">👦👧👶</div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Let's Start! →
            </Button>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📚 Quick Review</h2>
            <p className="text-lg text-white/90">Let's review parents from Lesson 6.1!</p>
            <div className="flex justify-center gap-4">
              <AudioButton text="Mother" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Father" className="bg-white/20 hover:bg-white/30 text-white" />
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 3:
        return (
          <PhonicsActivity
            letter="L"
            words={[
              { word: "lion", image: "lion", hasLetter: true },
              { word: "leaf", image: "leaf", hasLetter: true },
              { word: "cat", image: "cat", hasLetter: false }
            ]}
            onComplete={nextSlide}
          />
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">👦 Brother</h2>
            <div className="text-8xl mb-4">👦</div>
            <AudioButton text="Brother" className="bg-white/20 hover:bg-white/30 text-white text-xl px-8 py-4" />
            <p className="text-lg text-white/90">This is Brother!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Next →
            </Button>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">👧 Sister</h2>
            <div className="text-8xl mb-4">👧</div>
            <AudioButton text="Sister" className="bg-white/20 hover:bg-white/30 text-white text-xl px-8 py-4" />
            <p className="text-lg text-white/90">This is Sister!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Next →
            </Button>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">👶 Baby</h2>
            <div className="text-8xl mb-4">👶</div>
            <AudioButton text="Baby" className="bg-white/20 hover:bg-white/30 text-white text-xl px-8 py-4" />
            <p className="text-lg text-white/90">This is Baby!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Next →
            </Button>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🔊 Listen & Repeat</h2>
            <div className="space-y-4">
              <div className="flex justify-center gap-4 flex-wrap">
                <AudioButton text="Brother" className="bg-white/20 hover:bg-white/30 text-white" />
                <AudioButton text="Sister" className="bg-white/20 hover:bg-white/30 text-white" />
                <AudioButton text="Baby" className="bg-white/20 hover:bg-white/30 text-white" />
              </div>
              <p className="text-lg text-white/90">Click and repeat each word!</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 8:
        return (
          <DragDropActivity
            title="Match Family Members"
            items={[
              { id: '1', content: 'Brother', type: 'source', matchId: '4' },
              { id: '2', content: 'Sister', type: 'source', matchId: '5' },
              { id: '3', content: 'Baby', type: 'source', matchId: '6' },
              { id: '4', content: '👦', type: 'target' },
              { id: '5', content: '👧', type: 'target' },
              { id: '6', content: '👶', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📝 Grammar Practice</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👦</span>
                  <span className="text-white text-lg">"This is my brother."</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white text-lg">"This is my sister."</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👶</span>
                  <span className="text-white text-lg">"This is my baby."</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Practice Speaking →
            </Button>
          </div>
        );

      case 10:
        return (
          <SpeakingActivity
            prompt="Look at the picture and say the sentence:"
            expectedResponse="This is my brother"
            onComplete={nextSlide}
          />
        );

      case 11:
        return (
          <SpeakingActivity
            prompt="Look at the picture and say the sentence:"
            expectedResponse="This is my sister"
            onComplete={nextSlide}
          />
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🏠 Family House Game</h2>
            <p className="text-lg text-white/90">Who lives in the house?</p>
            <div className="text-6xl mb-4">🏠</div>
            <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white text-2xl p-2">
                👦
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white text-2xl p-2">
                🐱
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white text-2xl p-2">
                🚗
              </Button>
            </div>
            <p className="text-white/80">Click Brother!</p>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎮 Family Quiz</h2>
            <p className="text-lg text-white/90">Who is this?</p>
            <div className="text-8xl mb-4">👧</div>
            <div className="space-y-2">
              <Button className="bg-white/20 hover:bg-white/30 text-white block mx-auto">
                Brother
              </Button>
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white block mx-auto">
                Sister ✓
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white block mx-auto">
                Baby
              </Button>
            </div>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">👨‍👩‍👧‍👦 Family Tree</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex justify-center gap-4">
                  <span className="text-3xl">👨</span>
                  <span className="text-3xl">👩</span>
                </div>
                <div className="text-white/60">Parents</div>
                <div className="flex justify-center gap-4">
                  <span className="text-3xl">👦</span>
                  <span className="text-3xl">👧</span>
                  <span className="text-3xl">👶</span>
                </div>
                <div className="text-white/60">Children</div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Mini Story</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white">"This is my brother!"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👦</span>
                  <span className="text-white">"This is my sister!"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👶</span>
                  <span className="text-white">"Wah wah!" (Baby sounds)</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Role-Play</h2>
            <p className="text-lg text-white/90">Tell me about your siblings!</p>
            <div className="space-y-4">
              <div className="text-6xl">👦👧👶</div>
              <p className="text-white/80">Say: "This is my brother", "This is my sister", "This is my baby"</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Great Job! →
            </Button>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📝 Quick Review</h2>
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👦</div>
                <p className="text-white">Brother</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👧</div>
                <p className="text-white">Sister</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">👶</div>
                <p className="text-white">Baby</p>
              </Card>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🌟 Lesson Complete!</h2>
            <div className="text-6xl mb-4">🎉</div>
            <p className="text-xl text-white/90">You learned about siblings!</p>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 max-w-md mx-auto">
              <p className="text-white font-semibold">New Words: Brother, Sister, Baby</p>
              <p className="text-white/80">Grammar: "This is my..."</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Get Badge! →
            </Button>
          </div>
        );

      case 19:
        return (
          <BadgeReward
            title="Congratulations!"
            description="You completed Lesson 6.2!"
            badgeName="Sibling Star Badge"
            onContinue={() => navigate('/lesson/6-3-intro')}
          />
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <ProgressBar current={currentSlide} total={totalSlides} />
          
          <Card className="p-8 bg-white/10 backdrop-blur-sm border-white/20 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </Card>
          
          <div className="mt-6 flex justify-between">
            <Button 
              onClick={() => navigate('/lesson/6-2-intro')}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/10"
            >
              ← Back to Intro
            </Button>
            
            <div className="text-white/60">
              Slide {currentSlide} of {totalSlides}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}