import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson53 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 20;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🦁</div>
            <h1 className="text-4xl font-bold text-primary">Wild Animals!</h1>
            <p className="text-xl text-muted-foreground">Welcome to the safari! Let's meet wild animals!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🌳</div>
              <div className="flex justify-center space-x-4">
                <div className="text-4xl animate-bounce">🦁</div>
                <div className="text-4xl animate-bounce" style={{ animationDelay: '0.2s' }}>🐘</div>
                <div className="text-4xl animate-bounce" style={{ animationDelay: '0.4s' }}>🐵</div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Animal Review</h2>
            <p className="text-lg text-muted-foreground">Let's remember the animals we know!</p>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-bold mb-4">Pets</h3>
                <div className="flex justify-center space-x-2">
                  <span className="text-2xl">🐱</span>
                  <span className="text-2xl">🐶</span>
                  <span className="text-2xl">🐟</span>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Farm Animals</h3>
                <div className="flex justify-center space-x-2">
                  <span className="text-2xl">🐦</span>
                  <span className="text-2xl">🐄</span>
                  <span className="text-2xl">🦆</span>
                </div>
              </div>
            </div>
            <p className="text-success font-semibold">Great! Now let's explore the wild!</p>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Adventure</h2>
            <div className="text-6xl mb-4">🎵</div>
            <p className="text-lg">Let's chant: A, B, C, D, E, F, G, H, I, J...</p>
            <div className="bg-primary/10 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">New Letter: Kk</h3>
              <div className="text-4xl mb-2">👑</div>
              <p className="text-xl">/k/ like King, Kite, Key</p>
              <AudioButton text="K, king, kite, key" className="mt-4" />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Lion!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🦁</div>
              <h3 className="text-3xl font-bold text-primary">Lion</h3>
              <p className="text-lg text-muted-foreground">The king of the jungle!</p>
              <div className="text-2xl mt-2">ROAAAAAR! 🔊</div>
              <AudioButton text="lion" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Elephant!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🐘</div>
              <h3 className="text-3xl font-bold text-primary">Elephant</h3>
              <p className="text-lg text-muted-foreground">The biggest animal!</p>
              <div className="text-2xl mt-2">Pfffrrrr! (trumpet) 🔊</div>
              <AudioButton text="elephant" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Monkey!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🐵</div>
              <h3 className="text-3xl font-bold text-primary">Monkey</h3>
              <p className="text-lg text-muted-foreground">Swings in the trees!</p>
              <div className="text-2xl mt-2">Ooh ooh ah ah! 🔊</div>
              <AudioButton text="monkey" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Wild Animal Sounds</h2>
            <p className="text-lg text-muted-foreground">Click each wild animal to hear its sound</p>
            <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🦁 Lion</span>
                <AudioButton text="lion" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🐘 Elephant</span>
                <AudioButton text="elephant" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🐵 Monkey</span>
                <AudioButton text="monkey" />
              </Button>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Safari Matching</h2>
            <p className="text-lg text-muted-foreground">Match the wild animals to their names!</p>
            <DragDropActivity
              title="Wild Animal Matching"
              items={[
                { id: "lion", content: "lion", type: "source", matchId: "lion-target" },
                { id: "elephant", content: "elephant", type: "source", matchId: "elephant-target" },
                { id: "monkey", content: "monkey", type: "source", matchId: "monkey-target" },
                { id: "lion-target", content: "🦁", type: "target" },
                { id: "elephant-target", content: "🐘", type: "target" },
                { id: "monkey-target", content: "🐵", type: "target" }
              ]}
              onComplete={() => console.log("Wild animal matching completed!")}
            />
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🦁</div>
              <h3 className="text-2xl font-bold text-primary">It is a lion.</h3>
              <AudioButton text="It is a lion" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐘</div>
              <h3 className="text-2xl font-bold text-primary">It is an elephant.</h3>
              <AudioButton text="It is an elephant" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Notice: "an" elephant</p>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐵</div>
              <h3 className="text-2xl font-bold text-primary">It is a monkey.</h3>
              <AudioButton text="It is a monkey" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Safari Speaking Challenge</h2>
            <p className="text-lg text-muted-foreground">When I show a wild animal, say the sentence!</p>
            <SpeakingActivity
              prompt="Look at the wild animal and say the sentence"
              expectedResponse="It is a lion"
              onComplete={() => console.log("Safari speaking completed!")}
            />
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Wild Animal Sound Safari!</h2>
            <div className="text-6xl mb-4">🔊</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Listen! Which wild animal is it?</h3>
              <div className="text-4xl mb-4">🔊 "ROAAAAAR!"</div>
              <div className="grid grid-cols-3 gap-4">
                <Button variant="outline" className="bg-success/20">🦁 Lion ✓</Button>
                <Button variant="outline">🐘 Elephant</Button>
                <Button variant="outline">🐵 Monkey</Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Excellent! A lion roars!
              </p>
            </div>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Jungle Hide and Seek!</h2>
            <div className="text-6xl mb-4">🌳</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Find the animals hiding in the jungle!</h3>
              <div className="relative bg-green-100 p-8 rounded-lg">
                <div className="text-6xl absolute top-2 left-4">🌳</div>
                <div className="text-4xl absolute top-8 right-8">🦁</div>
                <div className="text-6xl absolute bottom-2 left-8">🌿</div>
                <div className="text-3xl absolute bottom-4 right-4">🐵</div>
                <div className="text-5xl absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">🐘</div>
              </div>
              <p className="text-success font-semibold mt-4">Found them all! Great safari eyes!</p>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Animal Size Game</h2>
            <p className="text-lg text-muted-foreground">Which animal is the biggest?</p>
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <Button variant="outline" size="lg" className="p-8 flex flex-col">
                <div className="text-3xl">🦁</div>
                <span>Big</span>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="p-8 flex flex-col hover:bg-success/20 border-success"
              >
                <div className="text-4xl">🐘</div>
                <span>Biggest ✓</span>
              </Button>
              <Button variant="outline" size="lg" className="p-8 flex flex-col">
                <div className="text-2xl">🐵</div>
                <span>Small</span>
              </Button>
            </div>
            <p className="text-success font-semibold">Yes! The elephant is the biggest!</p>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Safari Binoculars Game</h2>
            <div className="text-6xl mb-4">🔍</div>
            <div className="bg-gradient-card p-8 rounded-lg">
              <p className="text-lg mb-4">Look through your binoculars! What do you see?</p>
              <div className="relative w-32 h-32 mx-auto bg-black rounded-full border-8 border-gray-600 mb-4">
                <div className="absolute inset-2 bg-white rounded-full flex items-center justify-center">
                  <div className="text-4xl">🐵</div>
                </div>
              </div>
              <Button 
                size="lg" 
                className="bg-gradient-primary hover:bg-gradient-primary/90"
              >
                "It is a monkey!"
              </Button>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Safari Story 1</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6">
                <div className="text-4xl mb-2">👦</div>
                <h3 className="font-bold">Tom the Explorer says:</h3>
                <div className="text-3xl my-2">🦁</div>
                <p className="text-lg">"It is a lion!"</p>
                <AudioButton text="It is a lion" className="mt-2" />
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-2">👧</div>
                <h3 className="font-bold">Anna the Guide says:</h3>
                <div className="text-3xl my-2">🐘</div>
                <p className="text-lg">"It is an elephant!"</p>
                <AudioButton text="It is an elephant" className="mt-2" />
              </Card>
            </div>
            <p className="text-muted-foreground">Join the safari adventure!</p>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Safari Story 2</h2>
            <Card className="p-8 max-w-md mx-auto">
              <div className="text-4xl mb-2">👶</div>
              <h3 className="font-bold">Ben the Junior Ranger says:</h3>
              <div className="text-4xl my-2">🐵</div>
              <p className="text-lg">"It is a monkey!"</p>
              <AudioButton text="It is a monkey" className="mt-2" />
            </Card>
            <div className="bg-primary/10 p-4 rounded-lg max-w-md mx-auto">
              <p className="font-semibold">Now you repeat:</p>
              <p className="text-lg">"It is a monkey!"</p>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Safari Role-Play</h2>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-4">🚙</div>
              <h3 className="text-xl font-bold mb-4">Welcome to our safari tour! Guide asks:</h3>
              <div className="text-5xl mb-4">🐘</div>
              <p className="text-lg mb-4">"What is it?"</p>
              <div className="bg-primary/10 p-4 rounded">
                <p className="font-semibold">Tourist answers:</p>
                <p className="text-xl text-primary">"It is an elephant!"</p>
              </div>
              <AudioButton text="It is an elephant" className="mt-4" />
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-3xl font-bold text-primary">Safari Complete!</h2>
            <p className="text-xl">You discovered amazing wild animals!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Safari Explorer Badge Earned!</h3>
              <p className="text-muted-foreground">You know lions, elephants, and monkeys!</p>
            </div>
            <div className="flex justify-center space-x-3">
              <span className="text-3xl">🦁</span>
              <span className="text-3xl">🐘</span>
              <span className="text-3xl">🐵</span>
            </div>
            <div className="bg-success/10 p-4 rounded-lg">
              <p className="text-lg font-semibold">🌳 Safari Adventure Complete! 🌳</p>
              <div className="text-4xl mt-2">🚙</div>
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Safari Explorer Badge"
        description="You discovered wild animals: lion, elephant, and monkey!"
        badgeName="Safari Explorer"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson53-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 5.3 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson53;