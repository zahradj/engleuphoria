import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";

export const Lesson32Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
      <FloatingLogo />
      
      <div className="max-w-4xl mx-auto text-center space-y-8">
        
        {/* Animated Header */}
        <div className="space-y-6">
          <div className="flex justify-center">
            <div className="relative">
              <div className="text-8xl animate-bounce-gentle">🎲</div>
              <div className="absolute -top-2 -right-2 text-2xl animate-pulse-fun">👧</div>
              <div className="absolute -bottom-1 -left-3 text-xl animate-bounce-gentle" style={{animationDelay: '0.5s'}}>🧸</div>
              <div className="absolute top-4 -left-4 text-lg animate-pulse-fun" style={{animationDelay: '1s'}}>🔢</div>
            </div>
          </div>
          
          <h1 className="text-5xl font-bold font-fredoka rainbow-text">
            Lesson 3.2
          </h1>
          <h2 className="text-4xl font-bold font-fredoka text-primary">
            Numbers 4-5 & More Toys! 🎲👧🧸
          </h2>
          <p className="text-xl text-muted-foreground font-fredoka">
            Unit 3 - Lesson 2 • 22 Fun Slides • 25-30 minutes
          </p>
        </div>

        {/* Lesson Preview */}
        <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl border-2 border-primary/30 shadow-glow">
          <h3 className="text-2xl font-bold font-fredoka text-center text-primary mb-6">
            🎯 Today's Adventure: Toy Collector Challenge!
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* What We'll Learn */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-success mb-4">🔢 What We'll Learn:</h4>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold">4</div>
                  <span className="text-foreground font-semibold">Number Four (4)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold">5</div>
                  <span className="text-foreground font-semibold">Number Five (5)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-pink-500 rounded-full"></div>
                  <span className="text-foreground font-semibold">New Toys: Doll & Teddy</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-accent rounded-full"></div>
                  <span className="text-foreground font-semibold">Phonics: Letter F</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-warning rounded-full"></div>
                  <span className="text-foreground font-semibold">Review: Numbers 1-3</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-primary rounded-full"></div>
                  <span className="text-foreground font-semibold">Sentences: "Four dolls" / "I have ___"</span>
                </div>
              </div>
            </div>

            {/* Fun Activities */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-warning mb-4">🎮 Fun Games & Activities:</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">✨</span>
                  <span className="text-foreground">Four Stars Counting</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎈</span>
                  <span className="text-foreground">Five Balloons Game</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-foreground">Dancing Doll Flashcards</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🧸</span>
                  <span className="text-foreground">Waving Teddy Bear</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🛒</span>
                  <span className="text-foreground">Extended Toy Shop</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎪</span>
                  <span className="text-foreground">Advanced Spin Wheel</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Number Progress */}
        <div className="bg-gradient-to-r from-success/20 to-primary/20 p-6 rounded-2xl border border-success/30">
          <h3 className="text-xl font-bold text-center mb-4 font-fredoka">🔢 Number Journey</h3>
          <div className="flex justify-center items-center gap-4">
            {[1, 2, 3, 4, 5].map((num, index) => (
              <div key={num} className="text-center">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg ${
                  num <= 3 ? 'bg-success text-white' : 
                  num <= 5 ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'
                }`}>
                  {num}
                </div>
                <p className="text-sm mt-1">
                  {num <= 3 ? 'Learned' : num <= 5 ? 'Today' : 'Soon'}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Learning Goals */}
        <div className="bg-gradient-warm p-6 rounded-2xl text-white">
          <h3 className="text-xl font-bold text-center mb-4 font-fredoka">🎯 Learning Goals</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
            <div className="bg-white/20 p-4 rounded-xl">
              <div className="text-2xl mb-2">🔢</div>
              <p className="font-semibold text-sm">Count to 5</p>
            </div>
            <div className="bg-white/20 p-4 rounded-xl">
              <div className="text-2xl mb-2">🎲</div>
              <p className="font-semibold text-sm">Learn New Toys</p>
            </div>
            <div className="bg-white/20 p-4 rounded-xl">
              <div className="text-2xl mb-2">🗣️</div>
              <p className="font-semibold text-sm">Build Sentences</p>
            </div>
            <div className="bg-white/20 p-4 rounded-xl">
              <div className="text-2xl mb-2">🅵</div>
              <p className="font-semibold text-sm">Master Letter F</p>
            </div>
          </div>
        </div>

        {/* Toy Collection Preview */}
        <div className="bg-gradient-to-r from-pink-200 to-purple-200 p-6 rounded-2xl">
          <h3 className="text-xl font-bold text-center mb-4 font-fredoka text-gray-800">🧸 Toy Collection</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center bg-white/80 p-3 rounded-xl">
              <div className="text-4xl mb-2">⚽</div>
              <p className="text-sm font-semibold text-gray-700">Ball</p>
              <p className="text-xs text-green-600">✓ Learned</p>
            </div>
            <div className="text-center bg-white/80 p-3 rounded-xl">
              <div className="text-4xl mb-2">🚗</div>
              <p className="text-sm font-semibold text-gray-700">Car</p>
              <p className="text-xs text-green-600">✓ Learned</p>
            </div>
            <div className="text-center bg-white/80 p-3 rounded-xl border-2 border-pink-400">
              <div className="text-4xl mb-2">👧</div>
              <p className="text-sm font-semibold text-gray-700">Doll</p>
              <p className="text-xs text-blue-600">📚 Today</p>
            </div>
            <div className="text-center bg-white/80 p-3 rounded-xl border-2 border-purple-400">
              <div className="text-4xl mb-2">🧸</div>
              <p className="text-sm font-semibold text-gray-700">Teddy</p>
              <p className="text-xs text-blue-600">📚 Today</p>
            </div>
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="space-y-4">
          <div className="flex gap-4 justify-center flex-wrap">
            <Button
              onClick={() => navigate("/lesson32")}
              size="fun"
              variant="kid"
              className="text-2xl font-bold font-fredoka shadow-glow hover:shadow-fun transform hover:scale-110 transition-all duration-300"
            >
              🚀 Start Toy Collecting! 🧸
            </Button>
            <Button
              onClick={() => navigate("/")}
              variant="outline"
              size="fun"
              className="text-xl font-bold font-fredoka border-primary text-primary hover:bg-primary/10"
            >
              ← Back to Program
            </Button>
          </div>
          <p className="text-sm text-muted-foreground font-fredoka">
            Ready to learn numbers 4-5 and collect more toys?
          </p>
        </div>
      </div>
    </div>
  );
};