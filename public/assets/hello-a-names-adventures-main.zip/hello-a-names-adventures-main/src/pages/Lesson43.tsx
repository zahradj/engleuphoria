import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson43 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 20;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🎉</div>
            <h1 className="text-4xl font-bold text-primary">My Body Review!</h1>
            <p className="text-xl text-muted-foreground">Let's review everything we learned!</p>
            <div className="flex justify-center space-x-3">
              <div className="text-3xl">🧠</div>
              <div className="text-3xl">👀</div>
              <div className="text-3xl">👃</div>
              <div className="text-3xl">👄</div>
              <div className="text-3xl">👋</div>
              <div className="text-3xl">🦶</div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Quick Flash Review</h2>
            <p className="text-lg text-muted-foreground">Tap each body part to hear the word!</p>
            <div className="grid grid-cols-3 gap-4">
              <Button variant="outline" size="lg" className="p-6 h-auto flex-col space-y-2">
                <div className="text-4xl">🧠</div>
                <span>Head</span>
                <AudioButton text="head" />
              </Button>
              <Button variant="outline" size="lg" className="p-6 h-auto flex-col space-y-2">
                <div className="text-4xl">👀</div>
                <span>Eyes</span>
                <AudioButton text="eyes" />
              </Button>
              <Button variant="outline" size="lg" className="p-6 h-auto flex-col space-y-2">
                <div className="text-4xl">👃</div>
                <span>Nose</span>
                <AudioButton text="nose" />
              </Button>
              <Button variant="outline" size="lg" className="p-6 h-auto flex-col space-y-2">
                <div className="text-4xl">👄</div>
                <span>Mouth</span>
                <AudioButton text="mouth" />
              </Button>
              <Button variant="outline" size="lg" className="p-6 h-auto flex-col space-y-2">
                <div className="text-4xl">👋</div>
                <span>Hands</span>
                <AudioButton text="hands" />
              </Button>
              <Button variant="outline" size="lg" className="p-6 h-auto flex-col space-y-2">
                <div className="text-4xl">🦶</div>
                <span>Feet</span>
                <AudioButton text="feet" />
              </Button>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Warm-Up</h2>
            <div className="text-6xl mb-4">🎵</div>
            <div className="bg-primary/10 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">Let's Chant: Aa–Hh!</h3>
              <div className="grid grid-cols-4 gap-2 text-lg font-bold">
                <div>A a</div>
                <div>B b</div>
                <div>C c</div>
                <div>D d</div>
                <div>E e</div>
                <div>F f</div>
                <div>G g</div>
                <div>H h</div>
              </div>
              <AudioButton text="A, B, C, D, E, F, G, H" className="mt-4" />
              <p className="text-sm text-muted-foreground mt-2">Clap along with the rhythm!</p>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Lesson 4.1 Review</h2>
            <p className="text-lg text-muted-foreground">Remember these body parts?</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="text-6xl">🧠</div>
                <h3 className="text-xl font-semibold">Head</h3>
                <p className="text-sm">"This is my head."</p>
                <AudioButton text="This is my head" />
              </div>
              <div className="space-y-2">
                <div className="text-6xl">👀</div>
                <h3 className="text-xl font-semibold">Eyes</h3>
                <p className="text-sm">"These are my eyes."</p>
                <AudioButton text="These are my eyes" />
              </div>
              <div className="space-y-2">
                <div className="text-6xl">👃</div>
                <h3 className="text-xl font-semibold">Nose</h3>
                <p className="text-sm">"This is my nose."</p>
                <AudioButton text="This is my nose" />
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Lesson 4.2 Review</h2>
            <p className="text-lg text-muted-foreground">And these body parts too!</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="text-6xl">👄</div>
                <h3 className="text-xl font-semibold">Mouth</h3>
                <p className="text-sm">"This is my mouth."</p>
                <AudioButton text="This is my mouth" />
              </div>
              <div className="space-y-2">
                <div className="text-6xl">👋</div>
                <h3 className="text-xl font-semibold">Hands</h3>
                <p className="text-sm">"These are my hands."</p>
                <AudioButton text="These are my hands" />
              </div>
              <div className="space-y-2">
                <div className="text-6xl">🦶</div>
                <h3 className="text-xl font-semibold">Feet</h3>
                <p className="text-sm">"These are my feet."</p>
                <AudioButton text="These are my feet" />
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Complete Body Puzzle</h2>
            <p className="text-lg text-muted-foreground">Match all the body parts to their names!</p>
            <DragDropActivity
              title="Body Parts Matching"
              items={[
                { id: "head", content: "head", type: "source", matchId: "head-target" },
                { id: "eyes", content: "eyes", type: "source", matchId: "eyes-target" },
                { id: "nose", content: "nose", type: "source", matchId: "nose-target" },
                { id: "mouth", content: "mouth", type: "source", matchId: "mouth-target" },
                { id: "hands", content: "hands", type: "source", matchId: "hands-target" },
                { id: "feet", content: "feet", type: "source", matchId: "feet-target" },
                { id: "head-target", content: "🧠", type: "target" },
                { id: "eyes-target", content: "👀", type: "target" },
                { id: "nose-target", content: "👃", type: "target" },
                { id: "mouth-target", content: "👄", type: "target" },
                { id: "hands-target", content: "👋", type: "target" },
                { id: "feet-target", content: "🦶", type: "target" }
              ]}
              onComplete={() => console.log("Complete puzzle finished!")}
            />
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Guess the Body Part</h2>
            <p className="text-lg text-muted-foreground">Look at the zoomed picture. What is it?</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4">👀</div>
              <div className="grid grid-cols-3 gap-4">
                <Button variant="outline">Head</Button>
                <Button variant="outline" className="bg-success/20">Eyes ✓</Button>
                <Button variant="outline">Nose</Button>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-4">
                <Button variant="outline">Mouth</Button>
                <Button variant="outline">Hands</Button>
                <Button variant="outline">Feet</Button>
              </div>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Speaking Drill</h2>
            <p className="text-lg text-muted-foreground">I'll point to a body part. You say the sentence!</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4">👋</div>
              <div className="bg-primary/10 p-4 rounded">
                <p className="text-lg font-bold">Teacher points to hands</p>
                <p className="text-muted-foreground">Student says:</p>
                <p className="text-xl text-primary">"These are my hands!"</p>
              </div>
              <AudioButton text="These are my hands" className="mt-4" />
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Model Sentences Review</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6 bg-gradient-primary/10">
                <h3 className="text-xl font-bold mb-4">Singular (This is my...)</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>🧠 "This is my head."</span>
                    <AudioButton text="This is my head" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👃 "This is my nose."</span>
                    <AudioButton text="This is my nose" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👄 "This is my mouth."</span>
                    <AudioButton text="This is my mouth" />
                  </div>
                </div>
              </Card>
              <Card className="p-6 bg-gradient-success/10">
                <h3 className="text-xl font-bold mb-4">Plural (These are my...)</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>👀 "These are my eyes."</span>
                    <AudioButton text="These are my eyes" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👋 "These are my hands."</span>
                    <AudioButton text="These are my hands" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦶 "These are my feet."</span>
                    <AudioButton text="These are my feet" />
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Builder Challenge</h2>
            <p className="text-lg text-muted-foreground">Build the sentence: "This is my nose."</p>
            <DragDropActivity
              title="Complete the Sentence"
              items={[
                { id: "this", content: "This", type: "source", matchId: "word1" },
                { id: "is", content: "is", type: "source", matchId: "word2" },
                { id: "my", content: "my", type: "source", matchId: "word3" },
                { id: "nose", content: "nose", type: "source", matchId: "word4" },
                { id: "period", content: ".", type: "source", matchId: "word5" },
                { id: "word1", content: "1st word", type: "target" },
                { id: "word2", content: "2nd word", type: "target" },
                { id: "word3", content: "3rd word", type: "target" },
                { id: "word4", content: "4th word", type: "target" },
                { id: "word5", content: "5th word", type: "target" }
              ]}
              onComplete={() => console.log("Sentence built!")}
            />
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Simon Says Challenge!</h2>
            <div className="text-6xl mb-4">🎮</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Simon Says:</h3>
              <div className="space-y-3">
                <Button size="lg" variant="outline" className="w-full text-lg">
                  "Touch your head!" 🧠
                </Button>
                <Button size="lg" variant="outline" className="w-full text-lg">
                  "Point to your eyes!" 👀
                </Button>
                <Button size="lg" variant="outline" className="w-full text-lg">
                  "Touch your nose!" 👃
                </Button>
                <Button size="lg" variant="outline" className="w-full text-lg">
                  "Open your mouth!" 👄
                </Button>
                <Button size="lg" variant="outline" className="w-full text-lg">
                  "Clap your hands!" 👋
                </Button>
                <Button size="lg" variant="outline" className="w-full text-lg">
                  "Stomp your feet!" 🦶
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Do the action AND say the sentence!
              </p>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Spin & Speak Wheel</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="w-56 h-56 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-6 relative">
                <div className="text-6xl">🧠</div>
                <div className="absolute top-2 w-0 h-0 border-l-4 border-r-4 border-b-8 border-transparent border-b-primary"></div>
              </div>
              <p className="text-lg mb-4">The magic wheel landed on: <strong>Head</strong></p>
              <div className="bg-primary/10 p-4 rounded">
                <p className="font-semibold">Now you say:</p>
                <p className="text-xl text-primary">"This is my head!"</p>
              </div>
              <AudioButton text="This is my head" className="mt-4" />
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Quick Quiz</h2>
            <p className="text-lg text-muted-foreground">Which ones are feet?</p>
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <Button variant="outline" size="lg" className="p-8 text-4xl">
                👋
              </Button>
              <Button variant="outline" size="lg" className="p-8 text-4xl">
                👀
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="p-8 text-4xl hover:bg-success/20 border-success"
              >
                🦶 ✓
              </Button>
            </div>
            <p className="text-success font-semibold">Correct! These are feet!</p>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Body Puzzle Race</h2>
            <p className="text-lg text-muted-foreground">Complete the cartoon figure quickly!</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="relative mx-auto w-48 h-64 bg-primary/5 rounded-lg border-2 border-dashed border-primary/30">
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 text-3xl">🧠</div>
                <div className="absolute top-12 left-1/2 transform -translate-x-1/2 text-2xl">👀</div>
                <div className="absolute top-16 left-1/2 transform -translate-x-1/2 text-xl">👃</div>
                <div className="absolute top-20 left-1/2 transform -translate-x-1/2 text-xl">👄</div>
                <div className="absolute top-32 left-4 text-2xl">👋</div>
                <div className="absolute top-32 right-4 text-2xl">👋</div>
                <div className="absolute bottom-4 left-8 text-2xl">🦶</div>
                <div className="absolute bottom-4 right-8 text-2xl">🦶</div>
              </div>
              <p className="text-success font-semibold mt-4">Perfect! You completed the body puzzle!</p>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Comic Story 1</h2>
            <Card className="p-8 max-w-md mx-auto">
              <div className="text-4xl mb-2">👦</div>
              <h3 className="font-bold text-lg">Tom says:</h3>
              <p className="text-xl text-primary">"This is my head!"</p>
              <AudioButton text="This is my head" className="mt-2" />
            </Card>
            <div className="bg-primary/10 p-4 rounded-lg max-w-md mx-auto">
              <p className="font-semibold">Now you repeat what Tom says:</p>
              <p className="text-lg">"This is my head!"</p>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Comic Story 2</h2>
            <Card className="p-8 max-w-md mx-auto">
              <div className="text-4xl mb-2">👧</div>
              <h3 className="font-bold text-lg">Anna says:</h3>
              <p className="text-xl text-primary">"These are my feet!"</p>
              <AudioButton text="These are my feet" className="mt-2" />
            </Card>
            <div className="bg-success/10 p-4 rounded-lg max-w-md mx-auto">
              <p className="font-semibold">Now you repeat what Anna says:</p>
              <p className="text-lg">"These are my feet!"</p>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Role-Play Time</h2>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-4">🎭</div>
              <h3 className="text-xl font-bold mb-4">Teacher asks:</h3>
              <p className="text-lg mb-4">"What are these?" 👀</p>
              <div className="bg-primary/10 p-4 rounded">
                <p className="font-semibold">Student answers:</p>
                <p className="text-xl text-primary">"These are my eyes!"</p>
              </div>
              <AudioButton text="These are my eyes" className="mt-4" />
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Chant Party</h2>
            <div className="text-6xl mb-4">🎉</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">A–H Chant with Actions!</h3>
              <div className="grid grid-cols-4 gap-4 text-lg font-bold mb-4">
                <div className="space-y-1">
                  <div>A a</div>
                  <div className="text-2xl">🍎</div>
                </div>
                <div className="space-y-1">
                  <div>B b</div>
                  <div className="text-2xl">⚽</div>
                </div>
                <div className="space-y-1">
                  <div>C c</div>
                  <div className="text-2xl">🐱</div>
                </div>
                <div className="space-y-1">
                  <div>D d</div>
                  <div className="text-2xl">🐕</div>
                </div>
                <div className="space-y-1">
                  <div>E e</div>
                  <div className="text-2xl">🥚</div>
                </div>
                <div className="space-y-1">
                  <div>F f</div>
                  <div className="text-2xl">🐟</div>
                </div>
                <div className="space-y-1">
                  <div>G g</div>
                  <div className="text-2xl">🦒</div>
                </div>
                <div className="space-y-1">
                  <div>H h</div>
                  <div className="text-2xl">🎩</div>
                </div>
              </div>
              <AudioButton text="A apple, B ball, C cat, D dog, E egg, F fish, G giraffe, H hat" />
              <p className="text-sm text-muted-foreground mt-2">Clap and move your body!</p>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Final Review Quiz</h2>
            <p className="text-lg text-muted-foreground">Let's test everything you learned!</p>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">Question 1: Which is your nose?</p>
                <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
                  <Button variant="outline" size="lg" className="text-3xl">👄</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">👃 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">👀</Button>
                </div>
              </div>
              <div>
                <p className="font-semibold mb-2">Question 2: Complete: "These are my ___"</p>
                <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
                  <Button variant="outline">head</Button>
                  <Button variant="outline">nose</Button>
                  <Button variant="outline" className="bg-success/20">hands ✓</Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🏆</div>
            <h2 className="text-3xl font-bold text-primary">Amazing Work!</h2>
            <p className="text-xl">You completed the full body review!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Body Champion Badge Earned!</h3>
              <p className="text-muted-foreground">You mastered all body parts!</p>
            </div>
            <div className="flex flex-wrap justify-center gap-3">
              <span className="text-3xl">🧠</span>
              <span className="text-3xl">👀</span>
              <span className="text-3xl">👃</span>
              <span className="text-3xl">👄</span>
              <span className="text-3xl">👋</span>
              <span className="text-3xl">🦶</span>
            </div>
            <div className="text-lg font-semibold">
              Unit 4 Complete! 🎉
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Body Champion Badge"
        description="You mastered all body parts and completed Unit 4!"
        badgeName="Body Champion"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson43-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 4.3 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson43;