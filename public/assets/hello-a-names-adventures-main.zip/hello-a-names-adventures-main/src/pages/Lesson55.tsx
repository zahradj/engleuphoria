import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson55 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 23;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🏆</div>
            <h1 className="text-4xl font-bold text-primary">Animal Kingdom Review & Test!</h1>
            <p className="text-xl text-muted-foreground">Let's test everything we learned about animals!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🐾</div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <div className="text-2xl">🐱🐶🐟</div>
                  <span className="text-sm">Pets</span>
                </div>
                <div className="space-y-2">
                  <div className="text-2xl">🐦🐄🦆</div>
                  <span className="text-sm">Farm</span>
                </div>
                <div className="space-y-2">
                  <div className="text-2xl">🦁🐘🐵</div>
                  <span className="text-sm">Wild</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Unit 5 Journey</h2>
            <p className="text-lg text-muted-foreground">Look at our amazing animal adventure!</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="p-4">
                <h3 className="font-bold mb-2">Lesson 5.1</h3>
                <div className="text-3xl mb-2">🏠</div>
                <p>We met pet animals</p>
                <div className="flex justify-center space-x-1">
                  <span className="text-xl">🐱</span>
                  <span className="text-xl">🐶</span>
                  <span className="text-xl">🐟</span>
                </div>
              </Card>
              <Card className="p-4">
                <h3 className="font-bold mb-2">Lesson 5.2</h3>
                <div className="text-3xl mb-2">🚜</div>
                <p>We visited the farm</p>
                <div className="flex justify-center space-x-1">
                  <span className="text-xl">🐦</span>
                  <span className="text-xl">🐄</span>
                  <span className="text-xl">🦆</span>
                </div>
              </Card>
              <Card className="p-4">
                <h3 className="font-bold mb-2">Lesson 5.3</h3>
                <div className="text-3xl mb-2">🌳</div>
                <p>We explored the wild</p>
                <div className="flex justify-center space-x-1">
                  <span className="text-xl">🦁</span>
                  <span className="text-xl">🐘</span>
                  <span className="text-xl">🐵</span>
                </div>
              </Card>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Review Test</h2>
            <div className="text-6xl mb-4">🔤</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">A–L Phonics Assessment</h3>
              <div className="grid grid-cols-4 gap-4 text-lg font-bold mb-4">
                <div className="space-y-1">
                  <div>A a 🍎</div>
                  <div>B b ⚽</div>
                  <div>C c 🐱</div>
                </div>
                <div className="space-y-1">
                  <div>D d 🐕</div>
                  <div>E e 🥚</div>
                  <div>F f 🐟</div>
                </div>
                <div className="space-y-1">
                  <div>G g 🦒</div>
                  <div>H h 🎩</div>
                  <div>I i 🏠</div>
                </div>
                <div className="space-y-1">
                  <div>J j 🍯</div>
                  <div>K k 👑</div>
                  <div>L l 🦁</div>
                </div>
              </div>
              <AudioButton text="A apple, B ball, C cat, D dog, E egg, F fish, G giraffe, H hat, I igloo, J jam, K king, L lion" />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Animal Sorting</h2>
            <p className="text-lg text-muted-foreground">Sort these animals into the correct groups</p>
            <DragDropActivity
              title="Animal Kingdom Sorting"
              items={[
                { id: "cat", content: "🐱", type: "source", matchId: "pets" },
                { id: "cow", content: "🐄", type: "source", matchId: "farm" },
                { id: "lion", content: "🦁", type: "source", matchId: "wild" },
                { id: "pets", content: "🏠 Pets", type: "target" },
                { id: "farm", content: "🚜 Farm", type: "target" },
                { id: "wild", content: "🌳 Wild", type: "target" }
              ]}
              onComplete={() => console.log("Animal sorting completed!")}
            />
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Pet Animals</h2>
            <p className="text-lg text-muted-foreground">Click all the pet animals</p>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">Which animals are pets?</p>
                <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🐱 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🐶 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🐄</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🐟 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🦁</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🐘</Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Farm Animals</h2>
            <p className="text-lg text-muted-foreground">Click all the farm animals</p>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">Which animals live on a farm?</p>
                <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🐦 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🐄 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🦆 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🐱</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🦁</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🐵</Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Wild Animals</h2>
            <p className="text-lg text-muted-foreground">Click all the wild animals</p>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">Which animals live in the wild?</p>
                <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
                  <Button variant="outline" size="lg" className="text-3xl">🐶</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🦁 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🐄</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🐘 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl bg-success/20">🐵 ✓</Button>
                  <Button variant="outline" size="lg" className="text-3xl">🦆</Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Animal Sounds</h2>
            <div className="text-6xl mb-4">🔊</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Listen! Which animal makes this sound?</h3>
              <div className="text-4xl mb-4">🔊 "Quack! Quack!"</div>
              <div className="grid grid-cols-3 gap-4">
                <Button variant="outline">🐄 Cow</Button>
                <Button variant="outline" className="bg-success/20">🦆 Duck ✓</Button>
                <Button variant="outline">🦁 Lion</Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Perfect! Ducks say "Quack!"
              </p>
            </div>
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: More Animal Sounds</h2>
            <div className="text-6xl mb-4">🔊</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Which animal makes this sound?</h3>
              <div className="text-4xl mb-4">🔊 "ROAAAAAR!"</div>
              <div className="grid grid-cols-3 gap-4">
                <Button variant="outline" className="bg-success/20">🦁 Lion ✓</Button>
                <Button variant="outline">🐘 Elephant</Button>
                <Button variant="outline">🐵 Monkey</Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Excellent! Lions roar!
              </p>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Sentence Building</h2>
            <p className="text-lg text-muted-foreground">Complete: "It is an elephant"</p>
            <DragDropActivity
              title="Build the Sentence"
              items={[
                { id: "it", content: "It", type: "source", matchId: "word1" },
                { id: "is", content: "is", type: "source", matchId: "word2" },
                { id: "an", content: "an", type: "source", matchId: "word3" },
                { id: "elephant", content: "elephant", type: "source", matchId: "word4" },
                { id: "period", content: ".", type: "source", matchId: "word5" },
                { id: "word1", content: "1st", type: "target" },
                { id: "word2", content: "2nd", type: "target" },
                { id: "word3", content: "3rd", type: "target" },
                { id: "word4", content: "4th", type: "target" },
                { id: "word5", content: "5th", type: "target" }
              ]}
              onComplete={() => console.log("Assessment sentence built!")}
            />
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Speaking Test</h2>
            <SpeakingActivity
              prompt="Say this sentence: It is a cat"
              expectedResponse="It is a cat"
              onComplete={() => console.log("Speaking assessment completed!")}
            />
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Animal Actions</h2>
            <p className="text-lg text-muted-foreground">What can fish do?</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐟</div>
              <div className="grid grid-cols-4 gap-4">
                <Button variant="outline" className="bg-success/20">Swim ✓</Button>
                <Button variant="outline">Fly</Button>
                <Button variant="outline">Run</Button>
                <Button variant="outline">Jump</Button>
              </div>
              <p className="text-success font-semibold mt-4">Yes! Fish can swim!</p>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Complete Animal Actions</h2>
            <p className="text-lg text-muted-foreground">Match animals to their actions</p>
            <DragDropActivity
              title="Animals and Actions"
              items={[
                { id: "bird", content: "🐦", type: "source", matchId: "fly-target" },
                { id: "dog", content: "🐶", type: "source", matchId: "run-target" },
                { id: "monkey", content: "🐵", type: "source", matchId: "jump-target" },
                { id: "fly-target", content: "🦅 fly", type: "target" },
                { id: "run-target", content: "🏃‍♂️ run", type: "target" },
                { id: "jump-target", content: "🦘 jump", type: "target" }
              ]}
              onComplete={() => console.log("Animal actions assessment completed!")}
            />
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: "A" vs "An"</h2>
            <p className="text-lg text-muted-foreground">Choose the correct word</p>
            <div className="space-y-6">
              <div>
                <p className="font-semibold mb-2">It is ___ elephant.</p>
                <div className="grid grid-cols-2 gap-4 max-w-xs mx-auto">
                  <Button variant="outline">a</Button>
                  <Button variant="outline" className="bg-success/20">an ✓</Button>
                </div>
              </div>
              <div>
                <p className="font-semibold mb-2">It is ___ cat.</p>
                <div className="grid grid-cols-2 gap-4 max-w-xs mx-auto">
                  <Button variant="outline" className="bg-success/20">a ✓</Button>
                  <Button variant="outline">an</Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Memory Challenge</h2>
            <p className="text-lg text-muted-foreground">Remember all 9 animals in order</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <p className="mb-4">Click them in lesson order: Pets → Farm → Wild</p>
              <div className="grid grid-cols-3 gap-3">
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🐱 1</Button>
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🐶 2</Button>
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🐟 3</Button>
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🐦 4</Button>
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🐄 5</Button>
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🦆 6</Button>
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🦁 7</Button>
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🐘 8</Button>
                <Button variant="outline" size="lg" className="text-2xl bg-success/20">🐵 9</Button>
              </div>
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Animal Habitats</h2>
            <p className="text-lg text-muted-foreground">Where do these animals live?</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="p-4">
                <h3 className="font-bold mb-2">🏠 Home</h3>
                <div className="text-4xl mb-2">🐱🐶🐟</div>
                <p className="text-sm">Pets live with families</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-bold mb-2">🚜 Farm</h3>
                <div className="text-4xl mb-2">🐦🐄🦆</div>
                <p className="text-sm">Farm animals help farmers</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-bold mb-2">🌳 Wild</h3>
                <div className="text-4xl mb-2">🦁🐘🐵</div>
                <p className="text-sm">Wild animals live in nature</p>
              </Card>
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Speaking Performance</h2>
            <p className="text-lg text-muted-foreground">Show me and tell me about each animal</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="space-y-4">
                <div className="p-4 border rounded">
                  <div className="text-4xl mb-2">🐄</div>
                  <p className="font-semibold">Show: Point and say</p>
                  <p className="text-sm">"It is a cow. Moo!"</p>
                </div>
                <div className="p-4 border rounded">
                  <div className="text-4xl mb-2">🦁</div>
                  <p className="font-semibold">Show: Act and say</p>
                  <p className="text-sm">"It is a lion. Roar!"</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment: Complete Sentences</h2>
            <p className="text-lg text-muted-foreground">Make complete sentences about actions</p>
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4">
                <div className="text-3xl mb-2">🐟</div>
                <p className="font-semibold">Fish _____ swim.</p>
                <Button className="mt-2 bg-success/20">can ✓</Button>
              </Card>
              <Card className="p-4">
                <div className="text-3xl mb-2">🐦</div>
                <p className="font-semibold">Birds _____ fly.</p>
                <Button className="mt-2 bg-success/20">can ✓</Button>
              </Card>
              <Card className="p-4">
                <div className="text-3xl mb-2">🐶</div>
                <p className="font-semibold">Dogs _____ run.</p>
                <Button className="mt-2 bg-success/20">can ✓</Button>
              </Card>
              <Card className="p-4">
                <div className="text-3xl mb-2">🐵</div>
                <p className="font-semibold">Monkeys _____ jump.</p>
                <Button className="mt-2 bg-success/20">can ✓</Button>
              </Card>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Assessment Results</h2>
            <div className="text-6xl mb-4">📊</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Unit 5 Assessment Complete!</h3>
              <div className="grid grid-cols-2 gap-4 text-left">
                <div>
                  <h4 className="font-semibold">Animals:</h4>
                  <p className="text-success">✓ 9/9 mastered</p>
                </div>
                <div>
                  <h4 className="font-semibold">Sentences:</h4>
                  <p className="text-success">✓ Perfect structure</p>
                </div>
                <div>
                  <h4 className="font-semibold">Sounds:</h4>
                  <p className="text-success">✓ All recognized</p>
                </div>
                <div>
                  <h4 className="font-semibold">Actions:</h4>
                  <p className="text-success">✓ All matched</p>
                </div>
                <div>
                  <h4 className="font-semibold">Phonics A-L:</h4>
                  <p className="text-success">✓ Complete mastery</p>
                </div>
                <div>
                  <h4 className="font-semibold">Speaking:</h4>
                  <p className="text-success">✓ Fluent responses</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Unit 5 Achievement Summary</h2>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">What You Accomplished:</h3>
              <div className="space-y-3 text-left">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Learned 9 complete animal vocabulary words</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Mastered "It is a/an..." sentence patterns</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Learned "Animals can..." ability sentences</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Completed phonics letters A through L</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Understood animal habitats and categories</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>Passed comprehensive unit assessment</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Ready for Unit 6!</h2>
            <div className="text-6xl mb-4">🎓</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Next Learning Adventures:</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-3xl">👨‍👩‍👧‍👦</div>
                  <h4 className="font-semibold">Unit 6: Family</h4>
                  <p className="text-sm">Mom, Dad, Sister, Brother</p>
                </div>
                <div className="space-y-2">
                  <div className="text-3xl">🎨</div>
                  <h4 className="font-semibold">Unit 7: Colors</h4>
                  <p className="text-sm">Advanced color vocabulary</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 22:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Animal Kingdom Celebration!</h2>
            <div className="text-6xl mb-4">🎉</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Celebrate your animal knowledge!</h3>
              <p className="mb-4">You know animals from pets to wild safari!</p>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-2xl">🐱</span>
                <span className="text-2xl">🐶</span>
                <span className="text-2xl">🐟</span>
                <span className="text-2xl">🐦</span>
                <span className="text-2xl">🐄</span>
                <span className="text-2xl">🦆</span>
                <span className="text-2xl">🦁</span>
                <span className="text-2xl">🐘</span>
                <span className="text-2xl">🐵</span>
              </div>
            </div>
          </div>
        );

      case 23:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🏆</div>
            <h2 className="text-3xl font-bold text-primary">Animal Kingdom Master!</h2>
            <p className="text-xl">You completed the entire Animal unit!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Animal Kingdom Master Badge Earned!</h3>
              <p className="text-muted-foreground">Ready for Unit 6: Family!</p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <span className="text-2xl">🐱</span>
              <span className="text-2xl">🐶</span>
              <span className="text-2xl">🐟</span>
              <span className="text-2xl">🐦</span>
              <span className="text-2xl">🐄</span>
              <span className="text-2xl">🦆</span>
              <span className="text-2xl">🦁</span>
              <span className="text-2xl">🐘</span>
              <span className="text-2xl">🐵</span>
            </div>
            <div className="text-lg font-semibold text-success">
              🎊 UNIT 5 COMPLETE! 🎊
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Animal Kingdom Master Badge"
        description="You completed all of Unit 5: Animals! Amazing work learning 9 animals, their sounds, actions, and habitats!"
        badgeName="Animal Kingdom Master"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson55-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 5.5 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish Unit 5!" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson55;