import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { ProgressBar } from "@/components/ProgressBar";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";
import { ArrowLeft, ArrowRight, RotateCcw, Home, Volume2 } from "lucide-react";

const Lesson51 = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 21;
  const [showBadge, setShowBadge] = useState(false);

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setShowBadge(true);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const resetLesson = () => {
    setCurrentSlide(1);
    setShowBadge(false);
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🐾</div>
            <h1 className="text-4xl font-bold text-primary">Pets!</h1>
            <p className="text-xl text-muted-foreground">Let's meet our animal friends!</p>
            <div className="flex justify-center space-x-4">
              <div className="text-4xl animate-bounce">🐱</div>
              <div className="text-4xl animate-bounce" style={{ animationDelay: '0.2s' }}>🐶</div>
              <div className="text-4xl animate-bounce" style={{ animationDelay: '0.4s' }}>🐟</div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Quick Review</h2>
            <p className="text-lg text-muted-foreground">Let's remember our body parts!</p>
            <div className="grid grid-cols-5 gap-4">
              <div className="space-y-2">
                <div className="text-3xl">🧠</div>
                <span className="text-sm">Head</span>
              </div>
              <div className="space-y-2">
                <div className="text-3xl">👀</div>
                <span className="text-sm">Eyes</span>
              </div>
              <div className="space-y-2">
                <div className="text-3xl">👃</div>
                <span className="text-sm">Nose</span>
              </div>
              <div className="space-y-2">
                <div className="text-3xl">👋</div>
                <span className="text-sm">Hands</span>
              </div>
              <div className="space-y-2">
                <div className="text-3xl">🦶</div>
                <span className="text-sm">Feet</span>
              </div>
            </div>
            <p className="text-success font-semibold">Great job! Now let's learn about animals!</p>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Phonics Time</h2>
            <div className="text-6xl mb-4">🎵</div>
            <p className="text-lg">Let's chant: A, B, C, D, E, F, G, H...</p>
            <div className="bg-primary/10 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-primary mb-4">Letter: Ii</h3>
              <div className="text-4xl mb-2">🏠</div>
              <p className="text-xl">/ɪ/ like Insect, Igloo</p>
              <AudioButton text="I, insect, igloo" className="mt-4" />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Cat!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🐱</div>
              <h3 className="text-3xl font-bold text-primary">Cat</h3>
              <p className="text-lg text-muted-foreground">Tap to hear the cat!</p>
              <div className="text-2xl mt-2">Meow! 🔊</div>
              <AudioButton text="cat" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Dog!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🐶</div>
              <h3 className="text-3xl font-bold text-primary">Dog</h3>
              <p className="text-lg text-muted-foreground">Tap to hear the dog!</p>
              <div className="text-2xl mt-2">Woof! 🔊</div>
              <AudioButton text="dog" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Meet the Fish!</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-8xl mb-4 cursor-pointer hover:scale-110 transition-transform">🐟</div>
              <h3 className="text-3xl font-bold text-primary">Fish</h3>
              <p className="text-lg text-muted-foreground">Tap to see the fish swim!</p>
              <div className="text-2xl mt-2">Bubble! 🔊</div>
              <AudioButton text="fish" size="lg" className="mt-4" />
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Listen & Repeat</h2>
            <p className="text-lg text-muted-foreground">Click each animal to hear its name</p>
            <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🐱 Cat</span>
                <AudioButton text="cat" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🐶 Dog</span>
                <AudioButton text="dog" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center justify-between p-6">
                <span className="text-xl">🐟 Fish</span>
                <AudioButton text="fish" />
              </Button>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Pet Matching Game</h2>
            <p className="text-lg text-muted-foreground">Match the words to the pet pictures!</p>
            <DragDropActivity
              title="Match Pets to Words"
              items={[
                { id: "cat", content: "cat", type: "source", matchId: "cat-target" },
                { id: "dog", content: "dog", type: "source", matchId: "dog-target" },
                { id: "fish", content: "fish", type: "source", matchId: "fish-target" },
                { id: "cat-target", content: "🐱", type: "target" },
                { id: "dog-target", content: "🐶", type: "target" },
                { id: "fish-target", content: "🐟", type: "target" }
              ]}
              onComplete={() => console.log("Pet matching completed!")}
            />
          </div>
        );

      case 9:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐱</div>
              <h3 className="text-2xl font-bold text-primary">It is a cat.</h3>
              <AudioButton text="It is a cat" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐶</div>
              <h3 className="text-2xl font-bold text-primary">It is a dog.</h3>
              <AudioButton text="It is a dog" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Practice</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="text-6xl mb-4">🐟</div>
              <h3 className="text-2xl font-bold text-primary">It is a fish.</h3>
              <AudioButton text="It is a fish" size="lg" className="mt-4" />
              <p className="text-muted-foreground mt-2">Listen and repeat</p>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Speaking Drill</h2>
            <p className="text-lg text-muted-foreground">When I show an animal, say the full sentence!</p>
            <SpeakingActivity
              prompt="Look at the animal and say the sentence"
              expectedResponse="It is a cat"
              onComplete={() => console.log("Speaking completed!")}
            />
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Sentence Builder</h2>
            <p className="text-lg text-muted-foreground">Build the sentence: "It is a dog"</p>
            <DragDropActivity
              title="Complete the Sentence"
              items={[
                { id: "it", content: "It", type: "source", matchId: "word1" },
                { id: "is", content: "is", type: "source", matchId: "word2" },
                { id: "a", content: "a", type: "source", matchId: "word3" },
                { id: "dog", content: "dog", type: "source", matchId: "word4" },
                { id: "period", content: ".", type: "source", matchId: "word5" },
                { id: "word1", content: "1st word", type: "target" },
                { id: "word2", content: "2nd word", type: "target" },
                { id: "word3", content: "3rd word", type: "target" },
                { id: "word4", content: "4th word", type: "target" },
                { id: "word5", content: "5th word", type: "target" }
              ]}
              onComplete={() => console.log("Sentence built!")}
            />
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Animal Sounds Game!</h2>
            <div className="text-6xl mb-4">🔊</div>
            <div className="bg-gradient-card p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Listen to the sound! What animal is it?</h3>
              <div className="text-4xl mb-4">🔊 "Meow!"</div>
              <div className="grid grid-cols-3 gap-4">
                <Button variant="outline" className="bg-success/20">🐱 Cat ✓</Button>
                <Button variant="outline">🐶 Dog</Button>
                <Button variant="outline">🐟 Fish</Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Great! A cat says "Meow!"
              </p>
            </div>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Spin & Speak Wheel</h2>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="w-48 h-48 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <div className="text-6xl">🐶</div>
              </div>
              <p className="text-lg">The wheel landed on: <strong>Dog</strong></p>
              <div className="bg-primary/10 p-4 rounded mt-4">
                <p className="font-semibold">Now you say:</p>
                <p className="text-xl text-primary">"It is a dog!"</p>
              </div>
              <AudioButton text="It is a dog" className="mt-4" />
            </div>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Matching Quiz</h2>
            <p className="text-lg text-muted-foreground">Which one is a fish?</p>
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <Button variant="outline" size="lg" className="p-8 text-4xl">
                🐱
              </Button>
              <Button variant="outline" size="lg" className="p-8 text-4xl">
                🐶
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="p-8 text-4xl hover:bg-success/20 border-success"
              >
                🐟 ✓
              </Button>
            </div>
            <p className="text-success font-semibold">Correct! It is a fish!</p>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Guess the Hidden Animal</h2>
            <p className="text-lg text-muted-foreground">What's behind the curtain?</p>
            <div className="bg-gradient-card p-8 rounded-lg">
              <div className="relative w-32 h-32 mx-auto bg-primary/20 rounded-lg border-2 border-dashed border-primary/50 mb-4">
                <div className="absolute inset-0 bg-primary/10 rounded flex items-center justify-center">
                  <span className="text-2xl">🎭</span>
                </div>
              </div>
              <p className="text-lg mb-4">🔊 "Woof! Woof!"</p>
              <Button 
                size="lg" 
                className="bg-gradient-primary hover:bg-gradient-primary/90"
                onClick={() => console.log("Reveal animal!")}
              >
                Reveal the Animal!
              </Button>
              <div className="mt-4 text-6xl">🐶</div>
              <p className="text-xl text-primary font-bold">It is a dog!</p>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Comic Story 1</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6">
                <div className="text-4xl mb-2">👦</div>
                <h3 className="font-bold">Tom says:</h3>
                <div className="text-3xl my-2">🐶</div>
                <p className="text-lg">"It is a dog!"</p>
                <AudioButton text="It is a dog" className="mt-2" />
              </Card>
              <Card className="p-6">
                <div className="text-4xl mb-2">👧</div>
                <h3 className="font-bold">Anna says:</h3>
                <div className="text-3xl my-2">🐱</div>
                <p className="text-lg">"It is a cat!"</p>
                <AudioButton text="It is a cat" className="mt-2" />
              </Card>
            </div>
            <p className="text-muted-foreground">Listen and repeat what they say!</p>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Mini Comic Story 2</h2>
            <Card className="p-8 max-w-md mx-auto">
              <div className="text-4xl mb-2">👶</div>
              <h3 className="font-bold">Ben says:</h3>
              <div className="text-4xl my-2">🐟</div>
              <p className="text-lg">"It is a fish!"</p>
              <AudioButton text="It is a fish" className="mt-2" />
            </Card>
            <div className="bg-primary/10 p-4 rounded-lg max-w-md mx-auto">
              <p className="font-semibold">Now you repeat:</p>
              <p className="text-lg">"It is a fish!"</p>
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold">Role-Play Time</h2>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-4">🎭</div>
              <h3 className="text-xl font-bold mb-4">Teacher asks:</h3>
              <div className="text-5xl mb-4">🐱</div>
              <p className="text-lg mb-4">"What is it?"</p>
              <div className="bg-primary/10 p-4 rounded">
                <p className="font-semibold">Student answers:</p>
                <p className="text-xl text-primary">"It is a cat!"</p>
              </div>
              <AudioButton text="It is a cat" className="mt-4" />
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-6">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-3xl font-bold text-primary">Amazing Work!</h2>
            <p className="text-xl">You met all the pets!</p>
            <div className="bg-gradient-card p-6 rounded-lg">
              <div className="text-4xl mb-2">🏅</div>
              <h3 className="text-xl font-bold">Pet Friend Badge Earned!</h3>
              <p className="text-muted-foreground">You know cats, dogs, and fish!</p>
            </div>
            <div className="flex justify-center space-x-3">
              <span className="text-3xl">🐱</span>
              <span className="text-3xl">🐶</span>
              <span className="text-3xl">🐟</span>
            </div>
            <div className="bg-success/10 p-4 rounded-lg">
              <p className="text-lg font-semibold">Unit 5 Started! 🎊</p>
            </div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  if (showBadge) {
    return (
      <BadgeReward
        title="Pet Friend Badge"
        description="You learned about cats, dogs, and fish!"
        badgeName="Pet Friend"
        onContinue={() => navigate("/")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-fun">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button variant="ghost" onClick={() => navigate("/lesson51-intro")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Intro
        </Button>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary">
            Lesson 5.1 - Slide {currentSlide}/{totalSlides}
          </Badge>
        </div>

        <Button variant="ghost" onClick={() => navigate("/")}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <ProgressBar 
          current={currentSlide} 
          total={totalSlides} 
          className="max-w-4xl mx-auto"
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl bg-background/95 backdrop-blur shadow-2xl">
          <CardContent className="p-8 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 bg-background/80 backdrop-blur">
        <Button 
          variant="outline" 
          onClick={prevSlide}
          disabled={currentSlide === 1}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={resetLesson}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <Button 
          onClick={nextSlide}
          className="bg-gradient-primary hover:bg-gradient-primary/90"
        >
          {currentSlide === totalSlides ? "Finish" : "Next"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default Lesson51;