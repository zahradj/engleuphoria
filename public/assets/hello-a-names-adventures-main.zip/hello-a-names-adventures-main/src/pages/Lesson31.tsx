import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { BadgeReward } from "@/components/BadgeReward";
import { FloatingLogo } from "@/components/FloatingLogo";
import { DragDropActivity } from "@/components/DragDropActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";

const totalSlides = 21;

const Lesson31 = () => {
  const [currentSlide, setCurrentSlide] = useState(1);
  const [showBadgeReward, setShowBadgeReward] = useState(false);
  const navigate = useNavigate();

  const numbers = [1, 2, 3];
  const toys = ["ball", "car"];
  const colors = ["red", "blue", "yellow", "green", "black", "white"];
  
  const [basketItems, setBasketItems] = useState<string[]>([]);
  const [spinResult, setSpinResult] = useState<{toy: string, number: number} | null>(null);
  const [clickedObjects, setClickedObjects] = useState<number[]>([]);

  const nextSlide = () => {
    if (currentSlide >= totalSlides) {
      setShowBadgeReward(true);
    } else {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const handleObjectClick = (id: number) => {
    if (!clickedObjects.includes(id)) {
      setClickedObjects(prev => [...prev, id]);
    }
  };

  const handleSpin = () => {
    const randomToy = toys[Math.floor(Math.random() * toys.length)];
    const randomNumber = numbers[Math.floor(Math.random() * numbers.length)];
    setSpinResult({ toy: randomToy, number: randomNumber });
  };

  const handleDragToBasket = (toy: string) => {
    setBasketItems(prev => [...prev, toy]);
  };

  if (showBadgeReward) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 flex items-center justify-center p-4">
        <BadgeReward
          title="Number & Toy Explorer!"
          description="You've learned numbers 1-3 and toys! Fantastic counting!"
          badgeName="Number & Toy Explorer Badge 🎲"
          onContinue={() => navigate("/")}
        />
      </div>
    );
  }

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-8">
            <div className="flex justify-center gap-4">
              <div className="text-8xl animate-bounce-gentle">🎲</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.3s'}}>⚽</div>
              <div className="text-8xl animate-bounce-gentle" style={{animationDelay: '0.6s'}}>🚗</div>
            </div>
            <h1 className="text-5xl font-bold font-fredoka rainbow-text">
              Numbers & Toys!
            </h1>
            <p className="text-2xl font-fredoka text-primary">
              Let's count and play together! 🔢
            </p>
            <div className="flex justify-center gap-6">
              {numbers.map(num => (
                <div key={num} className="text-center">
                  <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold animate-pulse-fun">
                    {num}
                  </div>
                  <p className="text-lg font-bold mt-2">{num === 1 ? 'One' : num === 2 ? 'Two' : 'Three'}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🌈 Quick Color Review!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              What color is this? Click and say the color!
            </p>
            <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              {colors.slice(0, 6).map(color => (
                <Card key={color} className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105">
                  <div className="text-center space-y-4">
                    <div
                      className="w-20 h-20 rounded-lg mx-auto"
                      style={{ 
                        backgroundColor: color === 'black' ? '#000' : color === 'white' ? '#fff' : color,
                        border: color === 'white' ? '2px solid #ccc' : 'none'
                      }}
                    />
                    <Button variant="outline" className="capitalize">
                      {color}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎵 Phonics Time: A-B-C-D & E!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Let's review A-D and learn letter E!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-6 max-w-4xl mx-auto">
              {['A', 'B', 'C', 'D', 'E'].map((letter, index) => (
                <Card key={letter} className="p-6 text-center hover:shadow-lg transition-all">
                  <div className="space-y-4">
                    <div className={`text-4xl font-bold ${letter === 'E' ? 'text-accent animate-pulse' : 'text-primary'}`}>
                      {letter}{letter.toLowerCase()}
                    </div>
                    <p className="text-lg font-semibold">
                      {letter === 'A' ? 'Apple' : 
                       letter === 'B' ? 'Ball' : 
                       letter === 'C' ? 'Cat' : 
                       letter === 'D' ? 'Duck' : 
                       'Elephant'}
                    </p>
                    <div className="text-3xl">
                      {letter === 'A' ? '🍎' : 
                       letter === 'B' ? '⚽' : 
                       letter === 'C' ? '🐱' : 
                       letter === 'D' ? '🦆' : 
                       '🐘'}
                    </div>
                    <AudioButton text={letter} />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              1️⃣ Number One!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              One apple appears! Count with me: ONE!
            </p>
            <div className="space-y-6">
              <div className="text-9xl animate-bounce">🍎</div>
              <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-gradient-primary rounded-full flex items-center justify-center text-white text-4xl font-bold mx-auto">
                  1
                </div>
                <p className="text-3xl font-bold text-primary">ONE</p>
                <AudioButton text="one" className="text-lg" />
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              2️⃣ Number Two!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Two stars appear! Count with me: ONE, TWO!
            </p>
            <div className="space-y-6">
              <div className="flex justify-center gap-8">
                <div className="text-8xl animate-bounce">⭐</div>
                <div className="text-8xl animate-bounce" style={{animationDelay: '0.5s'}}>⭐</div>
              </div>
              <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-gradient-success rounded-full flex items-center justify-center text-white text-4xl font-bold mx-auto">
                  2
                </div>
                <p className="text-3xl font-bold text-success">TWO</p>
                <AudioButton text="two" className="text-lg" />
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              3️⃣ Number Three!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Three balloons float up! Count: ONE, TWO, THREE!
            </p>
            <div className="space-y-6">
              <div className="flex justify-center gap-4">
                <div className="text-7xl animate-float">🎈</div>
                <div className="text-7xl animate-float" style={{animationDelay: '0.3s'}}>🎈</div>
                <div className="text-7xl animate-float" style={{animationDelay: '0.6s'}}>🎈</div>
              </div>
              <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-gradient-accent rounded-full flex items-center justify-center text-white text-4xl font-bold mx-auto">
                  3
                </div>
                <p className="text-3xl font-bold text-accent">THREE</p>
                <AudioButton text="three" className="text-lg" />
              </div>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎯 Counting Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Click the objects and count aloud with teacher!
            </p>
            <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              {[1, 2, 3, 4, 5, 6].map(id => (
                <div
                  key={id}
                  className={`text-6xl cursor-pointer transition-all hover:scale-110 ${
                    clickedObjects.includes(id) ? 'opacity-50 scale-75' : ''
                  }`}
                  onClick={() => handleObjectClick(id)}
                >
                  {id <= 2 ? '🍎' : id <= 4 ? '⭐' : '🎈'}
                </div>
              ))}
            </div>
            <div className="text-center">
              <p className="text-lg font-bold">
                Clicked: {clickedObjects.length} objects
              </p>
              <Button 
                onClick={() => setClickedObjects([])} 
                variant="outline"
                className="mt-4"
              >
                Reset
              </Button>
            </div>
          </div>
        );

      case 8:
        return (
          <DragDropActivity
            title="🔢 Match Numbers to Sets!"
            items={[
              { id: '1', content: '1', type: 'source', matchId: 'one-apple' },
              { id: '2', content: '2', type: 'source', matchId: 'two-stars' },
              { id: '3', content: '3', type: 'source', matchId: 'three-balloons' },
              { id: 'one-apple', content: '🍎', type: 'target' },
              { id: 'two-stars', content: '⭐⭐', type: 'target' },
              { id: 'three-balloons', content: '🎈🎈🎈', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 9:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              ⚽ Toy Flashcard: Ball!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Tap to see the bouncing ball!
            </p>
            <div className="space-y-6">
              <div className="text-9xl animate-bounce cursor-pointer hover:scale-110 transition-all">
                ⚽
              </div>
              <Card className="p-6 max-w-md mx-auto">
                <div className="text-center space-y-4">
                  <h3 className="text-3xl font-bold text-primary">BALL</h3>
                  <AudioButton text="ball" className="text-xl" />
                  <p className="text-lg text-muted-foreground">
                    Say: "Ball"
                  </p>
                </div>
              </Card>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🚗 Toy Flashcard: Car!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Tap to see the racing car!
            </p>
            <div className="space-y-6">
              <div className="text-9xl cursor-pointer hover:scale-110 transition-all animate-bounce-gentle">
                🚗
              </div>
              <Card className="p-6 max-w-md mx-auto">
                <div className="text-center space-y-4">
                  <h3 className="text-3xl font-bold text-accent">CAR</h3>
                  <AudioButton text="car" className="text-xl" />
                  <p className="text-lg text-muted-foreground">
                    Say: "Car"
                  </p>
                </div>
              </Card>
            </div>
          </div>
        );

      case 11:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🗣️ Speaking Drill!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher models, you repeat: "Ball" and "Car"
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
              <Card className="p-8">
                <div className="text-center space-y-4">
                  <div className="text-8xl">⚽</div>
                  <SpeakingActivity 
                    prompt="Say: Ball"
                    expectedResponse="Ball"
                    onComplete={() => {}}
                  />
                </div>
              </Card>
              <Card className="p-8">
                <div className="text-center space-y-4">
                  <div className="text-8xl">🚗</div>
                  <SpeakingActivity 
                    prompt="Say: Car"
                    expectedResponse="Car"
                    onComplete={() => {}}
                  />
                </div>
              </Card>
            </div>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎯 Toy Matching Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Match the toy word to the picture!
            </p>
            <div className="grid grid-cols-2 gap-8 max-w-2xl mx-auto">
              <div className="space-y-4">
                <h3 className="text-xl font-bold">Words:</h3>
                <div className="space-y-3">
                  <Card className="p-4 cursor-pointer hover:shadow-lg transition-all">
                    <p className="text-2xl font-bold">BALL</p>
                  </Card>
                  <Card className="p-4 cursor-pointer hover:shadow-lg transition-all">
                    <p className="text-2xl font-bold">CAR</p>
                  </Card>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-bold">Pictures:</h3>
                <div className="space-y-3">
                  <Card className="p-4 cursor-pointer hover:shadow-lg transition-all">
                    <div className="text-6xl">🚗</div>
                  </Card>
                  <Card className="p-4 cursor-pointer hover:shadow-lg transition-all">
                    <div className="text-6xl">⚽</div>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Model Sentence 1
            </h2>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-primary">
              <div className="text-center space-y-6">
                <div className="text-8xl text-white">⚽</div>
                <div className="bg-white/20 p-6 rounded-2xl">
                  <p className="text-3xl font-bold text-white">
                    "One ball."
                  </p>
                </div>
                <AudioButton text="One ball" className="text-white border-white" />
                <p className="text-xl text-white">
                  Listen and repeat: "One ball."
                </p>
              </div>
            </Card>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Model Sentence 2
            </h2>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-success">
              <div className="text-center space-y-6">
                <div className="flex justify-center gap-4">
                  <div className="text-6xl text-white">🚗</div>
                  <div className="text-6xl text-white">🚗</div>
                </div>
                <div className="bg-white/20 p-6 rounded-2xl">
                  <p className="text-3xl font-bold text-white">
                    "Two cars."
                  </p>
                </div>
                <AudioButton text="Two cars" className="text-white border-white" />
                <p className="text-xl text-white">
                  Listen and repeat: "Two cars."
                </p>
              </div>
            </Card>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Model Sentence 3
            </h2>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-accent">
              <div className="text-center space-y-6">
                <div className="text-8xl text-white">⚽</div>
                <div className="bg-white/20 p-6 rounded-2xl">
                  <p className="text-3xl font-bold text-white">
                    "I have a ball."
                  </p>
                </div>
                <AudioButton text="I have a ball" className="text-white border-white" />
                <p className="text-xl text-white">
                  Listen and repeat: "I have a ball."
                </p>
              </div>
            </Card>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🗣️ Speaking Drill: What is this?
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher asks: "What is this?" You answer!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
              {[
                { emoji: '⚽', question: 'What is this?', answer: 'It is a ball' },
                { emoji: '🚗', question: 'What is this?', answer: 'It is a car' }
              ].map((item, index) => (
                <Card key={index} className="p-6">
                  <div className="space-y-4">
                    <div className="text-8xl">{item.emoji}</div>
                    <p className="font-bold text-lg">"{item.question}"</p>
                    <SpeakingActivity 
                      prompt={`Say: "${item.answer}"`}
                      expectedResponse={item.answer}
                      onComplete={() => {}}
                    />
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🧺 Grab & Count Game!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Drag toys into the basket, then count them!
            </p>
            <div className="grid grid-cols-2 gap-8 max-w-2xl mx-auto">
              <div className="space-y-4">
                <h3 className="text-xl font-bold">Available Toys:</h3>
                <div className="space-y-3">
                  {['⚽', '🚗', '⚽', '🚗'].map((toy, index) => (
                    <div
                      key={index}
                      className="text-6xl cursor-pointer hover:scale-110 transition-all"
                      onClick={() => handleDragToBasket(toy)}
                    >
                      {toy}
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-bold">Basket:</h3>
                <Card className="p-6 min-h-[200px] border-2 border-dashed border-primary">
                  <div className="text-6xl mb-4">🧺</div>
                  <div className="flex flex-wrap gap-2">
                    {basketItems.map((toy, index) => (
                      <span key={index} className="text-3xl">{toy}</span>
                    ))}
                  </div>
                  <p className="text-lg font-bold mt-4">
                    Count: {basketItems.length}
                  </p>
                </Card>
              </div>
            </div>
          </div>
        );

      case 18:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🛒 Toy Shop Role-Play!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Teacher is the shopkeeper. You are the customer!
            </p>
            <div className="max-w-2xl mx-auto">
              <Card className="p-8 bg-gradient-warm text-white">
                <div className="space-y-6">
                  <div className="flex items-center justify-center gap-4">
                    <div className="text-6xl">👨‍💼</div>
                    <div className="speech-bubble bg-white/20 p-4 rounded-2xl">
                      <p className="text-xl font-bold">
                        "Do you want a car?"
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="p-4 bg-white/20">
                      <div className="text-4xl mb-2">🚗</div>
                      <Button className="w-full">
                        "Yes, I want a car."
                      </Button>
                    </Card>
                    <Card className="p-4 bg-white/20">
                      <div className="text-4xl mb-2">⚽</div>
                      <Button className="w-full">
                        "I want a ball."
                      </Button>
                    </Card>
                  </div>
                  <p className="text-lg">
                    Choose your answer and practice speaking!
                  </p>
                </div>
              </Card>
            </div>
          </div>
        );

      case 19:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              🎪 Spin & Count Wheel!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              Spin the wheel, then say the sentence!
            </p>
            <div className="space-y-6">
              <div className="relative mx-auto w-64 h-64">
                <div className="w-full h-full rounded-full border-8 border-primary shadow-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <div className="text-6xl animate-spin-slow">🎯</div>
                </div>
              </div>
              <Button onClick={handleSpin} size="fun" variant="kid">
                🎪 Spin the Wheel!
              </Button>
              {spinResult && (
                <Card className="p-6 max-w-md mx-auto bg-gradient-success text-white">
                  <h3 className="text-2xl font-bold mb-4">Result:</h3>
                  <div className="flex justify-center gap-4 mb-4">
                    <div className="text-4xl">
                      {Array.from({length: spinResult.number}, (_, i) => (
                        <span key={i}>{spinResult.toy === 'ball' ? '⚽' : '🚗'}</span>
                      ))}
                    </div>
                  </div>
                  <p className="text-xl font-bold">
                    Now say: "{spinResult.number === 1 ? 'One' : spinResult.number === 2 ? 'Two' : 'Three'} {spinResult.toy}{spinResult.number > 1 ? 's' : ''}."
                  </p>
                  <AudioButton 
                    text={`${spinResult.number === 1 ? 'One' : spinResult.number === 2 ? 'Two' : 'Three'} ${spinResult.toy}${spinResult.number > 1 ? 's' : ''}`}
                    className="mt-4 text-white border-white"
                  />
                </Card>
              )}
            </div>
          </div>
        );

      case 20:
        return (
          <div className="text-center space-y-8">
            <h2 className="text-4xl font-bold font-fredoka text-primary">
              📝 Quick Quiz!
            </h2>
            <p className="text-xl font-fredoka text-muted-foreground">
              How many cars do you see?
            </p>
            <div className="space-y-6">
              <div className="flex justify-center gap-4">
                <div className="text-6xl">🚗</div>
                <div className="text-6xl">🚗</div>
                <div className="text-6xl">🚗</div>
              </div>
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                {[1, 2, 3].map(num => (
                  <Card key={num} className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-2">
                        {num}
                      </div>
                      <Button className="capitalize">
                        {num === 1 ? 'One' : num === 2 ? 'Two' : 'Three'}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        );

      case 21:
        return (
          <div className="text-center space-y-8">
            <div className="text-8xl animate-bounce">🏅</div>
            <h2 className="text-5xl font-bold font-fredoka rainbow-text">
              Congratulations!
            </h2>
            <h3 className="text-3xl font-bold font-fredoka text-primary">
              Number & Toy Explorer Badge Earned! 🎲
            </h3>
            <Card className="p-8 max-w-2xl mx-auto bg-gradient-to-r from-primary/20 to-accent/20">
              <div className="space-y-4">
                <div className="text-6xl">🏆</div>
                <h4 className="text-2xl font-bold">You are now a Number & Toy Expert!</h4>
                <p className="text-lg">
                  You've learned to count 1, 2, 3 and know the toys: ball and car! 
                  Amazing work with numbers and sentences!
                </p>
                <div className="flex justify-center gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold">1</div>
                    <span>⚽</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">2</div>
                    <span>🚗🚗</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold">3</div>
                    <span>🎈🎈🎈</span>
                  </div>
                </div>
              </div>
            </Card>
            <div className="text-6xl animate-pulse">✨🎉✨</div>
          </div>
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10 p-4">
      <FloatingLogo />
      
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Lesson 3.1 • Numbers 1-3 & Toys
          </Badge>
          <ProgressBar current={currentSlide} total={totalSlides} />
        </div>

        {/* Slide Content */}
        <Card className="p-8 mb-8 min-h-[500px] flex items-center justify-center">
          {renderSlide()}
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button
            onClick={prevSlide}
            disabled={currentSlide === 1}
            variant="outline"
            size="lg"
          >
            ← Previous
          </Button>
          
          <span className="text-lg font-semibold">
            {currentSlide} / {totalSlides}
          </span>
          
          <Button
            onClick={nextSlide}
            size="lg"
            className="bg-gradient-primary hover:shadow-button"
          >
            {currentSlide === totalSlides ? "Finish! 🏅" : "Next →"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Lesson31;