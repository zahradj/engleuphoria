import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Pen, Eraser, Trash2, X, Circle } from "lucide-react";

interface SimpleDrawingOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SimpleDrawingOverlay = ({ isOpen, onClose }: SimpleDrawingOverlayProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [activeTool, setActiveTool] = useState<"pen" | "circle" | "eraser">("pen");
  const [penColor, setPenColor] = useState("#ff6b35");
  const [ctx, setCtx] = useState<CanvasRenderingContext2D | null>(null);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!canvasRef.current || !isOpen) return;

    const canvas = canvasRef.current;
    canvas.width = window.innerWidth - 100;
    canvas.height = window.innerHeight - 200;
    
    const context = canvas.getContext("2d");
    if (context) {
      context.lineCap = "round";
      context.lineJoin = "round";
      setCtx(context);
    }
  }, [isOpen]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!ctx) return;
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    setStartPos({ x, y });
    setIsDrawing(true);
    
    if (activeTool === "pen") {
      ctx.beginPath();
      ctx.moveTo(x, y);
    } else if (activeTool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.beginPath();
      ctx.arc(x, y, 15, 0, 2 * Math.PI);
      ctx.fill();
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !ctx) return;
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    if (activeTool === "pen") {
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = penColor;
      ctx.lineWidth = 3;
      ctx.lineTo(x, y);
      ctx.stroke();
    } else if (activeTool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.beginPath();
      ctx.arc(x, y, 15, 0, 2 * Math.PI);
      ctx.fill();
    }
  };

  const stopDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !ctx) return;
    
    if (activeTool === "circle") {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;
      
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const radius = Math.sqrt(Math.pow(x - startPos.x, 2) + Math.pow(y - startPos.y, 2));
      
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = penColor;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(startPos.x, startPos.y, radius, 0, 2 * Math.PI);
      ctx.stroke();
    }
    
    setIsDrawing(false);
  };

  const handleClear = () => {
    if (!ctx || !canvasRef.current) return;
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-transparent animate-fade-in">
      <div className="absolute inset-4 bg-transparent rounded-lg">
        {/* Drawing Tools */}
        <div className="absolute top-4 left-4 flex gap-2 bg-white/98 backdrop-blur-none p-3 rounded-xl shadow-xl border border-border/50 animate-scale-in">
          <Button
            variant={activeTool === "pen" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTool("pen")}
            className="flex items-center gap-2 hover-scale"
          >
            <Pen className="h-4 w-4" />
            Pen
          </Button>
          
          <Button
            variant={activeTool === "circle" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTool("circle")}
            className="flex items-center gap-2 hover-scale"
          >
            <Circle className="h-4 w-4" />
            Circle
          </Button>
          
          <Button
            variant={activeTool === "eraser" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTool("eraser")}
            className="flex items-center gap-2 hover-scale"
          >
            <Eraser className="h-4 w-4" />
            Eraser
          </Button>
          
          <div className="flex gap-1 items-center">
            <span className="text-xs text-muted-foreground mr-1">Color:</span>
            {["#ff6b35", "#4f46e5", "#10b981", "#f59e0b", "#ef4444"].map((color) => (
              <button
                key={color}
                onClick={() => setPenColor(color)}
                className={`w-8 h-8 rounded-full border-2 transition-all duration-200 hover-scale ${
                  penColor === color ? "border-gray-800 scale-110" : "border-gray-300"
                }`}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handleClear}
            className="flex items-center gap-2 hover-scale"
          >
            <Trash2 className="h-4 w-4" />
            Clear
          </Button>
        </div>

        {/* Close Button */}
        <div className="absolute top-4 right-4">
          <Button
            variant="outline"
            size="sm"
            onClick={onClose}
            className="bg-white/98 backdrop-blur-none shadow-xl border border-border/50 hover-scale"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Instructions */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
          <div className="bg-white/98 backdrop-blur-none px-4 py-2 rounded-lg shadow-xl border border-border/50 animate-fade-in">
            <p className="text-sm text-muted-foreground text-center">
              {activeTool === "pen" && "Click and drag to draw"}
              {activeTool === "circle" && "Click and drag to draw a circle"}
              {activeTool === "eraser" && "Click and drag to erase"}
            </p>
          </div>
        </div>

        {/* Drawing Canvas */}
        <div className="flex justify-center items-center h-full">
          <canvas 
            ref={canvasRef} 
            className="absolute inset-0 cursor-crosshair"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={() => setIsDrawing(false)}
          />
        </div>
      </div>
    </div>
  );
};