import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Award, Star } from "lucide-react";

interface BadgeRewardProps {
  title: string;
  description: string;
  badgeName: string;
  onContinue: () => void;
}

export const BadgeReward = ({ title, description, badgeName, onContinue }: BadgeRewardProps) => {
  return (
    <div className="text-center space-y-6">
      <div className="relative">
        <div className="mx-auto w-32 h-32 bg-gradient-success rounded-full flex items-center justify-center shadow-button animate-pulse">
          <Award className="h-16 w-16 text-white" />
        </div>
        <div className="absolute -top-2 -right-2">
          <div className="w-8 h-8 bg-warning rounded-full flex items-center justify-center">
            <Star className="h-4 w-4 text-white" />
          </div>
        </div>
      </div>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
          {title}
        </h2>
        <p className="text-lg text-muted-foreground">
          {description}
        </p>
      </div>
      
      <Card className="p-6 bg-gradient-warm max-w-md mx-auto">
        <div className="text-center space-y-2">
          <h3 className="text-xl font-bold text-white">🏅 Badge Earned!</h3>
          <p className="text-white font-semibold">{badgeName}</p>
        </div>
      </Card>
      
      <Button 
        onClick={onContinue}
        className="bg-gradient-primary hover:shadow-button transition-all duration-300 text-lg font-semibold px-8 py-3"
      >
        Start Next Lesson →
      </Button>
    </div>
  );
};