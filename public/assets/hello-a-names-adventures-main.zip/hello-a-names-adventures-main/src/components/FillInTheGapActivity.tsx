import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AudioButton } from "@/components/AudioButton";
import { CheckCircle, XCircle } from "lucide-react";

interface WordItem {
  word: string;
  imageSrc: string;
  missingLetter: string;
  missingPosition: number;
}

interface FillInTheGapActivityProps {
  title: string;
  words: WordItem[];
  onComplete: () => void;
}

export const FillInTheGapActivity = ({ title, words, onComplete }: FillInTheGapActivityProps) => {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<Record<string, 'correct' | 'incorrect'>>({});
  const [showResults, setShowResults] = useState(false);
  
  const updateAnswer = (wordIndex: number, value: string) => {
    setAnswers(prev => ({ ...prev, [wordIndex]: value }));
  };
  
  const checkAnswers = () => {
    const newFeedback: Record<string, 'correct' | 'incorrect'> = {};
    
    words.forEach((wordItem, index) => {
      const userAnswer = answers[index]?.toLowerCase() || '';
      const correctAnswer = wordItem.missingLetter.toLowerCase();
      newFeedback[index] = userAnswer === correctAnswer ? 'correct' : 'incorrect';
    });
    
    setFeedback(newFeedback);
    setShowResults(true);
  };
  
  const allAnswered = words.every((_, index) => answers[index]?.trim());
  const allCorrect = Object.values(feedback).every(f => f === 'correct');
  
  const renderWordWithMissing = (wordItem: WordItem, wordIndex: number) => {
    return wordItem.word.split('').map((letter, letterIndex) => {
      if (letterIndex === wordItem.missingPosition) {
        return (
          <div key={letterIndex} className="inline-flex flex-col items-center mx-1">
            <Input
              value={answers[wordIndex] || ''}
              onChange={(e) => updateAnswer(wordIndex, e.target.value)}
              className={`w-12 h-12 text-center text-2xl font-bold border-2 ${
                showResults 
                  ? feedback[wordIndex] === 'correct' 
                    ? 'border-success bg-success/10' 
                    : 'border-destructive bg-destructive/10'
                  : 'border-primary'
              }`}
              maxLength={1}
              disabled={showResults}
              placeholder="_"
            />
          </div>
        );
      }
      return (
        <span key={letterIndex} className="text-2xl font-bold mx-1">
          {letter}
        </span>
      );
    });
  };
  
  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h3 className="text-2xl font-semibold">{title}</h3>
        <div className="bg-gradient-primary p-4 rounded-2xl inline-block">
          <span className="text-white text-lg font-medium">Fill in the missing letter for each word!</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {words.map((wordItem, index) => (
          <Card key={index} className="p-6 text-center space-y-4">
            <img 
              src={wordItem.imageSrc} 
              alt={wordItem.word} 
              className="w-32 h-32 object-contain mx-auto"
            />
            
            <div className="flex items-center justify-center gap-2">
              {renderWordWithMissing(wordItem, index)}
            </div>
            
            <div className="flex items-center justify-center gap-2">
              <AudioButton 
                text={wordItem.word} 
                variant="outline" 
                className="text-primary border-primary hover:bg-primary/10"
                size="sm"
              />
              {showResults && (
                feedback[index] === 'correct' 
                  ? <CheckCircle className="h-5 w-5 text-success" />
                  : <XCircle className="h-5 w-5 text-destructive" />
              )}
            </div>
          </Card>
        ))}
      </div>
      
      {!showResults && allAnswered && (
        <div className="text-center">
          <Button 
            onClick={checkAnswers}
            className="bg-gradient-primary hover:shadow-button transition-all duration-300"
          >
            Check All Answers
          </Button>
        </div>
      )}
      
      {showResults && (
        <div className="text-center space-y-4">
          {allCorrect ? (
            <div className="text-success font-semibold text-lg">
              Excellent! All letters are correct! 🎉
            </div>
          ) : (
            <div className="text-warning font-semibold">
              Good try! Check the incorrect answers and try again.
            </div>
          )}
          
          {allCorrect && (
            <Button 
              onClick={onComplete}
              className="bg-gradient-success hover:shadow-button transition-all duration-300"
            >
              Continue →
            </Button>
          )}
          
          {!allCorrect && (
            <Button 
              onClick={() => {
                setShowResults(false);
                setFeedback({});
              }}
              variant="outline"
              className="border-primary text-primary hover:bg-primary/10"
            >
              Try Again
            </Button>
          )}
        </div>
      )}
    </div>
  );
};