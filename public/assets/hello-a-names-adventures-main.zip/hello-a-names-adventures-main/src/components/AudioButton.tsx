import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Volume2, VolumeX } from "lucide-react";

interface AudioButtonProps {
  text?: string;
  audioSrc?: string;
  className?: string;
  size?: "sm" | "default" | "lg";
  variant?: "default" | "ghost" | "outline";
  playbackRate?: number; // 0.5 = half speed, 1 = normal, 2 = double speed
  voice?: "male" | "female" | "child";
  pitch?: number; // 0.5 = lower, 1 = normal, 2 = higher
}

export const AudioButton = ({ 
  text,
  audioSrc, 
  className = "", 
  size = "sm",
  variant = "ghost",
  playbackRate = 1,
  voice = "female",
  pitch = 1.2
}: AudioButtonProps) => {
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayAudio = async () => {
    if (isPlaying) return;
    
    setIsPlaying(true);
    
    try {
      if (audioSrc) {
        // Play audio file
        const audio = new Audio(audioSrc);
        audio.playbackRate = playbackRate;
        audio.onended = () => {
          setIsPlaying(false);
        };
        audio.onerror = () => {
          setIsPlaying(false);
        };
        await audio.play();
      } else if (text) {
        // Use Web Speech API as fallback
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.8 * playbackRate;
        utterance.pitch = pitch;
        utterance.volume = 1;
        
        // Try to select a voice based on gender preference
        const voices = speechSynthesis.getVoices();
        if (voices.length > 0) {
          const preferredVoice = voices.find(v => {
            const name = v.name.toLowerCase();
            if (voice === "female") return name.includes("female") || name.includes("woman") || name.includes("zira") || name.includes("susan");
            if (voice === "male") return name.includes("male") || name.includes("man") || name.includes("david") || name.includes("mark");
            if (voice === "child") return name.includes("child") || name.includes("kid");
            return false;
          }) || voices.find(v => voice === "female" ? !v.name.toLowerCase().includes("male") : v.name.toLowerCase().includes("male"));
          
          if (preferredVoice) utterance.voice = preferredVoice;
        }
        
        utterance.onend = () => {
          setIsPlaying(false);
        };
        
        speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error("Audio playback failed:", error);
      setIsPlaying(false);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handlePlayAudio}
      disabled={isPlaying}
      className={`transition-all duration-200 ${className}`}
      aria-label={`Play audio for: ${text || 'sound'}`}
    >
      {isPlaying ? (
        <VolumeX className="h-4 w-4" />
      ) : (
        <Volume2 className="h-4 w-4" />
      )}
    </Button>
  );
};