import React from "react";
import { Progress } from "@/components/ui/progress";

interface ProgressBarProps {
  current: number;
  total: number;
  className?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  current,
  total,
  className = ""
}) => {
  const percentage = Math.round((current / total) * 100);
  
  return (
    <div className={`w-full ${className}`}>
      <Progress value={percentage} className="h-3" />
      <p className="text-sm text-muted-foreground mt-2 text-center">
        {current} of {total} completed ({percentage}%)
      </p>
    </div>
  );
};