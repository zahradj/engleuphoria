import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle } from "lucide-react";

interface DragDropItem {
  id: string;
  content: string;
  type: 'source' | 'target';
  matchId?: string;
  isImage?: boolean;
}

interface DragDropActivityProps {
  title: string;
  items: DragDropItem[];
  onComplete: () => void;
}

export const DragDropActivity = ({ title, items, onComplete }: DragDropActivityProps) => {
  const [matches, setMatches] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<Record<string, 'correct' | 'incorrect'>>({});
  
  const sourceItems = items.filter(item => item.type === 'source');
  const targetItems = items.filter(item => item.type === 'target');
  
  const handleDrop = (sourceId: string, targetId: string) => {
    const sourceItem = sourceItems.find(item => item.id === sourceId);
    const isCorrect = sourceItem?.matchId === targetId;
    
    setMatches(prev => ({ ...prev, [sourceId]: targetId }));
    setFeedback(prev => ({ ...prev, [sourceId]: isCorrect ? 'correct' : 'incorrect' }));
  };
  
  const allMatched = sourceItems.length === Object.keys(matches).length;
  const allCorrect = Object.values(feedback).every(f => f === 'correct');
  
  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-center">{title}</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Source Items */}
        <div className="space-y-4">
          <h4 className="font-semibold text-center">Drag from here:</h4>
          <div className="space-y-3">
            {sourceItems.map(item => (
              <div 
                key={item.id}
                className={`p-2 cursor-move transition-all duration-200 ${
                  matches[item.id] 
                    ? feedback[item.id] === 'correct' 
                      ? 'opacity-70' 
                      : 'opacity-70'
                    : 'hover:scale-105'
                }`}
                draggable
                onDragStart={(e) => e.dataTransfer.setData('text/plain', item.id)}
              >
                <div className="flex items-center justify-between">
                  {item.isImage ? (
                    <img src={item.content} alt={item.id} className="w-48 h-48 object-contain" />
                  ) : (
                    <span className="font-medium">{item.content}</span>
                  )}
                  {matches[item.id] && (
                    feedback[item.id] === 'correct' 
                      ? <CheckCircle className="h-5 w-5 text-success" />
                      : <XCircle className="h-5 w-5 text-destructive" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Target Items */}
        <div className="space-y-4">
          <h4 className="font-semibold text-center">Drop here:</h4>
          <div className="space-y-3">
            {targetItems.map(item => (
              <Card 
                key={item.id}
                className="p-4 border-2 border-dashed border-muted-foreground/30 min-h-[60px] transition-colors duration-200 hover:border-primary/50"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const sourceId = e.dataTransfer.getData('text/plain');
                  handleDrop(sourceId, item.id);
                }}
              >
                <div className="text-center text-muted-foreground">
                  {item.isImage ? (
                    <img src={item.content} alt={item.id} className="w-24 h-24 object-contain mx-auto" />
                  ) : (
                    item.content
                  )}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
      
      {allMatched && (
        <div className="text-center space-y-4">
          {allCorrect ? (
            <div className="text-success font-semibold text-lg">
              Excellent! All matches are correct! 🎉
            </div>
          ) : (
            <div className="text-warning font-semibold">
              Try again! Some matches need to be corrected.
            </div>
          )}
          
          {allCorrect && (
            <Button 
              onClick={onComplete}
              className="bg-gradient-success hover:shadow-button transition-all duration-300"
            >
              Continue →
            </Button>
          )}
        </div>
      )}
    </div>
  );
};