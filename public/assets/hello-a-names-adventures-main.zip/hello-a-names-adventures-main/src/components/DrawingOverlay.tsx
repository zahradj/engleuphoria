import { useEffect, useRef, useState } from "react";
import { Canvas as FabricCanvas } from "fabric";
import { Button } from "@/components/ui/button";
import { Pen, Eraser, Trash2, X } from "lucide-react";

interface DrawingOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DrawingOverlay = ({ isOpen, onClose }: DrawingOverlayProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [fabricCanvas, setFabricCanvas] = useState<FabricCanvas | null>(null);
  const [activeTool, setActiveTool] = useState<"pen" | "eraser">("pen");
  const [penColor, setPenColor] = useState("#ff6b35");

  useEffect(() => {
    if (!canvasRef.current || !isOpen) return;

    const canvas = new FabricCanvas(canvasRef.current, {
      width: window.innerWidth - 100,
      height: window.innerHeight - 200,
      backgroundColor: "transparent",
    });

    // Enable drawing mode and ensure brush is initialized
    canvas.isDrawingMode = true;
    
    // Ensure freeDrawingBrush exists before setting properties
    if (canvas.freeDrawingBrush) {
      canvas.freeDrawingBrush.color = penColor;
      canvas.freeDrawingBrush.width = 3;
    }

    setFabricCanvas(canvas);

    return () => {
      canvas.dispose();
    };
  }, [isOpen, penColor]);

  useEffect(() => {
    if (!fabricCanvas || !fabricCanvas.freeDrawingBrush) return;

    if (activeTool === "pen") {
      fabricCanvas.freeDrawingBrush.color = penColor;
      fabricCanvas.freeDrawingBrush.width = 3;
    } else if (activeTool === "eraser") {
      fabricCanvas.freeDrawingBrush.color = "rgba(255,255,255,0)";
      fabricCanvas.freeDrawingBrush.width = 20;
    }
  }, [activeTool, penColor, fabricCanvas]);

  const handleClear = () => {
    if (!fabricCanvas) return;
    fabricCanvas.clear();
    fabricCanvas.backgroundColor = "transparent";
    fabricCanvas.renderAll();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm">
      <div className="absolute inset-4 bg-transparent rounded-lg">
        {/* Drawing Tools */}
        <div className="absolute top-4 left-4 flex gap-2 bg-white/90 backdrop-blur-sm p-3 rounded-xl shadow-lg border border-border/50">
          <Button
            variant={activeTool === "pen" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTool("pen")}
            className="flex items-center gap-2"
          >
            <Pen className="h-4 w-4" />
            Pen
          </Button>
          
          <Button
            variant={activeTool === "eraser" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTool("eraser")}
            className="flex items-center gap-2"
          >
            <Eraser className="h-4 w-4" />
            Eraser
          </Button>
          
          <div className="flex gap-1">
            {["#ff6b35", "#4f46e5", "#10b981", "#f59e0b", "#ef4444"].map((color) => (
              <button
                key={color}
                onClick={() => setPenColor(color)}
                className={`w-8 h-8 rounded-full border-2 ${
                  penColor === color ? "border-gray-800" : "border-gray-300"
                }`}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handleClear}
            className="flex items-center gap-2"
          >
            <Trash2 className="h-4 w-4" />
            Clear
          </Button>
        </div>

        {/* Close Button */}
        <div className="absolute top-4 right-4">
          <Button
            variant="outline"
            size="sm"
            onClick={onClose}
            className="bg-white/90 backdrop-blur-sm shadow-lg border border-border/50"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Drawing Canvas */}
        <div className="flex justify-center items-center h-full">
          <canvas 
            ref={canvasRef} 
            className="border border-gray-200 rounded-lg shadow-lg bg-transparent"
          />
        </div>
      </div>
    </div>
  );
};