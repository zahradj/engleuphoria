import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-medium font-fredoka ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 transform hover:scale-105",
  {
    variants: {
      variant: {
        default: "bg-gradient-primary text-white hover:shadow-glow shadow-button",
        destructive: "bg-gradient-to-r from-lesson-red to-warning text-white hover:shadow-glow",
        outline: "border-2 border-primary bg-white/80 text-primary hover:bg-gradient-primary hover:text-white hover:border-primary",
        secondary: "bg-gradient-to-r from-secondary to-warning text-foreground hover:shadow-fun",
        ghost: "hover:bg-gradient-fun hover:text-primary rounded-2xl",
        link: "text-primary underline-offset-4 hover:underline font-semibold",
        fun: "bg-gradient-rainbow text-white hover:shadow-glow animate-pulse-fun",
        success: "bg-gradient-success text-white hover:shadow-glow",
        kid: "bg-gradient-to-r from-lesson-pink to-lesson-purple text-white hover:shadow-glow rounded-2xl font-bold",
      },
      size: {
        default: "h-12 px-6 py-3 text-base",
        sm: "h-9 rounded-xl px-4 text-sm",
        lg: "h-14 rounded-2xl px-10 text-lg font-bold",
        icon: "h-12 w-12 rounded-2xl",
        fun: "h-16 px-12 py-4 text-xl font-bold rounded-3xl",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
