import { Card } from "@/components/ui/card";
import { AudioButton } from "@/components/AudioButton";
interface TranslationCardProps {
  english: string;
  french: string;
  className?: string;
}
export const TranslationCard = ({
  english,
  french,
  className = ""
}: TranslationCardProps) => {
  return <Card className={`p-4 bg-gradient-card border border-border/50 ${className}`}>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="text-lg font-semibold text-foreground">{english}</p>
          <AudioButton text={english} variant="ghost" className="text-primary hover:bg-primary/20" />
        </div>
        
      </div>
    </Card>;
};