import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AudioButton } from "@/components/AudioButton";

interface MissingLetterActivityProps {
  word: string;
  imageSrc: string;
  missingLetter: string;
  missingPosition: number;
  onComplete: () => void;
}

export const MissingLetterActivity = ({ 
  word, 
  imageSrc, 
  missingLetter, 
  missingPosition, 
  onComplete 
}: MissingLetterActivityProps) => {
  const [userInput, setUserInput] = useState("");
  const [showFeedback, setShowFeedback] = useState(false);
  
  const checkAnswer = () => {
    setShowFeedback(true);
    if (userInput.toLowerCase() === missingLetter.toLowerCase()) {
      setTimeout(() => onComplete(), 2000);
    }
  };
  
  const isCorrect = userInput.toLowerCase() === missingLetter.toLowerCase();
  
  const renderWordWithMissing = () => {
    return word.split('').map((letter, index) => {
      if (index === missingPosition) {
        return (
          <div key={index} className="inline-flex flex-col items-center mx-1">
            <Input
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              className="w-12 h-12 text-center text-2xl font-bold border-2 border-primary"
              maxLength={1}
              disabled={showFeedback}
              placeholder="_"
            />
          </div>
        );
      }
      return (
        <span key={index} className="text-2xl font-bold mx-1">
          {letter}
        </span>
      );
    });
  };
  
  return (
    <div className="space-y-8 text-center">
      <div className="space-y-4">
        <h3 className="text-2xl font-semibold">What letter is missing?</h3>
        <div className="bg-gradient-primary p-4 rounded-2xl inline-block">
          <span className="text-white text-lg font-medium">Fill in the missing letter!</span>
        </div>
      </div>
      
      <Card className="p-8 max-w-md mx-auto">
        <div className="space-y-6">
          <img 
            src={imageSrc} 
            alt={word} 
            className="w-40 h-40 object-contain mx-auto"
          />
          
          <div className="flex items-center justify-center gap-2">
            {renderWordWithMissing()}
          </div>
          
          <div className="flex items-center justify-center gap-2">
            <AudioButton 
              text={word} 
              variant="outline" 
              className="text-primary border-primary hover:bg-primary/10"
            />
          </div>
        </div>
      </Card>
      
      {!showFeedback && userInput && (
        <Button 
          onClick={checkAnswer}
          className="bg-gradient-primary hover:shadow-button transition-all duration-300"
        >
          Check Answer
        </Button>
      )}
      
      {showFeedback && (
        <div className="space-y-4">
          {isCorrect ? (
            <div className="text-success font-semibold text-lg">
              Perfect! The word is "{word}" 🎉
            </div>
          ) : (
            <div className="text-warning font-semibold">
              Try again! The missing letter is "{missingLetter}"
            </div>
          )}
          
          {isCorrect && (
            <Button 
              onClick={onComplete}
              className="bg-gradient-success hover:shadow-button transition-all duration-300"
            >
              Continue →
            </Button>
          )}
        </div>
      )}
    </div>
  );
};