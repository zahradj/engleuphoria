import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Volume2 } from "lucide-react";
import { AudioButton } from "@/components/AudioButton";
import appleImage from "@/assets/phonics-apple.png";
import sunImage from "@/assets/phonics-sun.png";
import antImage from "@/assets/phonics-ant.png";
import fishImage from "@/assets/phonics-fish.png";
import alligatorImage from "@/assets/phonics-alligator.png";
import bookImage from "@/assets/phonics-book.png";

interface PhonicsActivityProps {
  letter: string;
  words: Array<{
    word: string;
    image: string;
    hasLetter: boolean;
  }>;
  onComplete: () => void;
}

export const PhonicsActivity = ({ letter, words, onComplete }: PhonicsActivityProps) => {
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [showFeedback, setShowFeedback] = useState(false);
  
  const imageMap: Record<string, string> = {
    'apple': appleImage,
    'ant': antImage,
    'sun': sunImage,
    'fish': fishImage,
    'alligator': alligatorImage,
    'book': bookImage,
  };
  
  const handleWordClick = (word: string) => {
    if (selectedWords.includes(word)) {
      setSelectedWords(prev => prev.filter(w => w !== word));
    } else {
      setSelectedWords(prev => [...prev, word]);
    }
  };
  
  const checkAnswers = () => {
    setShowFeedback(true);
  };
  
  const correctWords = words.filter(w => w.hasLetter).map(w => w.word);
  const isCorrect = selectedWords.length === correctWords.length && 
    selectedWords.every(word => correctWords.includes(word));
  
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 bg-gradient-primary p-4 rounded-2xl">
          <span className="text-4xl font-bold text-white">
            {letter ? `${letter.toUpperCase()}${letter.toLowerCase()}` : 'Aa'}
          </span>
          <AudioButton 
            audioSrc="/audio/alphasounds-a.mp3"
            variant="ghost"
            className="text-white hover:bg-white/20"
          />
        </div>
        <p className="text-lg font-medium">
          Click on the words that start with the sound "{letter ? letter.toLowerCase() : 'a'}"
        </p>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {words.map((item) => {
          console.log('Rendering phonics word:', item.word, 'with image:', item.image);
          const isSelected = selectedWords.includes(item.word);
          const isCorrectWord = item.hasLetter;
          const showCorrect = showFeedback && isSelected && isCorrectWord;
          const showIncorrect = showFeedback && isSelected && !isCorrectWord;
          const showMissed = showFeedback && !isSelected && isCorrectWord;
          
          return (
            <Card
              key={item.word}
              className={`p-4 cursor-pointer transition-all duration-200 text-center space-y-3 ${
                showCorrect 
                  ? 'border-success bg-success/10 border-2'
                  : showIncorrect 
                    ? 'border-destructive bg-destructive/10 border-2'
                    : showMissed
                      ? 'border-warning bg-warning/10 border-2'
                      : isSelected 
                        ? 'border-primary bg-primary/10 border-2 shadow-soft'
                        : 'border-border hover:border-primary/50 hover:shadow-soft'
              }`}
              onClick={() => !showFeedback && handleWordClick(item.word)}
            >
              <div className="flex justify-center">
                <img 
                  src={imageMap[item.image] || item.image} 
                  alt={item.word}
                  className="w-32 h-32 object-contain"
                />
              </div>
              <div className="flex items-center justify-center gap-2">
                <p className="font-semibold text-lg">{item.word}</p>
                <AudioButton 
                  text={item.word} 
                  variant="ghost" 
                  className="text-primary hover:bg-primary/20" 
                />
              </div>
            </Card>
          );
        })}
      </div>
      
      {!showFeedback && selectedWords.length > 0 && (
        <div className="text-center">
          <Button 
            onClick={checkAnswers}
            className="bg-gradient-primary hover:shadow-button transition-all duration-300"
          >
            Check Answers
          </Button>
        </div>
      )}
      
      {showFeedback && (
        <div className="text-center space-y-4">
          {isCorrect ? (
            <div className="text-success font-semibold text-lg">
              Perfect! You found all the "{letter || 'a'}" words! 🎉
            </div>
          ) : (
            <div className="text-warning font-semibold">
              Good try! Look for the words that start with "{letter || 'a'}" sound.
            </div>
          )}
          
          <Button 
            onClick={onComplete}
            className="bg-gradient-success hover:shadow-button transition-all duration-300"
          >
            Continue →
          </Button>
        </div>
      )}
    </div>
  );
};