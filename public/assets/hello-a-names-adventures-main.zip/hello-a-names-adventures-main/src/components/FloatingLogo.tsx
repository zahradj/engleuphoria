import engliphoriaLogo from "@/assets/englephoria-logo-new.png";

export const FloatingLogo = () => {
  return (
    <div className="fixed top-4 left-4 z-50">
      <div className="logo-bubble animate-float">
        <img 
          src={engliphoriaLogo} 
          alt="Engliphoria Logo" 
          className="w-12 h-12 object-contain"
        />
      </div>
    </div>
  );
};