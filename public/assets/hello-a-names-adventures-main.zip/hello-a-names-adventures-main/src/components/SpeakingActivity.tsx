import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mic, Volume2, CheckCircle } from "lucide-react";
import { AudioButton } from "@/components/AudioButton";

interface SpeakingActivityProps {
  prompt: string;
  expectedResponse?: string;
  onComplete: () => void;
}

export const SpeakingActivity = ({ prompt, expectedResponse, onComplete }: SpeakingActivityProps) => {
  const [isRecording, setIsRecording] = useState(false);
  const [hasSpoken, setHasSpoken] = useState(false);
  
  const handleMicClick = () => {
    setIsRecording(true);
    // Simulate recording for 2 seconds
    setTimeout(() => {
      setIsRecording(false);
      setHasSpoken(true);
    }, 2000);
  };
  
  const handlePlayPrompt = () => {
    // Audio playback would be implemented here
    console.log("Playing:", prompt);
  };
  
  return (
    <div className="space-y-6">
      <Card className="p-6 bg-gradient-warm">
        <div className="flex items-center gap-3 justify-center">
          <AudioButton 
            text={prompt}
            variant="ghost"
            className="text-white hover:bg-white/20"
          />
          <p className="text-lg font-semibold text-center text-white">
            {prompt}
          </p>
        </div>
      </Card>
      
      {expectedResponse && (
        <Card className="p-4 bg-muted/50">
          <p className="text-center text-muted-foreground">
            <strong>Example:</strong> {expectedResponse}
          </p>
        </Card>
      )}
      
      <div className="text-center space-y-4">
        <p className="font-medium">Now it's your turn to speak!</p>
        
        <div className="flex justify-center">
          <Button
            onClick={handleMicClick}
            disabled={isRecording}
            className={`w-20 h-20 rounded-full transition-all duration-300 ${
              isRecording 
                ? 'bg-destructive hover:bg-destructive animate-pulse' 
                : hasSpoken
                  ? 'bg-success hover:bg-success'
                  : 'bg-gradient-primary hover:shadow-button'
            }`}
          >
            {hasSpoken ? (
              <CheckCircle className="h-8 w-8" />
            ) : (
              <Mic className={`h-8 w-8 ${isRecording ? 'animate-pulse' : ''}`} />
            )}
          </Button>
        </div>
        
        <p className="text-sm text-muted-foreground">
          {isRecording 
            ? "Recording... Speak clearly!" 
            : hasSpoken 
              ? "Great job speaking!"
              : "Click the microphone to record"
          }
        </p>
        
        {hasSpoken && (
          <Button 
            onClick={onComplete}
            className="bg-gradient-success hover:shadow-button transition-all duration-300"
          >
            Continue →
          </Button>
        )}
      </div>
    </div>
  );
};