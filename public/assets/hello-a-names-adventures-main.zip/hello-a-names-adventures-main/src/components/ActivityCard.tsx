import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ReactNode, useState } from "react";
import { Pen } from "lucide-react";
import { DrawingOverlay } from "@/components/DrawingOverlay";
import { SimpleDrawingOverlay } from "@/components/SimpleDrawingOverlay";
interface ActivityCardProps {
  title: string;
  children: ReactNode;
  onNext?: () => void;
  showNext?: boolean;
  className?: string;
}
export const ActivityCard = ({
  title,
  children,
  onNext,
  showNext = true,
  className = ""
}: ActivityCardProps) => {
  const [isDrawingOpen, setIsDrawingOpen] = useState(false);
  return <>
      <Card className={`p-8 bg-gradient-card shadow-fun border-2 border-primary/20 relative hover-grow rounded-3xl ${className}`}>
        {/* Drawing Tool Button */}
        <div className="absolute top-4 right-4">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setIsDrawingOpen(true)} 
            className="flex items-center gap-2 bg-gradient-fun hover:bg-gradient-primary border-primary/30 text-primary hover:text-white rounded-2xl shadow-button hover:shadow-glow transition-all duration-300 bounce-fun"
          >
            <Pen className="h-4 w-4" />
            ✏️ Draw
          </Button>
        </div>

        <div className="space-y-6">
          {/* Fun title with emoji and rainbow effect */}
          <div className="text-center">
            <h2 className="text-3xl font-bold font-fredoka rainbow-text mb-2 sparkle">
              {title}
            </h2>
            <div className="w-20 h-1 bg-gradient-rainbow rounded-full mx-auto animate-pulse-fun"></div>
          </div>
          
          <div className="space-y-4">
            {children}
          </div>
          
          {showNext && onNext && (
            <div className="flex justify-center">
              <Button 
                onClick={onNext} 
                className="bg-gradient-primary hover:shadow-glow transition-all duration-300 text-xl font-bold font-fredoka px-10 py-4 rounded-2xl shadow-button"
              >
                🎉 Next Adventure! →
              </Button>
            </div>
          )}
        </div>
      </Card>
      
      <SimpleDrawingOverlay isOpen={isDrawingOpen} onClose={() => setIsDrawingOpen(false)} />
    </>;
};